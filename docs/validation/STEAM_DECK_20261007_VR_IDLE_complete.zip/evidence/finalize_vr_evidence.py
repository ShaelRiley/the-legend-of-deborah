"""Verify the frozen matrix, retain every raw stream, and package VR idle evidence."""
import hashlib
import importlib.util
import json
import subprocess
import sys
import zipfile
from pathlib import Path

root = Path('/workspace/scratch/6c9c499b7513')
repo = root / 'the-legend-of-deborah'
out = root / 'vr-complete-matrix-final'
parent = '1e67e3fbac939166a10e6f856e4355ef2086e732'
spec = importlib.util.spec_from_file_location('vr_matrix', repo / 'tools/test_checkpoint_g_integration.py')
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
receipt = json.loads((out / 'receipt.json').read_text())
manifest = json.loads((out / 'source_manifest.json').read_text())
assert receipt['total'] == receipt['passed'] == len(matrix.SUITES) == 313
assert receipt['lua_files'] == len(matrix.LUA_FILES) == 884
assert receipt['changed_during_gate'] == []
assert matrix.source_snapshot() == manifest
assert matrix.snapshot_digest(manifest) == receipt['source_before'] == receipt['source_after']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == parent
for row, (name, command) in zip(receipt['results'], matrix.SUITES):
    assert row['name'] == name and row['command'] == command and row['returncode'] == 0
    assert json.loads((out / (row['log_prefix'] + '.json')).read_text()) == row
    for stream in ('stdout', 'stderr'):
        data = (out / (row['log_prefix'] + '.' + stream + '.txt')).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row[stream + '_sha256']
for path, digest in manifest.items():
    assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest

sys.path.insert(0, str(repo / 'tools'))
import install_vrmod
import runpy
upstream = install_vrmod.payload(install_vrmod.BUNDLE.read_bytes())
overlay = runpy.run_path(str(install_vrmod.OVERLAY))
installed = overlay['apply'](upstream)
mounted = {p: hashlib.sha256(data).hexdigest() for p, data in installed.items()
           if p.startswith('lua/') and p.endswith('.lua')}
assert len(mounted) == 139
assert all(installed[p] == data for p, data in upstream.items() if not p.startswith('lua/'))
gate = (root / 'vr-targeted-gate-final.log').read_text()
assert 'VR_GATE_PASS: 14 checks plus syntax' in gate
assert 'all proxies and held motion controllers retired' in gate
assert 'VR_IDLE_CLIENT_PASS 4800 idle frames' in gate

interrupted_attempts = []
for folder, reason in (
        ('vr-complete-matrix', 'Native held-prop motion controller outside hook/timer ownership.'),
        ('vr-complete-matrix-controllers', 'Dropped-NPC deletion must survive an intervening VR lifetime.')):
    interrupted = root / folder
    partial = []
    for path in sorted(interrupted.glob('*.json')):
        if path.name == 'source_manifest.json':
            continue
        row = json.loads(path.read_text())
        assert row['returncode'] == 0
        for stream in ('stdout', 'stderr'):
            data = (interrupted / (row['log_prefix'] + '.' + stream + '.txt')).read_bytes()
            assert hashlib.sha256(data).hexdigest() == row[stream + '_sha256']
        partial.append(row)
    interrupted_attempts.append({'folder': folder, 'completed': False, 'exit_code': 130,
                                 'completed_suites': len(partial), 'observed_failures': 0,
                                 'reason': reason + ' Interrupted, repaired and reran the complete frozen matrix.'})
(root / 'vr-interrupted-gate.json').write_text(json.dumps(interrupted_attempts, indent=2) + '\n')
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=repo, text=True).splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=repo, text=True).splitlines()
for path in sorted(set(changed)):
    target = out / 'changed-source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((repo / path).read_bytes())
proof = {k: receipt[k] for k in ('total', 'passed', 'lua_files', 'source_before', 'source_after', 'changed_during_gate')}
proof.update(parent_sha=parent, canonical_commands_verified=True,
             individual_receipts_verified=313, raw_stream_hashes_verified=626,
             frozen_source_hashes_verified=len(manifest), native_gmod_accepted=False,
             native_fps_gate_passed=False, native_idle_gate_accepted=False,
             overlay_version=overlay['VERSION'], upstream_revision=install_vrmod.REVISION,
             upstream_archive_sha256=install_vrmod.SHA256, non_lua_upstream_bytes_unchanged=True,
             mounted_addon_lua_sha256=mounted,
             bridge_sha256={p: manifest[p] for p in manifest if p.endswith(('/sh_vr.lua', '/cl_vr.lua'))},
             render_fingerprint_sources=10, population_fingerprint_sources=44,
             simulated_idle_frames_per_realm=4800, simulated_idle_vr_callbacks=0,
             simulated_idle_vr_recurring_timers=0, simulated_idle_server_player_scans=0,
             real_addon_proxy_and_pickup_lifecycle_bodies_tested=True,
             dropped_npc_cleanup_survives_new_vr_lifetime=True,
             native_engine_boundaries_doubled=True, interrupted_attempts=interrupted_attempts,
             production_sha256={p: h for p, h in manifest.items()
                                if (p.startswith(('gamemodes/', 'lua/')) and p.endswith('.lua'))
                                or p.startswith('third_party/vrmod-x64/deborah/')
                                or p in ('tools/install_dev.sh', 'tools/install_vrmod.py')})
(out / 'verification.json').write_text(json.dumps(proof, indent=2) + '\n')
archive = repo / 'docs/validation/STEAM_DECK_20261007_VR_IDLE_complete.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(out.rglob('*')):
        if path.is_file():
            z.write(path, 'matrix/' + path.relative_to(out).as_posix())
    for path in sorted(root.glob('vr-targeted-*.log')):
        z.write(path, 'targeted/' + path.name)
    for name in ('vr-complete-matrix-final.log', 'vr-complete-matrix.log', 'vr-complete-matrix-controllers.log',
                 'vr-interrupted-gate.json', 'finalize_vr_evidence.py'):
        z.write(root / name, 'evidence/' + name)
    for attempt in interrupted_attempts:
        interrupted = root / attempt['folder']
        for path in sorted(interrupted.rglob('*')):
            if path.is_file():
                z.write(path, 'interrupted-gate/' + attempt['folder'] + '/' + path.relative_to(interrupted).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    proof['archive_entries'] = len(z.infolist())
proof['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
proof['archive_bytes'] = archive.stat().st_size
(repo / 'docs/validation/STEAM_DECK_20261007_VR_IDLE_matrix.json').write_text(json.dumps(proof, indent=2) + '\n')
(root / 'vr-final-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: v for k, v in proof.items()
                  if k not in ('production_sha256', 'mounted_addon_lua_sha256', 'bridge_sha256')}, indent=2))
