"""Task-owned bounded native input for one explicitly focused Garry's Mod client.

This script sends ordinary keyboard/mouse input and captures the active game
window. It does not change game state, run console commands itself, or launch.
The request in /tmp/deborah-control-request.json is a JSON list (at most20
actions), or an explicit {"window":"decimal XID","actions":[...]} envelope.
List requests require exactly one visible client; explicit requests pin the
chosen visible exact-title window and its process identity for the input run.
A screenshot action may request persist=true for a durable copy in
this task's ignored .build directory.
"""
from pathlib import Path
import json
import math
import re
import shutil
import subprocess
import time

TASK_ROOT = Path('/home/deck/Downloads/the-legend-of-deborah/.build/autonomous-playtest-20261027')
REQUEST = Path('/tmp/deborah-control-request.json')


def call(parts, timeout=20):
    return subprocess.check_output(parts, text=True, timeout=timeout,
                                   stderr=subprocess.STDOUT).strip()


def run_raw_sequence(action, focused):
    """One native keyboard lifetime, with bounded hold/release steps."""
    steps = action['steps']
    allowed = set('wasderf') | {'space', 'Shift_L', 'Control_L', 'Up', 'Down',
        'Left', 'Right', 'q', 'm', 'p', 'i', 'o', 'l', 'grave', 'Escape'}
    assert isinstance(steps, list) and 1 <= len(steps) <= 12
    validated = []
    requested_keys = set()
    for step in steps:
        assert isinstance(step, dict)
        keys, seconds = step['keys'], step['seconds']
        assert isinstance(keys, list) and 0 <= len(keys) <= 4
        assert all(isinstance(key, str) and key in allowed for key in keys)
        assert len(set(keys)) == len(keys)
        assert isinstance(seconds, (int, float)) and not isinstance(seconds, bool)
        assert .01 <= seconds <= 2
        validated.append((set(keys), float(seconds)))
        requested_keys.update(keys)
    assert sum(seconds for _, seconds in validated) <= 10
    from evdev import UInput, ecodes as code
    keycodes = {key: getattr(code, 'KEY_' + key.upper()) for key in 'abcdefghijklmnopqrstuvwxyz'}
    keycodes.update(space=code.KEY_SPACE, Shift_L=code.KEY_LEFTSHIFT,
        Control_L=code.KEY_LEFTCTRL, Up=code.KEY_UP, Down=code.KEY_DOWN,
        Left=code.KEY_LEFT, Right=code.KEY_RIGHT, grave=code.KEY_GRAVE, Escape=code.KEY_ESC)
    with UInput({code.EV_KEY: list(set(keycodes.values()))},
                name='Deborah bounded playtest sequence') as device:
        held = set()
        try:
            time.sleep(.6)
            for wanted, seconds in validated:
                focused()
                for key in held - wanted:
                    device.write(code.EV_KEY, keycodes[key], 0)
                for key in wanted - held:
                    device.write(code.EV_KEY, keycodes[key], 1)
                device.syn()
                held = set(wanted)
                time.sleep(seconds)
        finally:
            # Include every planned key, even after a partial write or lost focus.
            errors = []
            for key in sorted(requested_keys):
                try:
                    device.write(code.EV_KEY, keycodes[key], 0)
                except Exception as error:
                    errors.append(error)
            try:
                device.syn()
            except Exception as error:
                errors.append(error)
            if errors:
                raise errors[0]
            time.sleep(.3)


def parse_request(request):
    if isinstance(request, list):
        actions, pinned = request, None
    else:
        assert isinstance(request, dict) and set(request) == {'window', 'actions'}, 'Expected an actions list or explicit window/actions envelope'
        actions, pinned = request['actions'], request['window']
        assert isinstance(pinned, str) and re.fullmatch(r'[1-9][0-9]{0,9}', pinned)
        assert int(pinned) < 2**32, 'Expected a canonical positive X11 window ID'
    assert isinstance(actions, list) and 0 < len(actions) <= 20
    return actions, pinned


def select_window(ids, pinned):
    assert len(set(ids)) == len(ids), 'Visible game window IDs must be unique'
    if pinned is None:
        assert len(ids) == 1, ('Expected exactly one visible GMod client', ids)
        return ids[0]
    assert ids.count(pinned) == 1, ('Pinned game window is not uniquely visible', pinned, ids)
    return pinned


def shell_numbers(text):
    fields = {}
    for line in text.splitlines():
        key, value = line.split('=', 1)
        assert re.fullmatch(r'[A-Z_]+', key) and re.fullmatch(r'-?[0-9]+', value)
        fields[key] = int(value)
    return fields


def placement(window):
    geometry = shell_numbers(call(['xdotool', 'getwindowgeometry', '--shell', window]))
    desktop = [int(value) for value in call(['xdotool', 'getdisplaygeometry']).split()]
    pointer = shell_numbers(call(['xdotool', 'getmouselocation', '--shell']))
    assert {'X', 'Y', 'WIDTH', 'HEIGHT'} <= set(geometry)
    assert {'X', 'Y'} <= set(pointer) and len(desktop) == 2 and min(desktop) > 0
    return {'window_geometry': geometry, 'reported_desktop': desktop, 'pointer': pointer,
            'full_window_within_reported_desktop': geometry['X'] >= 0 and geometry['Y'] >= 0
                and geometry['X'] + geometry['WIDTH'] <= desktop[0]
                and geometry['Y'] + geometry['HEIGHT'] <= desktop[1]}


def reachable_point(report, x=None, y=None):
    geometry, desktop, pointer = (report[key] for key in ('window_geometry', 'reported_desktop', 'pointer'))
    if x is None:
        x, y = pointer['X'] - geometry['X'], pointer['Y'] - geometry['Y']
    assert 0 <= x < geometry['WIDTH'] and 0 <= y < geometry['HEIGHT'], ('Pointer point is outside the game client', report, x, y)
    gx, gy = geometry['X'] + x, geometry['Y'] + y
    assert 0 <= gx < desktop[0] and 0 <= gy < desktop[1], (
        'Pointer point is outside reported desktop; move_window brings the client toward0,0', report, x, y)
    return gx, gy


def run_raw_click(action, focused):
    """One bounded native mouse-button lifetime; no pointer-motion writes."""
    button, seconds = action.get('button', 1), action.get('seconds', .15)
    assert type(button) is int and button in (1, 3)
    assert isinstance(seconds, (int, float)) and not isinstance(seconds, bool)
    assert math.isfinite(seconds) and .05 <= seconds <= 1
    from evdev import UInput, ecodes as code
    selected = code.BTN_LEFT if button == 1 else code.BTN_RIGHT
    # REL capabilities identify this as a mouse; this action emits no REL events.
    capabilities = {code.EV_KEY: [code.BTN_LEFT, code.BTN_RIGHT], code.EV_REL: [code.REL_X, code.REL_Y]}
    with UInput(capabilities, name='Deborah bounded native click') as device:
        try:
            time.sleep(.6)
            focused()
            device.write(code.EV_KEY, selected, 1)
            device.syn()
            time.sleep(float(seconds))
        finally:
            errors = []
            try:
                device.write(code.EV_KEY, selected, 0)
            except Exception as error:
                errors.append(error)
            try:
                device.syn()
            except Exception as error:
                errors.append(error)
            if errors:
                raise errors[0]
            time.sleep(.3)


def main():
    assert REQUEST.stat().st_size <= 65536, 'Request exceeds task limit'
    actions, pinned = parse_request(json.loads(REQUEST.read_text()))
    ids = call(['xdotool', 'search', '--onlyvisible', '--name', '^Garry.s Mod$']).splitlines()
    window = select_window(ids, pinned)
    assert call(['xdotool', 'getwindowname', window]) == "Garry's Mod"
    identity_pid = call(['xdotool', 'getwindowpid', window]) if pinned is not None else None
    if identity_pid is not None:
        assert re.fullmatch(r'[1-9][0-9]*', identity_pid), 'Pinned window has no native process identity'
    call(['xdotool', 'windowactivate', '--sync', window])

    def focused():
        assert call(['xdotool', 'getactivewindow']) == window, 'Focus changed; input stopped'
        if pinned is not None:
            current = call(['xdotool', 'search', '--onlyvisible', '--name', '^Garry.s Mod$']).splitlines()
            assert current.count(window) == 1, 'Pinned client is no longer uniquely visible'
            assert call(['xdotool', 'getwindowname', window]) == "Garry's Mod", 'Pinned window title changed'
            assert call(['xdotool', 'getwindowpid', window]) == identity_pid, 'Pinned window process identity changed'

    result = {'window': window, 'name': "Garry's Mod", 'actions': []}
    result['initial_placement'] = placement(window)
    if pinned is not None:
        result['window_pid'] = identity_pid
    focused()
    for action in actions:
        focused()
        kind = action['action']
        if kind == 'key':
            keys = action['keys']
            assert isinstance(keys, list) and 1 <= len(keys) <= 10
            assert all(re.fullmatch(r'[A-Za-z0-9_+]+', key) for key in keys)
            if keys == ['Return']:
                try:
                    call(['xdotool', 'keydown', '--clearmodifiers', 'Return'])
                    time.sleep(.13)
                finally:
                    call(['xdotool', 'keyup', 'Return'])
            else:
                call(['xdotool', 'key', '--clearmodifiers', *keys])
        elif kind == 'logical_hold':
            keys, seconds = action['keys'], float(action['seconds'])
            assert isinstance(keys, list) and 1 <= len(keys) <= 4 and 0 < seconds <= 2
            assert all(re.fullmatch(r'[A-Za-z0-9_+]+', key) for key in keys)
            try:
                call(['xdotool', 'keydown', '--clearmodifiers', *keys])
                time.sleep(seconds)
            finally:
                for key in keys:
                    call(['xdotool', 'keyup', key])
        elif kind == 'hold':
            keys, seconds = action['keys'], float(action['seconds'])
            allowed = set('wasderf') | {'space', 'Shift_L', 'Control_L', 'Up', 'Down',
                'Left', 'Right', 'q', 'm', 'p', 'i', 'o', 'l', 'grave', 'Escape'}
            assert isinstance(keys, list) and 1 <= len(keys) <= 4 and 0 < seconds <= 10
            assert len(set(keys)) == len(keys) and all(key in allowed for key in keys)
            from evdev import UInput, ecodes as code
            keycodes = {key: getattr(code, 'KEY_' + key.upper()) for key in 'abcdefghijklmnopqrstuvwxyz'}
            keycodes.update(space=code.KEY_SPACE, Shift_L=code.KEY_LEFTSHIFT,
                Control_L=code.KEY_LEFTCTRL, Up=code.KEY_UP, Down=code.KEY_DOWN,
                Left=code.KEY_LEFT, Right=code.KEY_RIGHT, grave=code.KEY_GRAVE, Escape=code.KEY_ESC)
            with UInput({code.EV_KEY: list(set(keycodes.values()))},
                        name='Deborah bounded playtest keyboard') as device:
                time.sleep(.6)
                focused()
                try:
                    for key in keys:
                        device.write(code.EV_KEY, keycodes[key], 1)
                    device.syn()
                    time.sleep(seconds)
                finally:
                    # Release every requested key even after a partial write.
                    errors = []
                    for key in keys:
                        try:
                            device.write(code.EV_KEY, keycodes[key], 0)
                        except Exception as error:
                            errors.append(error)
                    device.syn()
                    if errors:
                        raise errors[0]
                    time.sleep(.3)
        elif kind == 'raw_sequence':
            run_raw_sequence(action, focused)
        elif kind == 'raw_click':
            before = placement(window)
            reachable_point(before)
            run_raw_click(action, focused)
            result['actions'].append({'action': kind, 'placement_before': before, 'placement_after': placement(window)})
            continue
        elif kind == 'text':
            value = action['text']
            assert isinstance(value, str) and 0 < len(value) <= 6000 and '\n' not in value and '\r' not in value
            assert chr(96) not in value and '~' not in value, 'Source console toggle character in text'
            call(['xdotool', 'type', '--clearmodifiers', '--delay', '3', '--', value])
        elif kind == 'mouse':
            x, y = int(action['x']), int(action['y'])
            assert 0 <= x < 1280 and 0 <= y < 800
            before = placement(window)
            expected_x, expected_y = reachable_point(before, x, y)
            call(['xdotool', 'mousemove', '--window', window, str(x), str(y)])
            time.sleep(.05)
            after = placement(window)
            assert abs(after['pointer']['X'] - expected_x) <= 2 and abs(after['pointer']['Y'] - expected_y) <= 2, (
                'Pointer warp did not reach requested game coordinate', before, after, x, y)
            reachable_point(after)
            result['actions'].append({'action': kind, 'client_point': [x, y], 'placement_before': before, 'placement_after': after})
            continue
        elif kind == 'look':
            dx, dy = int(action['dx']), int(action['dy'])
            assert abs(dx) <= 2000 and abs(dy) <= 1000
            from evdev import UInput, ecodes as code
            with UInput({code.EV_KEY: [code.BTN_LEFT], code.EV_REL: [code.REL_X, code.REL_Y]},
                        name='Deborah bounded playtest mouse') as device:
                time.sleep(.5)
                focused()
                steps = max(1, math.ceil(max(abs(dx), abs(dy)) / 50))
                previous_x = previous_y = 0
                for index in range(1, steps + 1):
                    focused()
                    next_x, next_y = round(dx * index / steps), round(dy * index / steps)
                    device.write(code.EV_REL, code.REL_X, next_x - previous_x)
                    device.write(code.EV_REL, code.REL_Y, next_y - previous_y)
                    device.syn()
                    previous_x, previous_y = next_x, next_y
                    time.sleep(.06)
                time.sleep(.3)
        elif kind == 'click':
            button, count = int(action.get('button', 1)), int(action.get('count', 1))
            assert button in range(1, 8) and 1 <= count <= 20
            before = placement(window)
            reachable_point(before)
            if button in (1, 2, 3):
                for _ in range(count):
                    focused()
                    try:
                        call(['xdotool', 'mousedown', str(button)])
                        time.sleep(.15)
                    finally:
                        call(['xdotool', 'mouseup', str(button)])
                    time.sleep(.07)
            else:
                call(['xdotool', 'click', '--repeat', str(count), '--delay', '70', str(button)])
            result['actions'].append({'action': kind, 'placement_before': before, 'placement_after': placement(window)})
            continue
        elif kind == 'hold_mouse':
            button, seconds = int(action.get('button', 1)), float(action['seconds'])
            assert button in (1, 3) and 0 < seconds <= 4
            before = placement(window)
            reachable_point(before)
            try:
                call(['xdotool', 'mousedown', str(button)])
                time.sleep(seconds)
            finally:
                call(['xdotool', 'mouseup', str(button)])
            result['actions'].append({'action': kind, 'placement_before': before, 'placement_after': placement(window)})
            continue
        elif kind == 'wait':
            seconds = float(action['seconds'])
            assert 0 <= seconds <= 5
            time.sleep(seconds)
        elif kind == 'move_window':
            call(['xdotool', 'windowmove', window, '0', '0'])
            time.sleep(.1)
            result['actions'].append({'action': kind, 'placement_after': placement(window)})
            continue
        elif kind == 'screenshot':
            name = action['name']
            assert re.fullmatch(r'[a-zA-Z0-9_.-]+\.png', name)
            path = Path('/tmp') / name
            call(['spectacle', '-b', '-n', '-a', '-o', str(path)], timeout=30)
            assert path.is_file()
            entry = {'action': kind, 'path': str(path)}
            if action.get('persist') is True:
                destination = TASK_ROOT / 'screenshots' / (str(time.time_ns()) + '-' + name)
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, destination)
                entry['durable_copy'] = str(destination)
            result['actions'].append(entry)
            continue
        else:
            raise ValueError('Unsupported game action: ' + str(kind))
        result['actions'].append({'action': kind})
    print(json.dumps(result))


if __name__ == '__main__':
    main()
