"""Bounded native HID exploration using a reviewed read-only client observer.

Plans: {"path":[[x,y,z],...], "target_ids":[1,...], "seconds":20,
        "tolerance":48, "pause_for_targets":true, "face_route":true}
Set "visible_hostiles":true explicitly to engage only the observer's currently
visible ordinary hostiles. Default mode never attacks. No console or game-state
writes, no grants, teleportation, convars, server assertions or hidden targets.
"""
from pathlib import Path
import argparse
import fcntl
import json
import math
import signal
import subprocess
import time

ROOT = Path('/home/deck/Downloads/the-legend-of-deborah/.build/autonomous-playtest-20261027')
DATA = Path('/home/deck/.local/share/Steam/steamapps/common/GarrysMod/garrysmod/data/legend_of_deborah/native_pilot_latest.json')
FIREARMS = {'weapon_pistol', 'weapon_357', 'weapon_smg1', 'weapon_shotgun', 'weapon_ar2'}


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def vector(value):
    return isinstance(value, list) and len(value) == 3 and all(number(x) and abs(x) <= 32768 for x in value)


def validate_plan(plan):
    assert isinstance(plan, dict), 'Plan must be an object'
    assert not set(plan) - {'path', 'target_ids', 'visible_hostiles', 'seconds', 'tolerance', 'pause_for_targets', 'face_route'}, 'Unknown plan fields'
    path, targets = plan.get('path', []), plan.get('target_ids', [])
    dynamic = plan.get('visible_hostiles', False)
    assert type(dynamic) is bool
    assert isinstance(path, list) and len(path) <= 16 and all(vector(p) for p in path), 'Invalid reviewed route'
    assert isinstance(targets, list) and len(targets) <= 8 and len(set(targets)) == len(targets)
    assert all(type(x) is int and 0 < x < 8192 for x in targets), 'Invalid explicit target IDs'
    assert not (dynamic and targets), 'Choose dynamic visible hostiles or explicit IDs'
    assert path or targets or dynamic, 'Provide a route or explicit combat mode'
    seconds, tolerance = plan.get('seconds', 20), plan.get('tolerance', 48)
    assert number(seconds) and 0 < seconds <= 30, 'Runtime must be at most 30 seconds'
    assert number(tolerance) and 24 <= tolerance <= 64
    pause = plan.get('pause_for_targets', True)
    assert type(pause) is bool
    face_route = plan.get('face_route', True)
    assert type(face_route) is bool
    return path, set(targets), dynamic, seconds, tolerance, pause, face_route


def context(state):
    return tuple(state.get(k) for k in ('observer', 'epoch', 'world', 'body', 'body_creation', 'stage'))


def unavailable(state):
    if state.get('error'): return 'observer_error:' + str(state['error'])
    if state.get('alive') is not True or state['hp'] <= 0: return 'dead'
    if state.get('move_type') != 2: return 'not_movetype_walk'
    if state.get('staged') is not False or state.get('deployed') is not True: return 'not_deployed'
    if any(state.get(k) is True for k in ('ui_blocked', 'frozen', 'failed', 'level_cleared')): return 'ui_or_gameplay_unavailable'
    return None


def eligible_targets(state, explicit, dynamic):
    return [t for t in state.get('targets', []) if isinstance(t, dict)
            and type(t.get('id')) is int and 0 < t['id'] < 8192
            and type(t.get('creation')) is int and t['creation'] >= 0
            and (dynamic or t['id'] in explicit) and t.get('class') == 'lod_hostile'
            and t.get('visible') is True and t.get('alive') is True and vector(t.get('center'))]


def mouse_counts(state, yaw, pitch):
    mouse = state.get('mouse', {})
    sensitivity, yaw_unit, pitch_unit = (mouse.get(k) for k in ('sensitivity', 'yaw', 'pitch'))
    if mouse.get('rawinput') != 1 or not all(number(x) and abs(x) > .00001 for x in (sensitivity, yaw_unit, pitch_unit)):
        raise ValueError('raw_mouse_calibration_unavailable')
    dyaw = (yaw - state['ang'][1] + 180) % 360 - 180
    dpitch = (pitch - state['ang'][0] + 180) % 360 - 180
    return (max(-50, min(50, round(-dyaw / (sensitivity * yaw_unit)))),
            max(-40, min(40, round(dpitch / (sensitivity * pitch_unit)))), dyaw, dpitch)


def route_action(state, goal, face_route=True, enemy=False):
    """Face an already reviewed waypoint; a visible enemy keeps camera priority."""
    dx, dy = goal[0] - state['pos'][0], goal[1] - state['pos'][1]
    action = {'mouse': None, 'turning': False, 'aim_error': None, 'keys': set()}
    if face_route and not enemy:
        yaw = math.degrees(math.atan2(dy, dx))
        mx, my, dyaw, dpitch = mouse_counts(state, yaw, 0)
        action.update(mouse=(mx, my), turning=abs(dyaw) > 40 or abs(dpitch) > 20,
                      aim_error=max(abs(dyaw), abs(dpitch)))
        if action['turning']: return action
    facing = math.radians(state['ang'][1])
    forward = dx * math.cos(facing) + dy * math.sin(facing)
    right = dx * math.sin(facing) - dy * math.cos(facing)
    if abs(forward) > 20: action['keys'].add('w' if forward > 0 else 's')
    if abs(right) > 20: action['keys'].add('d' if right > 0 else 'a')
    return action


class AlignedMissSkips:
    """Skip a repeatedly aligned but non-contacting target for this run only."""
    def __init__(self):
        self.skipped, self.records = set(), []
        self.current, self.since = None, None

    def select(self, candidates, eye):
        available = [target for target in candidates if (target['id'], target['creation']) not in self.skipped]
        return min(available, key=lambda target: sum((a-b)**2 for a,b in zip(target['center'], eye)), default=None)

    def observe(self, target, aim_error, aim_entity, now):
        if target is None or aim_error > 2 or aim_entity == target['id']:
            self.current, self.since = None, None
            return False
        key = target['id'], target['creation']
        if self.current != key:
            self.current, self.since = key, now
            return False
        if now-self.since < 1:
            return False
        self.skipped.add(key)
        self.records.append({'id': target['id'], 'creation': target['creation'],
            'center': target['center'], 'aligned_miss_seconds': now-self.since,
            'aim_error': aim_error, 'aim_entity': aim_entity})
        self.current, self.since = None, None
        return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--telemetry', type=Path, default=DATA)
    parser.add_argument('--stop-file', type=Path, default=ROOT / 'native_pilot.stop')
    args = parser.parse_args()
    assert args.plan.stat().st_size <= 16384, 'Plan too large'
    path, target_ids, dynamic, seconds, tolerance, pause_targets, face_route = validate_plan(json.loads(args.plan.read_text()))
    ROOT.mkdir(parents=True, exist_ok=True)
    lock = (ROOT / 'native_pilot.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    prefix = ROOT / ('native-pilot-' + str(time.time_ns()))
    trace_path, result_path = prefix.with_suffix('.jsonl'), prefix.with_suffix('.result.json')
    started = time.monotonic()
    deadline = started + seconds
    interrupted = []
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda signum, frame: interrupted.append(signum))

    def command(parts):
        remaining = deadline - time.monotonic()
        if remaining <= 0: raise TimeoutError('Run budget exhausted')
        return subprocess.check_output(parts, text=True, stderr=subprocess.STDOUT, timeout=min(.5, remaining)).strip()

    def telemetry():
        for attempt in range(10):
            if time.monotonic() >= deadline: raise TimeoutError('Run budget exhausted during telemetry read')
            try:
                st = args.telemetry.stat()
                if not 0 <= time.time() - st.st_mtime <= .75 or st.st_size > 32768:
                    raise ValueError('Stale or oversized telemetry')
                state = json.loads(args.telemetry.read_text())
            except (json.JSONDecodeError, FileNotFoundError):
                if attempt == 9: raise
                time.sleep(min(.02, max(0, deadline - time.monotonic())))
                continue
            assert state.get('schema') == 2 and type(state.get('seq')) is int and state['seq'] > 0
            assert number(state.get('t')) and number(state.get('hp'))
            assert all(vector(state.get(k)) for k in ('pos', 'eye', 'ang'))
            assert isinstance(state.get('world'), str) and state['world']
            assert isinstance(state.get('observer'), str) and state['observer']
            assert all(type(state.get(k)) is int and state[k] >= 0 for k in ('epoch', 'body', 'body_creation', 'stage'))
            assert state['body'] > 0 and state['epoch'] > 0
            assert state.get('gamemode') == 'legend_of_deborah' and state.get('map') == 'gm_flatgrass'
            assert isinstance(state.get('targets'), list) and len(state['targets']) <= 8
            if dynamic: assert state.get('mode') == 'visible_hostiles', 'Observer dynamic mode was not explicitly installed'
            return state

    reason, frames, arrivals, triggers, reloads = 'not_started', 0, 0, 0, 0
    contacts = AlignedMissSkips()
    held, release_errors = set(), []
    last_state = initial_context = None
    try:
        if args.stop_file.exists(): reason = 'stop_file'; return
        ids = command(['xdotool', 'search', '--onlyvisible', '--name', '^Garry.s Mod$']).splitlines()
        assert len(ids) == 1, 'Exactly one visible GMod client required'
        wid = ids[0]
        assert command(['xdotool', 'getwindowname', wid]) == "Garry's Mod"
        assert command(['xdotool', 'getactivewindow']) == wid, 'GMod not focused'
        first = telemetry()
        initial_context = context(first)
        from evdev import UInput, ecodes as e
        codes = {'w': e.KEY_W, 'a': e.KEY_A, 's': e.KEY_S, 'd': e.KEY_D, 'r': e.KEY_R, 'fire': e.BTN_LEFT}
        caps = {e.EV_KEY: list(codes.values()), e.EV_REL: [e.REL_X, e.REL_Y]}
        with trace_path.open('x') as trace, UInput(caps, name='Deborah bounded native pilot') as device:
            def keys(wanted):
                for key in held - wanted: device.write(e.EV_KEY, codes[key], 0)
                for key in wanted - held: device.write(e.EV_KEY, codes[key], 1)
                device.syn()
                held.clear(); held.update(wanted)

            waypoint, best, last_progress = 0, math.inf, time.monotonic()
            fire_until = reload_until = next_fire = next_reload = 0
            fire_weapon = previous_target = last_seq = no_target_since = None
            best_aim, aim_progress_at = math.inf, time.monotonic()
            route_turn_best, route_turn_progress = math.inf, time.monotonic()
            pinned = {}
            try:
                time.sleep(min(.6, max(0, deadline - time.monotonic())))
                reason = 'timeout'
                while time.monotonic() < deadline:
                    now = time.monotonic()
                    if interrupted: reason = 'signal'; break
                    if args.stop_file.exists(): reason = 'stop_file'; break
                    if command(['xdotool', 'getactivewindow']) != wid: reason = 'focus_changed'; break
                    state = telemetry(); last_state = state
                    if context(state) != initial_context: reason = 'world_body_stage_or_observer_changed'; break
                    blocked = unavailable(state)
                    if blocked: reason = blocked; break
                    if state['seq'] == last_seq:
                        wanted = set(held)
                        if now >= fire_until: wanted.discard('fire')
                        if now >= reload_until: wanted.discard('r')
                        keys(wanted)
                        time.sleep(min(.04, max(0, deadline - time.monotonic())))
                        continue
                    if last_seq is not None and state['seq'] < last_seq: reason = 'observer_restarted'; break
                    last_seq = state['seq']; wanted = set()
                    candidates = eligible_targets(state, target_ids, dynamic)
                    for target in candidates:
                        prior = pinned.setdefault(target['id'], target['creation'])
                        if prior != target['creation']: raise ValueError('Target entity index reused')
                    candidate = contacts.select(candidates, state['eye'])
                    if candidate is None: contacts.observe(None, 0, -1, now)
                    aim_error, target_id, route_view = None, None, None
                    if candidate:
                        route_turn_best, route_turn_progress = math.inf, now
                        target_id = candidate['id']
                        delta = [a - b for a, b in zip(candidate['center'], state['eye'])]
                        yaw = math.degrees(math.atan2(delta[1], delta[0]))
                        pitch = -math.degrees(math.atan2(delta[2], math.hypot(delta[0], delta[1])))
                        dx, dy, dyaw, dpitch = mouse_counts(state, yaw, pitch)
                        aim_error = max(abs(dyaw), abs(dpitch))
                        if target_id != previous_target: best_aim, aim_progress_at = math.inf, now
                        if aim_error <= 2 or aim_error < best_aim - .5: best_aim, aim_progress_at = aim_error, now
                        elif now - aim_progress_at > 3: reason = 'aim_no_progress'; break
                        if dx or dy:
                            device.write(e.EV_REL, e.REL_X, dx); device.write(e.EV_REL, e.REL_Y, dy); device.syn()
                        weapon = state.get('weapon', {})
                        owned = weapon.get('owned') is True and weapon.get('class') in FIREARMS
                        if not owned: reason = 'no_owned_supported_firearm'; break
                        clip, reserve = weapon.get('clip'), weapon.get('reserve')
                        assert number(clip) and number(reserve) and number(weapon.get('next_primary'))
                        if clip <= 0 and reserve <= 0: reason = 'out_of_ammunition'; break
                        aim_hits = state.get('aim_entity') == target_id
                        if contacts.observe(candidate, aim_error, state.get('aim_entity'), now):
                            # Do not remove the aim-hit guard or aim through cover.
                            # Release this sample; choose another currently visible
                            # body or resume the reviewed route on the next sample.
                            keys(set()); fire_until = reload_until = 0
                            previous_target = None
                            trace.write(json.dumps({'event': 'aligned_target_without_native_hit_skipped',
                                'elapsed': round(now-started, 3), 'seq': state['seq'], 'pos': state['pos'],
                                'hp': state['hp'], 'target': target_id, 'skip': contacts.records[-1]})+'\n')
                            trace.flush(); frames += 1
                            time.sleep(min(.08, max(0, deadline-time.monotonic())))
                            continue
                        if clip > 0 and aim_error <= 2 and aim_hits and now >= next_fire and state['t'] >= weapon['next_primary']:
                            fire_until, next_fire, fire_weapon = now + .15, now + .32, weapon.get('id')
                            triggers += 1
                        if clip == 0 and reserve > 0 and now >= next_reload:
                            reload_until, next_reload = now + .15, now + 1.5; reloads += 1
                        if clip > 0 and aim_hits and aim_error <= 2 and now < fire_until and weapon.get('id') == fire_weapon: wanted.add('fire')
                        if now < reload_until: wanted.add('r')
                        no_target_since = None
                    elif not path:
                        no_target_since = no_target_since or now
                        if now - no_target_since > 1:
                            reason = 'no_unskipped_visible_target' if contacts.records and candidates else 'no_visible_approved_target'
                            break
                    previous_target = target_id
                    if path:
                        goal = path[waypoint]
                        dx, dy = goal[0] - state['pos'][0], goal[1] - state['pos'][1]
                        distance = math.hypot(dx, dy)
                        if distance <= tolerance:
                            if abs(goal[2] - state['pos'][2]) > 90: reason = 'waypoint_height_mismatch'; break
                            waypoint += 1; arrivals += 1
                            if waypoint == len(path): reason = 'path_complete'; break
                            best, last_progress = math.inf, now
                            route_turn_best, route_turn_progress = math.inf, now
                        elif candidate and pause_targets:
                            last_progress = now
                        else:
                            route_view = route_action(state, goal, face_route, enemy=candidate is not None)
                            if route_view['mouse'] is not None:
                                mx, my = route_view['mouse']
                                if mx or my:
                                    device.write(e.EV_REL, e.REL_X, mx); device.write(e.EV_REL, e.REL_Y, my); device.syn()
                            if route_view['turning']:
                                error = route_view['aim_error']
                                if error < route_turn_best - .5: route_turn_best, route_turn_progress = error, now
                                elif now - route_turn_progress > 2.5: reason = 'route_turn_no_progress'; break
                                # Exclude verified camera alignment from the movement-stall
                                # timer. The original absolute run deadline never changes.
                                last_progress = now
                            else:
                                route_turn_best, route_turn_progress = math.inf, now
                                if distance < best - 8: best, last_progress = distance, now
                                if now - last_progress > 2.5: reason = 'movement_no_progress'; break
                                wanted.update(route_view['keys'])
                    keys(wanted)
                    trace.write(json.dumps({'elapsed': round(now - started, 3), 'seq': state['seq'], 'pos': state['pos'],
                        'ang': state['ang'], 'hp': state['hp'], 'waypoint': waypoint, 'keys': sorted(wanted),
                        'target': target_id, 'aim_error': aim_error, 'aim_entity': state.get('aim_entity'), 'weapon': state.get('weapon', {}),
                        'route_turning': route_view['turning'] if route_view else False,
                        'route_aim_error': route_view['aim_error'] if route_view else None,
                        'visible_approved': [t['id'] for t in candidates]}) + '\n')
                    trace.flush(); frames += 1
                    time.sleep(min(.08, max(0, deadline - time.monotonic())))
            finally:
                for key, code in codes.items():
                    try: device.write(e.EV_KEY, code, 0)
                    except Exception as exc: release_errors.append({'key': key, 'error': type(exc).__name__ + ': ' + str(exc)})
                try: device.syn()
                except Exception as exc: release_errors.append({'key': 'SYN', 'error': type(exc).__name__ + ': ' + str(exc)})
                if not release_errors: held.clear()
                else: reason += '; release_errors'
    except Exception as exc:
        reason = type(exc).__name__ + ': ' + str(exc)
    finally:
        result = {'kind': 'assisted_native_exploration', 'reason': reason, 'seconds': round(time.monotonic() - started, 3),
            'frames': frames, 'waypoints_reached': arrivals, 'trigger_presses': triggers, 'reload_presses': reloads,
            'last_hp': last_state.get('hp') if last_state else None, 'initial_context': initial_context,
            'skipped_targets': contacts.records,
            'trace': str(trace_path), 'held_at_end': sorted(held), 'release_errors': release_errors, 'result': str(result_path)}
        result_path.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result)); lock.close()


if __name__ == '__main__':
    main()
