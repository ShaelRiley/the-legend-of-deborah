-- One-shot read-only existence/visibility oracle; never selects or changes loot.
assert(util.CRC(file.Read("gamemodes/legend_of_deborah/gamemode/lod/sh_near_look.lua", "GAME")) == "84557611", "wrong source18 NearLook")
local realm = SERVER and "server" or "client"
local p = SERVER and player.GetHumans()[1] or LocalPlayer()
assert(IsValid(p), "real player unavailable")
local function vec(v) return {v.x, v.y, v.z} end
local function entity(e)
    if not IsValid(e) then return {valid = false} end
    local r = {valid = true, id = e:EntIndex(), birth = e:GetCreationID(), class = e:GetClass(),
        pos = vec(e:GetPos()), center = vec(e:WorldSpaceCenter()), noDraw = e:GetNoDraw(),
        lootName = e:GetNW2String("LOD_LootName", ""), solid = e:GetSolid()}
    if e.GetOpened then r.opened = e:GetOpened() end
    if e.GetGateIndex then r.gateIndex = e:GetGateIndex() end
    return r
end
local anchor = Vector(-2620,3072,-12229.96875)
local health, distance, names = nil, nil, {}
for _, e in ipairs(ents.FindByClass("lod_loot_pickup")) do
    local d = e:WorldSpaceCenter():DistToSqr(anchor)
    if d <= 96 * 96 then
        names[#names + 1] = {id = e:EntIndex(), name = e:GetNW2String("LOD_LootName", ""), distanceSquared = d}
        if e:GetNW2String("LOD_LootName", "") == "Health" and (not distance or d < distance) then health, distance = e, d end
    end
end
local gate, gateDistance
for _, e in ipairs(ents.FindByClass("lod_gate")) do
    if e.GetGateIndex and e:GetGateIndex() == 1 then
        local d = e:GetPos():DistToSqr(Vector(-2880,3072,-12079.96875))
        if not gateDistance or d < gateDistance then gate, gateDistance = e, d end
    end
end
local state = SERVER and LOD.RunManager.State or LOD.ClientState
local cards, gates = SERVER and state.Cards or state.cards, SERVER and state.GatesOpen or state.gates
local result = {kind = "source18_independent_Health_existence_sight_oracle", realm = realm,
    at = SysTime(), sourceCRC = "84557611", map = game.GetMap(),
    health = entity(health), originalHealthAnchor = vec(anchor), candidatesNearAnchor = names,
    redGate = entity(gate), eye = vec(p:EyePos()), alive = p:Alive(), playerHP = p:Health(),
    cards = {}, gates = {}, qualification = "Independent class/name/position lookup; no cached HUD target is forced and no entity, pickup, gate or player state is changed."}
for i = 1,4 do
    result.cards[i] = cards[i] == true
    result.gates[i] = gates[i] == true
end
if IsValid(health) then
    result.healthVisible = LOD.NearLook:Visible(p, health)
    result.healthQualifies512 = LOD.NearLook:Qualifies(p, health, 512)
    result.healthDistanceSquared = p:EyePos():DistToSqr(health:WorldSpaceCenter())
end
if CLIENT then
    local fn = hook.GetTable().HUDPaint and hook.GetTable().HUDPaint.LOD_EquipmentComparison
    result.cachedHUDSelectionReadable = false
    if type(fn) == "function" then
        for i = 1, debug.getinfo(fn, "u").nups do
            local name, value = debug.getupvalue(fn, i)
            if name == "target" then
                result.cachedHUDSelectionReadable = true
                result.cachedHUDTarget = entity(value)
                break
            end
        end
    end
end
LODNativeSight18OracleSerial = (LODNativeSight18OracleSerial or 0) + 1
local text = util.TableToJSON(result, true)
local base = "legend_of_deborah/source18_health_sight_oracle_" .. realm
file.Write(base .. "_" .. LODNativeSight18OracleSerial .. "_" .. math.floor(SysTime()*1000) .. ".json", text)
file.Write(base .. "_latest.json", text)
print("SOURCE18_HEALTH_SIGHT_ORACLE=" .. util.TableToJSON(result))
