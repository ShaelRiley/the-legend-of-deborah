-- Optional, explicitly unranked native sight fixture. No route traversal claim.
-- Moves only the current Hero through SafeTeleport; never grants/uses/removes loot.
assert(SERVER and GetConVar("lod_developer_mode"):GetBool(),"private developer server required")
assert(util.CRC(file.Read("gamemodes/legend_of_deborah/gamemode/lod/sv_safe_teleport.lua","GAME"))=="377454284","wrong SafeTeleport source")
local T,N,R=LOD.SafeTeleport,LOD.MazeNavigator,LOD.RunManager
local s=R.State local g=assert(s.Graph) local pc=LOD.Config.Progression
assert(s.CampaignSeed==6102602 and s.Ranked==false,"expected already-unranked campaign6102602")
local humans=player.GetHumans() assert(#humans==1,"sole real client required")
local p=humans[1] local b=assert(T:Bind(p),"current living deployed Hero required")
assert(not s.Failed and not s.LevelCleared and not s.Cards[1] and not s.GatesOpen[1],"fresh closed Red gate required")
local m=assert(g.Progression.Gates[1]) local gate=assert(m.entity)
assert(IsValid(gate) and gate:GetClass()=="lod_gate" and gate:GetGateIndex()==1 and not gate:GetOpened(),"actual closed Red gate required")
local function key(c) return LOD.MazeGenerator.CellKey(c.x,c.y,c.z) end
assert(key(m.beforeCell)=="3:19:0" and key(m.afterCell)=="4:19:0","current layout differs; inspect before moving")
local before=assert(g.Cells[key(m.beforeCell)]) local after=assert(g.Cells[key(m.afterCell)])
local a,z=N:CellCenter(before),N:CellCenter(after)
assert(math.abs(gate:GetPos().x+2880)<2 and math.abs(gate:GetPos().y-3072)<2,"unexpected native Red gate position")
local home,angles=p:GetPos(),p:EyeAngles()
local hc=assert(T:CellAt(g,home)) local homeLanding=assert(T:Landing(p,g,hc,home),"safe return anchor unavailable")
local path=assert(N:FindPath(g,hc,before),"no currently unlocked route to accessible Red-gate side")
local cards,gates={},{} for i=1,4 do cards[i]=s.Cards[i]==true gates[i]=s.GatesOpen[i]==true end
local function current()
    if not T:Matches(b) or R.State~=s or s.Graph~=g or s.CampaignSeed~=6102602
        or g.Progression.Gates[1]~=m or m.entity~=gate or not IsValid(gate) or gate:GetOpened() then return false end
    for i=1,4 do if (s.Cards[i]==true)~=cards[i] or (s.GatesOpen[i]==true)~=gates[i] then return false end end
    for i=2,#path do if not N:CanTraverse(g,key(path[i-1]),key(path[i])) then return false end end
    return p:GetPos():DistToSqr(home)<1
end
local function pickupClear(dest)
    local lo,hi=p:GetHull() local radius=(pc.KeycardTriggerRadius or 52)+8
    for _,class in ipairs({"lod_keycard","lod_floor_map","lod_jail_key"}) do
        for _,e in ipairs(ents.FindByClass(class)) do
            local v=e.GetPickupPosition and e:GetPickupPosition() or e:GetPos()
            local q=Vector(math.Clamp(v.x,dest.x+lo.x,dest.x+hi.x),math.Clamp(v.y,dest.y+lo.y,dest.y+hi.y),math.Clamp(v.z,dest.z+lo.z,dest.z+hi.z))
            if q:DistToSqr(v)<=radius*radius then return false end
        end
    end
    for _,e in ipairs(ents.FindInBox(dest+lo-Vector(8,8,8),dest+hi+Vector(8,8,8))) do
        if e:GetClass()=="lod_loot_pickup" then return false end
    end
    return true
end
local direction=(a-z):GetNormalized() local destination,distance
for _,d in ipairs({160,128}) do
    local v=gate:GetPos()+direction*d v.z=a.z
    local valid=T:Landing(p,g,before,v)
    if valid and pickupClear(valid) then destination,distance=valid,d break end
end
assert(destination,"both160/128 positions fail standing support, clearance or pickup guard")
assert(current(),"world/life/lock changed before move")
local moved,detail=T:MoveBound(b,destination,current,before)
local function vec(v) return {v.x,v.y,v.z} end
local r={kind="explicit_source17_closed_red_gate_sight_setup",at=SysTime(),campaign=s.CampaignSeed,
    level_seed=s.LevelSeed,graph_tostring=tostring(g),spawn=b.spawn,life=tostring(b.life),
    gate_id=gate:EntIndex(),gate_creation=gate:GetCreationID(),gate_open=gate:GetOpened(),
    before_cell=key(before),after_cell=key(after),home=vec(home),destination=vec(destination),
    offset_from_gate=distance,graph_route_cells=#path,move_accepted=moved,move_detail=tostring(detail),
    qualification="Unranked optional relocation, not ordinary route traversal. No card/gate/loot/HP/class changes; no pickup or label is selected or forced."}
if moved and T:Matches(b) and not gate:GetOpened() then
    local reader=gate:GetPos()+direction*(pc.GateThickness*.5+15)+Vector(0,0,-pc.GateBlockerHeight*.5+62)
    p:SetEyeAngles((reader-p:EyePos()):Angle()) r.reader_aim=vec(reader)
end
RED17GATE={binding=b,home=homeLanding,homeCell=hc,angles=angles,setup=r}
function RED17GATE:Return()
    if not T:Matches(self.binding) then return false,"Hero or run changed" end
    local now=T:CellAt(g,p:GetPos())
    local route=now and N:FindPath(g,now,self.homeCell)
    if not route or not pickupClear(self.home) then return false,"return route locked or pickup at home" end
    local function owned()
        if not T:Matches(self.binding) or R.State~=s or s.Graph~=g then return false end
        for i=2,#route do if not N:CanTraverse(g,key(route[i-1]),key(route[i])) then return false end end
        return true
    end
    local ok,why=T:MoveBound(self.binding,self.home,owned,self.homeCell)
    if ok and owned() then p:SetEyeAngles(self.angles) end
    return ok,why
end
local text=util.TableToJSON(r,true)
file.Write("legend_of_deborah/source17_red_gate_sight_setup.json",text)
print("RED17_GATE_SIGHT="..util.TableToJSON(r))
