-- Optional setup only: stand96 units before the actual Redcard, then return.
-- Collection and gate opening require ordinary player actions; no route proof.
assert(SERVER and GetConVar("lod_developer_mode"):GetBool(), "private server fixture only")
assert(util.CRC(file.Read("gamemodes/legend_of_deborah/gamemode/lod/sv_safe_teleport.lua", "GAME")) == "377454284", "wrong SafeTeleport source")
assert(util.CRC(file.Read("gamemodes/legend_of_deborah/gamemode/lod/sh_near_look.lua", "GAME")) == "84557611", "wrong source18 NearLook")
assert(not LODNativeRedcard18Approach, "archive previous approach before another setup")
local T, N, R = LOD.SafeTeleport, LOD.MazeNavigator, LOD.RunManager
local s, g, pc = R.State, R.State.Graph, LOD.Config.Progression
assert(s.CampaignSeed == 6102602 and s.Ranked == false and g, "expected existing unranked6102602")
local humans = player.GetHumans(); assert(#humans == 1, "one actual client required")
local p = humans[1]
local binding = assert(T:Bind(p), "living deployed Hero required")
local function key(c) return LOD.MazeGenerator.CellKey(c.x,c.y,c.z) end
local function vec(v) return {v.x,v.y,v.z} end
local function flags(values) local r = {} for i = 1,4 do r[i] = values[i] == true end return r end
local meta = assert(g.Progression.Keycards[1], "no Redcard metadata")
local card = assert(meta.entity, "no actual Redcard entity")
local gateMeta = assert(g.Progression.Gates[1], "no actual Redgate metadata")
local gate = assert(gateMeta.entity, "no actual Redgate entity")
assert(key(meta.cell) == "1:21:0" and IsValid(card) and card:GetClass() == "lod_keycard" and card:GetCardIndex() == 1, "actual Redcard/layout changed")
assert(IsValid(gate) and not gate:GetOpened() and not s.Cards[1] and not s.GatesOpen[1], "perform closed-gate baseline before this optional setup")
local cardBirth, gateBirth = card:GetCreationID(), gate:GetCreationID()
local home = Vector(p:GetPos().x,p:GetPos().y,p:GetPos().z)
local angles = p:EyeAngles()
local homeCell = assert(T:CellAt(g, home), "no exact home cell")
assert(key(homeCell) == key(gateMeta.beforeCell), "start from the recorded accessible before-gate pose")
local homeLanding = assert(T:Landing(p,g,homeCell,home), "home support/standing hull is unsafe")
local cardCell = assert(g.Cells[key(meta.cell)])
local path = assert(N:FindPath(g,homeCell,cardCell), "no currently unlocked route to actual Redcard")
assert(#path > 0, "empty unlocked route")
local epoch, seed = s.CampaignEpoch, s.LevelSeed
local beforeCards, beforeGates = flags(s.Cards), flags(s.GatesOpen)
local function scope()
    return T:Matches(binding) and R.State == s and s.Graph == g
        and s.CampaignEpoch == epoch and s.LevelSeed == seed and s.CampaignSeed == 6102602
end
local function legal(route)
    for i = 2,#route do if not N:CanTraverse(g,key(route[i-1]),key(route[i])) then return false end end
    return true
end
local function pickupClear(dest)
    local lo, hi = p:GetHull()
    local radius = pc.KeycardTriggerRadius + 8
    for _, class in ipairs({"lod_keycard","lod_floor_map","lod_jail_key"}) do
        for _, e in ipairs(ents.FindByClass(class)) do
            local v = e.GetPickupPosition and e:GetPickupPosition() or e:GetPos()
            local q = Vector(math.Clamp(v.x,dest.x+lo.x,dest.x+hi.x),math.Clamp(v.y,dest.y+lo.y,dest.y+hi.y),math.Clamp(v.z,dest.z+lo.z,dest.z+hi.z))
            if q:DistToSqr(v) <= radius*radius then return false end
        end
    end
    for _, e in ipairs(ents.FindInBox(dest+lo-Vector(24,24,24),dest+hi+Vector(24,24,24))) do
        if e:GetClass() == "lod_loot_pickup" then return false end
    end
    return true
end
local function current()
    if not scope() or not IsValid(card) or card:GetCreationID() ~= cardBirth or meta.entity ~= card
        or not IsValid(gate) or gate:GetCreationID() ~= gateBirth or gate:GetOpened()
        or g.Progression.Keycards[1] ~= meta or g.Progression.Gates[1] ~= gateMeta or not legal(path)
        or p:GetPos():DistToSqr(home) >= 1 then return false end
    for i = 1,4 do
        if (s.Cards[i] == true) ~= beforeCards[i] or (s.GatesOpen[i] == true) ~= beforeGates[i] then return false end
    end
    return true
end
local anchor = card:GetPickupPosition()
local previous = #path > 1 and N:CellCenter(path[#path-1]) or home
local direction = previous - N:CellCenter(cardCell); direction.z = 0
if direction:LengthSqr() == 0 then direction = Vector(1,0,0) else direction = direction:GetNormalized() end
local side = Vector(-direction.y,direction.x,0)
local dest
for _, offset in ipairs({direction*96,side*96,side*-96,direction*-96}) do
    local request = anchor + offset; request.z = N:CellCenter(cardCell).z
    local landing = T:Landing(p,g,cardCell,request)
    if landing and pickupClear(landing) then dest = landing break end
end
local output = "legend_of_deborah/source18_redcard_approach_latest.json"
assert(not file.Exists(output,"DATA"), "archive existing approach result first")
local result = {kind = "explicit_source18_Redcard_approach", started = SysTime(), duration = 8,
    heroSpawn = binding.spawn, home = vec(home), homeCell = key(homeCell), cardCell = key(cardCell),
    cardId = card:EntIndex(), cardBirth = cardBirth, cardAnchor = vec(anchor),
    gateId = gate:EntIndex(), gateBirth = gateBirth, unlockedRouteCells = #path,
    cardsBefore = beforeCards, gatesBefore = beforeGates, HPBefore = p:Health(),
    qualification = "Canonical Hero setup96 units from real Redcard with pickup-clear standing hull. Root must use ordinary movement/touch. No grant/CollectCard/gate opening/item/class/HP/lock edit; traversal unaccepted."}
if not dest then
    result.setupRejected = "No pickup-clear supported96-unit approach among four candidates"
    file.Write(output,util.TableToJSON(result,true)); print("SOURCE18_REDCARD_APPROACH=" .. util.TableToJSON(result))
    return
end
result.destination = vec(dest)
LODNativeRedcard18Approach = result
local finished = false
local function back()
    if finished then return end
    finished = true
    result.sameHeroAtReturn = scope()
    if result.sameHeroAtReturn then
        local now = T:CellAt(g,p:GetPos())
        local route = now and N:FindPath(g,now,homeCell)
        if route and legal(route) and pickupClear(homeLanding) then
            result.returnAccepted, result.returnDetail = T:MoveBound(binding,homeLanding,function() return scope() and legal(route) end,homeCell)
            result.returnDetail = tostring(result.returnDetail)
            if result.returnAccepted and scope() then p:SetEyeAngles(angles) end
        else result.returnRejected = "return route or pickup-clear home changed" end
        result.returnedPosition, result.HPAfter = vec(p:GetPos()), p:Health()
    end
    result.cardStillExists = IsValid(card)
    result.recordedRunStillCurrent = R.State == s
    result.cardsAfter, result.gatesAfter = flags(s.Cards), flags(s.GatesOpen)
    result.gateStillExists, result.gateOpenedAfter = IsValid(gate), IsValid(gate) and gate:GetOpened() or false
    result.finished = SysTime()
    file.Write(output,util.TableToJSON(result,true)); print("SOURCE18_REDCARD_APPROACH=" .. util.TableToJSON(result))
end
timer.Simple(8,back) -- install the same-life return before any native movement
result.moveAccepted, result.moveDetail = T:MoveBound(binding,dest,current,cardCell)
result.moveDetail = tostring(result.moveDetail)
if not result.moveAccepted then back() return end
if scope() and IsValid(card) then p:SetEyeAngles((card:WorldSpaceCenter()-p:EyePos()):Angle()) end
file.Write(output,util.TableToJSON(result,true))
print("SOURCE18_REDCARD_APPROACH_STARTED=" .. util.TableToJSON(result))
