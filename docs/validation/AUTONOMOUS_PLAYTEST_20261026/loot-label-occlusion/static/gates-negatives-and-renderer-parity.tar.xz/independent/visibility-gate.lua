local mode = assert(arg[1])
local originalDofile = dofile
function dofile(path)
    if path == 'gamemodes/legend_of_deborah/gamemode/lod/sh_near_look.lua' then
        local filename = mode == 'original' and 'frozen-near-look.lua.txt'
            or mode == 'target-hit-mutant' and 'target-hit-mutant.lua.txt'
            or 'candidate-near-look.lua.txt'
        return originalDofile('.build/autonomous-playtest-20261027/bug018-independent-review/' .. filename)
    end
    return originalDofile(path)
end
originalDofile('tools/test_near_look_native_bounds.lua')
