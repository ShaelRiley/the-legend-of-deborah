-- Independent headless observation of actual production-generated transforms.
-- Only the requested renderer file can be replaced; all other source is current.
local mode, output = assert(arg[1]), assert(arg[2])
local originalDofile = dofile
local captured = {}
local handle = assert(io.open(output, 'w'))
local function number(n) return string.format('%.17g', n or 0) end
local function observe()
    local w = LOD and LOD.WallVisualsClient
    if not w or not w.world or #w.world == 0 or captured[w.seed]
        or not w.nextModel or w.nextModel <= #w.world or #w.retryQueue > 0 then return end
    captured[w.seed] = true
    handle:write('SEED\t', tostring(w.seed), '\tCOUNT\t', tostring(#w.world), '\n')
    for i, instance in ipairs(w.world) do
        local p, a, model = instance.pos, instance.ang, w.models[i]
        assert(IsValid(model) and model.pos == p and model.ang == a, 'native fixture transform mismatch')
        handle:write(table.concat({tostring(i), number(p.x), number(p.y), number(p.z),
            number(a.p), number(a.y), number(a.r), number(model.pos.x), number(model.pos.y),
            number(model.pos.z), number(model.ang.p), number(model.ang.y), number(model.ang.r)}, '\t'), '\n')
    end
end
function dofile(path)
    if path == 'gamemodes/legend_of_deborah/gamemode/lod/cl_wall_visuals.lua' then
        local add = hook.Add
        hook.Add = function(event, id, callback)
            if id == 'LOD_BuildProceduralContainerWalls' then
                return add(event, id, function(...)
                    local result = callback(...)
                    observe()
                    return result
                end)
            end
            return add(event, id, callback)
        end
        local value = originalDofile(mode == 'old' and
            '.build/autonomous-playtest-20261027/bug018-independent-review/frozen-wall-renderer.lua.txt' or path)
        hook.Add = add
        return value
    end
    return originalDofile(path)
end
originalDofile('tools/test_consult_wall_pool.lua')
for _, seed in ipairs({7,8,9,10,11}) do assert(captured[seed], 'missing actual production seed' .. seed) end
handle:close()
print('INDEPENDENT_WALL_TRANSFORMS_CAPTURED five production manifests; world and native-double transforms; no native FPS claim')
