local base=dofile
dofile=function(path) if path=="gamemodes/legend_of_deborah/gamemode/lod/sh_near_look.lua" then return assert(loadfile(".build/autonomous-playtest-20261027/bug018-near-look/original-sh_near_look.lua.txt"))() end return base(path) end
base("tools/test_near_look_native_bounds.lua")
