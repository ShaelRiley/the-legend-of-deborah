-- Mirror the client snapshot's exact frozen rays; read-only gameplay diagnostic.
assert(SERVER and GetConVar("lod_developer_mode"):GetBool(),"private developer server required")
local raw=assert(file.Read("legend_of_deborah/source16_pickup_sight_client_latest.json","DATA"),"client snapshot required")
local c=assert(util.JSONToTable(raw),"invalid client snapshot")
assert(c.kind=="source16_exact_production_pickup_target" and c.target and c.target.valid,"valid frozen client target required")
local function vec(v) return v and {v.x,v.y,v.z} end
local function vector(v) return Vector(v[1],v[2],v[3]) end
local function entity(e)
    if not IsValid(e) then return {valid=false} end
    local a,b=e:GetCollisionBounds()
    return {valid=true,id=e:EntIndex(),creation=e:GetCreationID(),class=e:GetClass(),model=e:GetModel(),
        pos=vec(e:GetPos()),center=vec(e:WorldSpaceCenter()),collision_mins=vec(a),collision_maxs=vec(b),
        solid=e:GetSolid(),solid_flags=e:GetSolidFlags(),collision_group=e:GetCollisionGroup(),
        box_kind=e.GetBoxKind and e:GetBoxKind() or nil,
        gate_index=e.GetGateIndex and e:GetGateIndex() or nil,
        gate_open=e.GetOpened and e:GetOpened(),loot_name=e:GetNW2String("LOD_LootName","")}
end
local p=Entity(c.player.id) local target=Entity(c.target.id)
assert(IsValid(p) and p:IsPlayer(),"snapshot player no longer valid")
local r={kind="source16_frozen_client_ray_server_mirror",at=SysTime(),client_history=c.history_file,
    client_snapshot_crc=util.CRC(raw),client_at=c.at,player=entity(p),target=entity(target),
    source_target=c.target,same_target_class=IsValid(target) and target:GetClass()==c.target.class,
    target_center_delta=IsValid(target) and target:WorldSpaceCenter():Distance(vector(c.target.center)) or nil,
    player_eye_delta=p:EyePos():Distance(vector(c.eye)),traces={},gates={}}
local b=vector(c.target.center)
for _,origin in ipairs({{"production_eye",c.eye},{"render_view",c.view and c.view.origin}}) do
    if origin[2] then
        for _,m in ipairs({{"VISIBLE",MASK_VISIBLE},{"SHOT",MASK_SHOT},{"SOLID",MASK_SOLID}}) do
            for _,hull in ipairs({false,true}) do
                local q={start=vector(origin[2]),endpos=b,filter=p,mask=m[2]}
                if hull then q.mins=Vector(-1,-1,-1) q.maxs=Vector(1,1,1) end
                local t=hull and util.TraceHull(q) or util.TraceLine(q)
                r.traces[#r.traces+1]={origin=origin[1],mask_name=m[1],mask=m[2],hull_half_size=hull and 1 or 0,
                    hit=t.Hit,start_solid=t.StartSolid,all_solid=t.AllSolid,fraction=t.Fraction,
                    hit_world=t.HitWorld,contents=t.Contents,hit_pos=vec(t.HitPos),normal=vec(t.HitNormal),entity=entity(t.Entity)}
            end
        end
    end
end
for _,g in ipairs(c.gates or {}) do r.gates[#r.gates+1]=entity(Entity(g.id)) end
local name="legend_of_deborah/source16_pickup_sight_server_"..tostring(SysTime()):gsub("[^%w]","_")..".json"
r.history_file=name
local text=util.TableToJSON(r,true) file.Write(name,text) file.Write("legend_of_deborah/source16_pickup_sight_server_latest.json",text)
print("PICKUP_SIGHT16_SERVER="..util.TableToJSON({file=name,target=r.target.id,same_class=r.same_target_class,target_delta=r.target_center_delta,eye_delta=r.player_eye_delta,gates=#r.gates}))
