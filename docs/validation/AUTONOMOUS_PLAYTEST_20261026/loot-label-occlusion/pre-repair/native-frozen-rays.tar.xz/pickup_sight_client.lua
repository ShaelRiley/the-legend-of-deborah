-- One-shot read-only diagnostic. No Find(), selection replacement or actor changes.
-- Root loads from the private DATA directory, then closes the console without moving.
assert(CLIENT and LOD and LOD.NearLook and LOD.Equipment, "client gameplay required")
local id, output = "DeborahPickupSight16", "legend_of_deborah/source16_pickup_sight_client_latest.json"
assert(not hook.GetTable().PostRender or not hook.GetTable().PostRender[id], "probe already armed")
local armed, expires = RealTime(), RealTime() + 12
local function vec(v) return v and {v.x,v.y,v.z} end
local function ang(v) return v and {v.p,v.y,v.r} end
local function upvalue(fn, wanted)
    if type(fn) ~= "function" then return nil, false end
    for n = 1, debug.getinfo(fn,"u").nups do
        local name, value = debug.getupvalue(fn,n)
        if name == wanted then return value, true end
    end
    return nil, false
end
local function entity(e)
    if not IsValid(e) then return {valid=false} end
    local a,b=e:GetCollisionBounds()
    local lo,hi=e:WorldSpaceAABB()
    return {valid=true,id=e:EntIndex(),creation=e:GetCreationID(),class=e:GetClass(),
        model=e:GetModel(),pos=vec(e:GetPos()),angles=ang(e:GetAngles()),center=vec(e:WorldSpaceCenter()),
        collision_mins=vec(a),collision_maxs=vec(b),world_mins=vec(lo),world_maxs=vec(hi),
        solid=e:GetSolid(),solid_flags=e:GetSolidFlags(),collision_group=e:GetCollisionGroup(),
        move_type=e:GetMoveType(),no_draw=e:GetNoDraw(),dormant=e:IsDormant(),
        box_kind=e.GetBoxKind and e:GetBoxKind() or nil,
        box_mins=e.GetBoxMins and vec(e:GetBoxMins()) or nil,
        box_maxs=e.GetBoxMaxs and vec(e:GetBoxMaxs()) or nil,
        gate_index=e.GetGateIndex and e:GetGateIndex() or nil,
        gate_axis=e.GetGateAxis and e:GetGateAxis() or nil,
        gate_open=e.GetOpened and e:GetOpened(),
        loot_name=e:GetNW2String("LOD_LootName","")}
end
local function trace(a,b,p,mask,hull)
    local q={start=a,endpos=b,filter=p,mask=mask}
    if hull then q.mins=Vector(-1,-1,-1) q.maxs=Vector(1,1,1) end
    local t=hull and util.TraceHull(q) or util.TraceLine(q)
    return {mask=mask,hull_half_size=hull and 1 or 0,hit=t.Hit,start_solid=t.StartSolid,
        all_solid=t.AllSolid,fraction=t.Fraction,fraction_left_solid=t.FractionLeftSolid,
        hit_world=t.HitWorld,contents=t.Contents,hit_pos=vec(t.HitPos),normal=vec(t.HitNormal),
        material=t.MatType,texture=t.HitTexture,entity=entity(t.Entity)}
end
local function source(fn)
    local d=type(fn)=="function" and debug.getinfo(fn,"Su") or nil
    return d and {path=d.short_src,line=d.linedefined,upvalues=d.nups} or nil
end
local function capture()
    local p=LocalPlayer()
    if not IsValid(p) then return {error="invalid_local_player"} end
    local fn=hook.GetTable().HUDPaint and hook.GetTable().HUDPaint.LOD_EquipmentComparison
    local target,found=upvalue(fn,"target")
    local cache,cacheFound=upvalue(LOD.Equipment.PickupNameLayout,"nameCache")
    local scan=upvalue(fn,"nextScan")
    local view=render.GetViewSetup(false)
    local r={kind="source16_exact_production_pickup_target",at=RealTime(),cur_time=CurTime(),
        frame=FrameNumber(),map=game.GetMap(),production_hook=source(fn),near_look=source(LOD.NearLook.Visible),
        selection_upvalue_found=found,layout_upvalue_found=cacheFound,next_scan=scan,
        player=entity(p),alive=p:Alive(),noclip=p:GetMoveType()==MOVETYPE_NOCLIP,
        eye=vec(p:EyePos()),eye_angles=ang(p:EyeAngles()),active_page=tostring(LOD.UI.ActivePage),
        target=entity(target),console_visible=gui.IsConsoleVisible(),
        game_ui_visible=gui.IsGameUIVisible(),qualification="Snapshot of production closure and cached layout; pair with actual screenshot. No draw call is replaced or instrumented.",
        view=view and {source="render.GetViewSetup(false) at PostRender",origin=vec(view.origin),
            angles=ang(view.angles),fov=view.fov,width=view.width,height=view.height,
            view_id=view.viewid,draw_local_player=p:ShouldDrawLocalPlayer(),view_entity=entity(p:GetViewEntity())} or nil,
        traces={},gates={},cvars={},source_crc={}}
    for _,path in ipairs({"gamemodes/legend_of_deborah/gamemode/lod/sh_near_look.lua",
        "gamemodes/legend_of_deborah/gamemode/lod/cl_equipment.lua",
        "gamemodes/legend_of_deborah/gamemode/lod/sv_safe_teleport.lua"}) do
        local bytes=file.Read(path,"GAME") r.source_crc[path]=bytes and util.CRC(bytes) or "unavailable"
    end
    for _,name in ipairs({"cl_drawhud","r_drawvgui","lod_third_person","lod_developer_mode"}) do
        local c=GetConVar(name) r.cvars[name]=c and c:GetString() or "absent"
    end
    if cacheFound and cache then
        r.cached_layout={target=entity(cache.entity),name=cache.name,width=cache.width,lines=cache.lines,
            matches_target=cache.entity==target}
    end
    if not found then r.error="production_target_upvalue_unavailable" return r end
    if not IsValid(target) then r.error="production_target_invalid" return r end
    r.qualifies=LOD.NearLook:Qualifies(p,target,512) and true or false
    r.would_draw=p:Alive() and not LOD.UI.ActivePage and r.qualifies and r.target.loot_name~=""
    local a,b=p:EyePos(),target:WorldSpaceCenter()
    for _,m in ipairs({{"VISIBLE",MASK_VISIBLE},{"SHOT",MASK_SHOT},{"SOLID",MASK_SOLID}}) do
        r.traces[#r.traces+1]={origin="production_eye",mask_name=m[1],line=trace(a,b,p,m[2],false),hull=trace(a,b,p,m[2],true)}
        if view and view.origin then
            r.traces[#r.traces+1]={origin="render_view",mask_name=m[1],line=trace(view.origin,b,p,m[2],false),hull=trace(view.origin,b,p,m[2],true)}
        end
    end
    for _,g in ipairs(ents.FindByClass("lod_gate")) do
        if g:GetPos():DistToSqr(a)<=768*768 then
            local row=entity(g) local lo,hi=g:GetCollisionBounds()
            local hit,normal,fraction=util.IntersectRayWithOBB(a,b-a,g:GetPos(),g:GetAngles(),lo,hi)
            row.eye_segment_obb_hit=hit~=nil row.eye_segment_obb_fraction=fraction
            row.eye_segment_obb_pos=vec(hit) row.eye_segment_obb_normal=vec(normal)
            r.gates[#r.gates+1]=row
        end
    end
    table.sort(r.gates,function(a,b) return a.id<b.id end)
    return r
end
local function finish(r)
    hook.Remove("PostRender",id)
    r.armed_at=armed r.probe_finished_at=RealTime()
    local name="legend_of_deborah/source16_pickup_sight_client_"..tostring(SysTime()):gsub("[^%w]","_")..".json"
    r.history_file=name
    local text=util.TableToJSON(r,true) file.Write(name,text) file.Write(output,text)
    print("PICKUP_SIGHT16="..util.TableToJSON({file=name,error=r.error,target=r.target and r.target.id,
        name=r.target and r.target.loot_name,would_draw=r.would_draw,qualifies=r.qualifies,gates=r.gates and #r.gates}))
end
hook.Add("PostRender",id,function()
    if RealTime()>expires then finish({kind="source16_pickup_sight_timeout",error="console_or_game_ui_not_closed_within_12s"}) return end
    if gui.IsConsoleVisible() or gui.IsGameUIVisible() or RealTime()-armed<.35 then return end
    local ok,result=pcall(capture)
    finish(ok and result or {kind="source16_pickup_sight_diagnostic_error",error=tostring(result)})
end)
print("PICKUP_SIGHT16_ARMED: close console without moving; one PostRender snapshot; 12-second timeout")
