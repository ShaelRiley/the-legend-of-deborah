-- Read-only frozen ray comparison, before BUG018 repair. Same file runs in both realms.
local c=assert(util.JSONToTable(file.Read("legend_of_deborah/source16_pickup_sight_client_latest.json","DATA")),"frozen client sight snapshot required")
assert(c.target.id==1054 and c.target.creation==1269,"wrong frozen Health target")
local p=Entity(c.player.id) local target=Entity(1054) local gate=Entity(967)
assert(IsValid(p) and p:IsPlayer() and p:Alive(),"same living viewer required")
assert(IsValid(target) and target:GetCreationID()==1269 and target:GetClass()=="lod_loot_pickup","target retired")
assert(IsValid(gate) and gate:GetCreationID()==1176 and gate:GetClass()=="lod_gate" and gate:GetGateIndex()==1 and not gate:GetOpened(),"same closed Red gate required")
local function v(a) return Vector(a[1],a[2],a[3]) end
local function vec(a) return a and {a.x,a.y,a.z} end
local a,b=v(c.eye),v(c.target.center)
assert(p:EyePos():DistToSqr(a)<4 and target:WorldSpaceCenter():DistToSqr(b)<.0625,"frozen pose changed")
local source="gamemodes/legend_of_deborah/gamemode/lod/sh_near_look.lua"
assert(util.CRC(file.Read(source,"GAME"))=="3701160472","expected unrepaired NearLook source")
local mon=assert(CONTENTS_MONSTER) local ignore=assert(CONTENTS_IGNORE_NODRAW_OPAQUE)
local withoutIgnore=bit.band(MASK_VISIBLE,bit.bnot(ignore))
local masks={{"VISIBLE",MASK_VISIBLE},{"VISIBLE_OR_MONSTER",bit.bor(MASK_VISIBLE,mon)},
    {"VISIBLE_WITHOUT_IGNORE_NODRAW",withoutIgnore},{"VISIBLE_WITHOUT_IGNORE_NODRAW_OR_MONSTER",bit.bor(withoutIgnore,mon)},
    {"OPAQUE",MASK_OPAQUE},{"BLOCKLOS",MASK_BLOCKLOS},{"SOLID",MASK_SOLID},{"SHOT",MASK_SHOT}}
local lo,hi=gate:GetCollisionBounds()
local color=gate:GetColor()
local r={kind="source17_frozen_pickup_ray_variants",realm=CLIENT and "client" or "server",at=SysTime(),
    source_crc=util.CRC(file.Read(source,"GAME")),client_history=c.history_file,eye=vec(a),target_center=vec(b),
    target_id=target:EntIndex(),target_birth=target:GetCreationID(),eye_delta=p:EyePos():Distance(a),
    target_delta=target:WorldSpaceCenter():Distance(b),traces={},
    gate={id=gate:EntIndex(),birth=gate:GetCreationID(),closed=not gate:GetOpened(),model=gate:GetModel(),
        material_override=gate:GetMaterial(),model_materials=gate:GetMaterials(),no_draw=gate:GetNoDraw(),
        color={color.r,color.g,color.b,color.a},render_mode=gate:GetRenderMode(),solid=gate:GetSolid(),
        solid_flags=gate:GetSolidFlags(),collision_group=gate:GetCollisionGroup(),mins=vec(lo),maxs=vec(hi),
        pos=vec(gate:GetPos()),materials={}},mask_constants={VISIBLE=MASK_VISIBLE,MONSTER=mon,IGNORE_NODRAW=ignore}}
if CLIENT then
    for _,name in ipairs(gate:GetMaterials()) do
        local m=Material(name)
        r.gate.materials[#r.gate.materials+1]={name=name,error=m:IsError(),shader=m:GetShader(),
            flags=m:GetInt("$flags"),surfaceprop=m:GetString("$surfaceprop"),base_texture=m:GetString("$basetexture")}
    end
end
for _,mask in ipairs(masks) do
    for _,shape in ipairs({"line","zeroXY_oneZ","cube_one"}) do
        local q={start=a,endpos=b,filter=p,mask=mask[2]}
        if shape=="zeroXY_oneZ" then q.mins=Vector(0,0,0) q.maxs=Vector(0,0,1)
        elseif shape=="cube_one" then q.mins=Vector(-1,-1,-1) q.maxs=Vector(1,1,1) end
        local t=shape=="line" and util.TraceLine(q) or util.TraceHull(q)
        r.traces[#r.traces+1]={mask_name=mask[1],mask=mask[2],shape=shape,hit=t.Hit,
            start_solid=t.StartSolid,all_solid=t.AllSolid,fraction=t.Fraction,contents=t.Contents,
            hit_pos=vec(t.HitPos),hit_no_draw=t.HitNoDraw,surface_flags=t.SurfaceFlags,
            surface_property=t.SurfaceProps,surface_name=util.GetSurfacePropName(t.SurfaceProps or 0),texture=t.HitTexture,
            entity_id=IsValid(t.Entity) and t.Entity:EntIndex() or nil,
            entity_class=IsValid(t.Entity) and t.Entity:GetClass() or nil}
    end
end
local name="legend_of_deborah/source17_pickup_sight_variants_"..r.realm..".json"
file.Write(name,util.TableToJSON(r,true))
print("PICKUP_SIGHT_VARIANTS="..util.TableToJSON({file=name,traces=#r.traces,gate=r.gate.id,realm=r.realm,eye_delta=r.eye_delta,target_delta=r.target_delta}))
