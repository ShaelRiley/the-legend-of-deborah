-- One-shot client observation only. No gameplay setters, requests or net sends.
assert(CLIENT and game.GetMap()=="gm_flatgrass","expected native client/map")
local expected={cl_minimap="538781210",sv_minimap_magic="1541306324",sv_magic="979323034"}
for name,crc in pairs(expected) do
    assert(util.CRC(file.Read("gamemodes/legend_of_deborah/gamemode/lod/"..name..".lua","GAME"))==crc,"wrong map/Magic source: "..name)
end
local p=LocalPlayer()
assert(IsValid(p) and p:IsPlayer() and p:Alive() and LOD.Minimap,"living native player required")
local birth=p:GetCreationID()
local started=SysTime()
local clientLevel=LOD.ClientState and LOD.ClientState.level
local tag=tostring(math.floor(started*1000000))
local timerName="LOD_Source18_MapMagic_Observation_"..tag
local out={kind="source18_map_magic_readonly_25s",duration_requested=25,interval_requested=.25,
    started_sys=started,started_cur=CurTime(),player_id=p:EntIndex(),player_birth=birth,
    initial_client_level=clientLevel,source_crc=expected,samples={},
    qualification="Client NW2 observations, not direct server pool or forced-close event attribution. Ordinary input only; no automatic pass. Stop if player invalid/dead/replaced or synchronized level changes. Same-entity death/respawn between samples is not excluded."}
local done=false
local function finish(reason)
    if done then return end
    done=true timer.Remove(timerName)
    out.stop_reason=reason out.ended_sys=SysTime() out.elapsed=out.ended_sys-started
    out.sample_count=#out.samples
    local text=util.TableToJSON(out,true)
    assert(text,"diagnostic JSON serialization failed")
    local path="source18_map_magic_sampler_"..tag..".json"
    file.Write(path,text)
    print("MAPMAGIC18",path,reason,out.sample_count,string.format("%.3fs",out.elapsed))
end
local function sample()
    local current=LocalPlayer()
    if not IsValid(current) or current~=p or current:GetCreationID()~=birth then finish("player_replaced_or_invalid") return end
    local cs=LOD.ClientState or {}
    local pos=p:GetPos()
    local row={elapsed=SysTime()-started,cur=CurTime(),alive=p:Alive(),hp=p:Health(),
        map_open=LOD.Minimap.open==true,magic=p:GetNW2Float("LOD_Magic",-1),
        magic_max=p:GetNW2Int("LOD_MagicMax",-1),server_map_active=p:GetNW2Bool("LOD_MapMagicActive",false),
        player_id=p:EntIndex(),player_birth=p:GetCreationID(),position={pos.x,pos.y,pos.z},
        client_level=cs.level,objective_stage=cs.objectiveStage,synchronized=cs.synchronized==true,
        floor_mask=p:GetNW2Int("LOD_MapFloorMask",0),build_serial=p:GetNW2Int("LOD_MapBuildSerial",0),
        console_visible=gui.IsConsoleVisible(),game_ui_visible=gui.IsGameUIVisible(),
        q_down=input.IsKeyDown(KEY_Q),m_down=input.IsKeyDown(KEY_M)}
    out.samples[#out.samples+1]=row
    if not row.alive then finish("death_observed") return end
    if cs.level~=clientLevel then finish("client_level_changed") return end
end
sample()
timer.Create(timerName,.25,100,function()
    if done then return end
    sample()
    if not done and #out.samples>=101 then finish("25_seconds_complete") end
end)
print("MAPMAGIC18 started",timerName,"25s read-only; hide console then ordinary Q/M")
