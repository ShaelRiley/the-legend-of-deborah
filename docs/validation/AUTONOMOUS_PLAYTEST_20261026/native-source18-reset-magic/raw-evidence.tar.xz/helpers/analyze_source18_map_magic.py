"""Recompute bounded client observations from the frozen native JSON only."""
from pathlib import Path
import json, statistics

src=Path('.build/autonomous-playtest-20261027/source18-reset-magic/source18_map_magic_sampler_3727783296.json')
d=json.loads(src.read_text())
ss=d['samples']
assert len(ss)==d['sample_count']==101 and d['stop_reason']=='25_seconds_complete'
opened=[(i,s) for i,s in enumerate(ss) if s['map_open'] or s['server_map_active']]
first_i,last_i=opened[0][0],opened[-1][0]
close_i=next(i for i in range(last_i+1,len(ss)) if not ss[i]['map_open'] and not ss[i]['server_map_active'])
def rate(rows):
    xs=[s['cur'] for s in rows];ys=[s['magic'] for s in rows]
    xm,ym=statistics.mean(xs),statistics.mean(ys)
    m=sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/sum((x-xm)**2 for x in xs)
    b=ym-m*xm
    return {'sample_count':len(rows),'OLS_magic_per_CurTime_second':m,
        'maximum_absolute_residual_magic':max(abs(y-(m*x+b)) for x,y in zip(xs,ys))}
fields=['elapsed','cur','map_open','server_map_active','magic','console_visible','game_ui_visible','q_down','m_down']
def row(i):return {'index_zero_based':i,**{k:ss[i][k] for k in fields}}
changes=[]
for i,s in enumerate(ss):
    if i==0 or any(s[k]!=ss[i-1][k] for k in fields[2:4]+fields[5:]):changes.append(row(i))
openrows=[s for _,s in opened]
tail=ss[close_i:]
invariants={k:len({json.dumps(s[k],sort_keys=True) for s in ss}) for k in
 ['player_id','player_birth','alive','hp','position','floor_mask','build_serial','client_level','magic_max','objective_stage','synchronized']}
assert all(n==1 for n in invariants.values())
assert all(s['alive'] and s['hp']==100 and s['magic_max']==100 and s['floor_mask']==0 and s['build_serial']==5 for s in ss)
assert all(s['map_open']==s['server_map_active'] for s in ss)
assert ss[close_i]['magic']==0 and ss[-1]['magic']==9
assert all(b['magic']<=a['magic'] for a,b in zip(openrows,openrows[1:]))
assert all(b['magic']>=a['magic'] for a,b in zip(tail,tail[1:]))
assert not any(any(s[k] for k in ('console_visible','game_ui_visible','q_down','m_down')) for s in ss[first_i+1:])
out={'kind':'Independent recomputation of native client samples; no game execution',
 'source':str(src),'native_sample_count':len(ss),'wall_elapsed':d['elapsed'],
 'sample_intervals_wall':{'minimum':min(b['elapsed']-a['elapsed'] for a,b in zip(ss,ss[1:])),
 'maximum':max(b['elapsed']-a['elapsed'] for a,b in zip(ss,ss[1:]))},
 'observed_transitions':changes,'first_open':row(first_i),'last_open':row(last_i),'first_zero_closed':row(close_i),'last_sample':row(len(ss)-1),
 'zero_close_wall_bracket':[ss[last_i]['elapsed'],ss[close_i]['elapsed']],
 'zero_close_CurTime_bracket':[ss[last_i]['cur'],ss[close_i]['cur']],
 'first_open_to_first_zero_observed_wall':ss[close_i]['elapsed']-ss[first_i]['elapsed'],
 'qualification':'First open sample already has99.3Magic. The15.0229s first-open-to-first-zero sample interval is not an exact100to0 stopwatch. Client NW2 sampling quantizes pool/transition timing; no direct server forced-close event is captured.',
 'open_magic_nonincreasing':True,'closed_recovery_magic_nondecreasing':True,
 'no_later_sampled_Q_M_console_gameUI':True,'map_open_matches_server_active_every_sample':True,
 'constant_field_distinct_value_counts':invariants,'constant_values':{k:ss[0][k] for k in invariants},
 'open_OLS':rate(openrows),'closed_recovery_OLS':rate(tail)}
dest=src.parent/'sample-analysis.json'
dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'samples':len(ss),'close_bracket':out['zero_close_wall_bracket'],'end_magic':ss[-1]['magic'],
 'open_rate':out['open_OLS'],'recovery_rate':out['closed_recovery_OLS']}))
