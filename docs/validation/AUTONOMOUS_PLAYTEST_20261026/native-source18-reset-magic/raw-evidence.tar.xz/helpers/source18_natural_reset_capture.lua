assert(SERVER and #player.GetHumans()==1,"sole native server")
local p=player.GetHumans()[1] local R=LOD.RunManager local s=R.State local ps=R:GetPlayerState(p)
local old=EVP and EVP.b and EVP.b.run
local function row(state)
 if not state then return {available=false} end
 return {available=true,runId=state.RunId,epoch=state.CampaignEpoch,seed=state.CampaignSeed,levelSeed=state.LevelSeed,
 level=state.Level,failed=state.Failed,failedReason=state.FailedReason,failureReason=state.FailureReason,
 buildReady=state.BuildReady,clock=table.Copy(state.CampaignClock or {}),cards=table.Copy(state.Cards or {}),
 gates=table.Copy(state.GatesOpen or {}),floorMapMask=state.FloorMaps and state.FloorMaps.mask}
end
local account=LOD.CryptoStore:Read(p:SteamID64())
local r={kind="source18_automatic_clock_reset_readonly",at=SysTime(),oldRecordedRun=row(old),currentRun=row(s),
 sameRun=old==s,spawn=p.LODRunSpawnSerial,inStaging=ps.inStaging,deployed=ps.deploymentComplete,
 hero=ps.identity,alive=p:Alive(),hp=p:Health(),balance=account and account.balance,
 qualification="Snapshot after natural unmodified1800s expiry and new staging observation. Old table is retained only by the earlier event diagnostic. No reset/time/campaign/role/resource setter invoked; no explosion-visual/audio acceptance."}
file.Write("legend_of_deborah/source18_natural_reset_snapshot.json",util.TableToJSON(r,true))
print("NATURAL_RESET18",util.TableToJSON(r))
