local original=dofile
dofile=function(path)
if path=='gamemodes/legend_of_deborah/gamemode/lod/cl_ui_theme.lua' then return original('/tmp/deborah-popup-escape-20261027-negative/cl_ui_theme.lua') end
if path=='gamemodes/legend_of_deborah/gamemode/lod/cl_character_sheet.lua' then return original('/tmp/deborah-popup-escape-20261027-negative/cl_character_sheet.lua') end
return original(path)
end
original("tools/test_equipment_inventory_ui.lua")
