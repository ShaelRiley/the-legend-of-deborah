"""Assemble a reviewable CI evidence preview only; no docs/Git/private writes."""
import datetime
import hashlib
import io
import json
import pathlib
import re
import shutil
import tarfile

ROOT=pathlib.Path('/home/deck/Downloads/the-legend-of-deborah')
OUT=ROOT/'.build/source19-ci'
PREVIEW=OUT/'bank-preview'
COMMIT='658a8c7249a322494b49025e7076c33f78efb511'
MERGE='ff674d7d6aa23edf82dc809d3f39e8caacf4c322'
IDS={40635361503:122640976686,40635361486:122640976593,40635361464:122640976545,40635361563:122640976710}

def sha(data):return hashlib.sha256(data).hexdigest()
def read(name):return json.loads((OUT/name).read_text())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')

core=read('verification-core.json');proof=read('proof.json');pr=read('pr.json')
jobs=read('jobs.json')['jobs_by_run'];runs=read('workflows.json')['workflow_runs']
assert pr['head_sha']==COMMIT and pr['base_sha']=='f1af067c8616f46e8ba70df93399a785ac23901d'
assert pr['merge_commit_sha']==MERGE and pr['draft'] is True and pr['merged'] is False
assert {r['id'] for r in runs}==set(IDS)
assert all(r['status']=='completed' and r['conclusion']=='success' for r in runs)
compare=read('head-to-synthetic-merge-comparison.json')
assert compare['base']==COMMIT and compare['head']==MERGE and compare['files']==[]
checkout=[];warnings=[]
for run,job in IDS.items():
    entries=jobs[str(run)]
    assert len(entries)==1 and entries[0]['id']==job
    assert entries[0]['status']=='completed' and entries[0]['conclusion']=='success'
    assert all(s['status']=='completed' and s['conclusion']=='success' for s in entries[0]['steps'])
    text=(OUT/f'job-{job}.log').read_text();lines=text.splitlines();actual=[]
    for i,line in enumerate(lines):
        if 'git log -1 --format=%H' in line:
            for value in lines[i+1:i+3]:
                value=re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+Z ','',value)
                if re.fullmatch('[0-9a-f]{40}',value):actual.append(value)
    expected=MERGE if run in (40635361486,40635361464) else COMMIT
    assert actual==[expected],(run,actual)
    errors=[s for s in lines if '##[error]' in s]
    marked=[s for s in lines if '##[warning]' in s]
    assert not errors
    assert len(marked)==1 and 'Node.js 20 is deprecated' in marked[0] and 'Node.js 24' in marked[0]
    warnings.append({'run_id':run,'job_id':job,'explicit_ci_warning_markers':marked,
        'classification':'Pinned GitHub actions runner-runtime deprecation/forcedNode24 notice; original warning retained. Test setup requests Node22. No action-version or gameplay change made in this evidence task.'})
    checkout.append({'run_id':run,'job_id':job,'workflow':next(r['name'] for r in runs if r['id']==run),
        'status':'completed','conclusion':'success','associated_PR_head':COMMIT,'actual_checkout_sha':expected,
        'checkout_basis':'Canonical job git log -1 --format=%H output',
        'source_relation':'exact candidate checkout' if expected==COMMIT else 'GitHub synthetic PR merge; direct API comparison against candidate returns files[] (byte-equivalent source)',
        'url':f'https://github.com/ShaelRiley/the-legend-of-deborah/actions/runs/{run}'})
save(OUT/'checkout-and-warnings.json',{'workflow_checkouts':checkout,'warnings':warnings})
artifacts=read('artifacts.json')['artifacts'];assert len(artifacts)==1
artifact=artifacts[0]
assert artifact['id']==12792874736 and artifact['workflow_run']['head_sha']==COMMIT and artifact['expired'] is False
artifact_meta={key:artifact[key] for key in ('id','name','size_in_bytes','digest','expired','created_at','expires_at')}
artifact_meta.update({'url':f'https://github.com/ShaelRiley/the-legend-of-deborah/actions/runs/40635361503/artifacts/{artifact["id"]}',
    'head_sha':COMMIT,'downloaded_zip':False,'digest_locally_verified':False})
members=['pr.json','workflows.json','jobs.json','artifacts.json','head-to-synthetic-merge-comparison.json',
    'checkout-and-warnings.json','frozen-receipt.json','frozen-production_manifest.json',
    'frozen-git-source-manifest.json','local-frozen-production-manifest.json','local-frozen-identity.json',
    'proof.json','verification-core.json','hash_frozen_commit.py','verify_frozen_job.py','assemble_evidence.py']
members += [f'job-{job}.log' for job in IDS.values()]
assert len(set(members))==len(members)
payload={}
for name in members:
    data=(OUT/name).read_bytes()
    assert not re.search(rb'https?://[^\s\"<>]*[?&](?:sig|X-Amz-Signature|Signature)=',data,re.I)
    assert not re.search(rb'gh[pousr]_[A-Za-z0-9]{30,}',data)
    payload[name]=data
PREVIEW.mkdir(exist_ok=False)
archive=PREVIEW/'frozen-receipt-and-job-log.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for name,data in sorted(payload.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:xz') as tar:
    assert set(tar.getnames())==set(payload)
    assert all(tar.extractfile(name).read()==data for name,data in payload.items())
verification=dict(core)
verification.update({'all_four_workflows_success':True,'workflow_checkouts':checkout,
    'artifact_metadata':[artifact_meta],'warnings':warnings,
    'proof_json_provenance':'Parsed FROZEN_MATRIX_PROOF log JSON, formatted locally. Not claimed as the original artifact proof.json byte encoding. Receipt and production manifest are reconstructed exact original bytes from contiguous EVIDENCE_CHUNK records.',
    'archived_members':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(payload.items())},
    'archive_members':len(payload),'evidence_archive_sha256':sha(archive.read_bytes()),'evidence_archive_bytes':archive.stat().st_size})
save(PREVIEW/'verification.json',verification)
shutil.copyfile(OUT/'proof.json',PREVIEW/'proof.json')
files={path.name:{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())} for path in sorted(PREVIEW.iterdir())}
proposal={'kind':'bounded source19 CI evidence bank proposal only','status':'READY_FOR_ROOT_REVIEW; not copied to docs or committed',
    'candidate':COMMIT,'PR':'https://github.com/ShaelRiley/the-legend-of-deborah/pull/9',
    'destination':'docs/validation/AUTONOMOUS_PLAYTEST_20261026/ci-source19',
    'preview':str(PREVIEW.relative_to(ROOT)),'files':files,'archive_members':len(payload),
    'scope':'Only three new files in ci-source19; no coverage/plan/BUG019/source/GDD/private/GUI/Git mutation by this task. Root owns later banking/integration.',
    'checks':'All four workflows/jobs/steps success;338 ordered registered results/returncodes;929Lua;576production;4399 independently hashed frozenGit blobs; exact receipt SHA and identical before/after digest; all20 archive members verified byte-exact and signedURI/credential-pattern scan passed.',
    'limits':'Canonical job logs, exact receipt/production chunks and local frozenGit identity materialized. CI verified actual suite stdout/stderr hashes; individual suite logs/artifactZIP not downloaded. VR/audio use byte-equivalent synthetic merge checkout. Runner deprecation warnings retained. No source19 native/main integration/fullcampaign/cleanpass/co-op/audio acceptance claim.'}
save(OUT/'bank-proposal.json',proposal)
print(json.dumps({'files':files,'archive_members':len(payload),'status':proposal['status']},indent=2))
