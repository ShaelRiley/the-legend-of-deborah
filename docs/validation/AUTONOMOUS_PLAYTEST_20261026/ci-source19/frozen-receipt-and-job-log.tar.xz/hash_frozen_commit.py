"""Read-only frozen Git blob identity, independent of the current worktree."""
import hashlib
import json
import pathlib
import subprocess

ROOT=pathlib.Path('/home/deck/Downloads/the-legend-of-deborah')
OUT=ROOT/'.build/source19-ci'
COMMIT='658a8c7249a322494b49025e7076c33f78efb511'

def git(*args):
    return subprocess.check_output(['git','-C',str(ROOT),*args])

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()

def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')

rows=[]
for raw in git('ls-tree','-r','-z',COMMIT).split(b'\0'):
    if not raw:continue
    meta,name=raw.split(b'\t',1)
    mode,kind,oid=meta.decode().split()
    name=name.decode()
    assert kind=='blob' and mode in ('100644','100755'), (mode,kind,name)
    if '__pycache__' not in pathlib.PurePosixPath(name).parts:
        rows.append((name,oid))

manifest={}
total_bytes=0
with subprocess.Popen(['git','-C',str(ROOT),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE) as child:
    for name,oid in sorted(rows):
        child.stdin.write((oid+'\n').encode());child.stdin.flush()
        header=child.stdout.readline().decode().split()
        assert header[:2]==[oid,'blob'], (name,header)
        size=int(header[2]);remaining=size;h=hashlib.sha256()
        while remaining:
            block=child.stdout.read(min(1024*1024,remaining))
            assert block, name
            h.update(block);remaining-=len(block)
        assert child.stdout.read(1)==b'\n'
        manifest[name]=h.hexdigest();total_bytes+=size
    child.stdin.close()
    assert child.wait(timeout=30)==0

production={name:h for name,h in manifest.items() if name.startswith(('gamemodes/','lua/')) and name.endswith('.lua')}
lua=[name for name in manifest if name.startswith(('gamemodes/','lua/','tools/')) and name.endswith('.lua')]
identity={'kind':'independent frozen Git blob hashes','checkout_sha':COMMIT,'checkout_tree':git('rev-parse',COMMIT+':').decode().strip(),
    'source_files':len(manifest),'source_bytes':total_bytes,'source_digest':digest(manifest),
    'production_files':len(production),'production_digest':digest(production),'lua_files':len(lua),
    'method':'git ls-tree of exact candidate plus streamed git cat-file blob bytes; no worktree approximation, Git mutation or test execution'}
assert len(production)==576 and len(lua)==929
save('frozen-git-source-manifest.json',manifest)
save('local-frozen-production-manifest.json',production)
save('local-frozen-identity.json',identity)
print(json.dumps(identity,indent=2))
