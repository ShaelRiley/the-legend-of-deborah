"""Reconstruct exact evidence chunks from canonical decoded GitHub job logs."""
import datetime
import hashlib
import json
import pathlib
import re
import runpy

ROOT=pathlib.Path('/home/deck/Downloads/the-legend-of-deborah')
OUT=ROOT/'.build/source19-ci'
COMMIT='658a8c7249a322494b49025e7076c33f78efb511'
JOB=122640976686
RUN=40635361503

def sha(data):return hashlib.sha256(data).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def read(name):return json.loads((OUT/name).read_text())
def digest(value):return sha(json.dumps(value,sort_keys=True).encode())

raw=(OUT/f'job-{JOB}.log').read_text()
assert not re.search(r'https?://[^\s\"<>]*[?&](?:sig|X-Amz-Signature|Signature)=',raw,re.I)
chunks={};proofs=[]
for row in raw.splitlines():
    text=re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+Z ','',row)
    if text.startswith('EVIDENCE_CHUNK={'):
        piece=json.loads(text.removeprefix('EVIDENCE_CHUNK='))
        assert piece['file'] in ('receipt.json','production_manifest.json')
        offsets=chunks.setdefault(piece['file'],{})
        assert piece['offset'] not in offsets
        offsets[piece['offset']]=piece['text']
    if text.startswith('FROZEN_MATRIX_PROOF={'):
        proofs.append(json.loads(text.removeprefix('FROZEN_MATRIX_PROOF=')))
assert len(proofs)==1 and set(chunks)=={'receipt.json','production_manifest.json'}
for name,offsets in chunks.items():
    expected=0;pieces=[]
    for offset,text in sorted(offsets.items()):
        assert offset==expected and 0<len(text)<=4000
        pieces.append(text);expected+=len(text)
    (OUT/('frozen-'+name)).write_bytes(''.join(pieces).encode())
proof=proofs[0];save('proof.json',proof)
receipt=read('frozen-receipt.json');production=read('frozen-production_manifest.json')
identity=read('local-frozen-identity.json');sources=read('frozen-git-source-manifest.json')
assert proof['checkout_sha']==identity['checkout_sha']==COMMIT
assert proof['checkout_tree']==identity['checkout_tree']
assert proof['passed']==proof['total']==proof['verified_suite_logs']==receipt['passed']==receipt['total']==338
assert proof['lua_files']==receipt['lua_files']==identity['lua_files']==929
assert proof['source_files']==identity['source_files']==len(sources)
assert proof['source_before']==proof['source_after']==receipt['source_before']==receipt['source_after']==identity['source_digest']==digest(sources)
assert not proof['changed_during_gate'] and not receipt['changed_during_gate']
assert proof['receipt_sha256']==sha((OUT/'frozen-receipt.json').read_bytes())
assert proof['production_files']==identity['production_files']==len(production)==576
assert proof['production_sha256']==identity['production_digest']==digest(production)
assert production==read('local-frozen-production-manifest.json')
assert proof['native_gmod_accepted'] is False and receipt['native_gmod_accepted'] is False
rows=receipt['results']
assert [row['index'] for row in rows]==list(range(1,339))
assert len({row['log_prefix'] for row in rows})==338
assert all(row['returncode']==0 for row in rows)
assert len(re.findall(r'^\S+ \[PASS\] \d+/338 ',raw,re.M))==338
registry=ROOT/'tools/test_checkpoint_g_integration.py'
assert sha(registry.read_bytes())==sources['tools/test_checkpoint_g_integration.py']
expected_lua=sorted(name for name in sources if name.startswith(('gamemodes/','lua/','tools/')) and name.endswith('.lua'))
actual_lua=sorted(str(path.relative_to(ROOT)) for name in ('gamemodes','lua','tools') for path in (ROOT/name).rglob('*.lua'))
assert actual_lua==expected_lua
gate=runpy.run_path(str(registry),run_name='independent_registry_only')
assert len(gate['SUITES'])==338
assert [[row['name'],row['command']] for row in rows]==[[name,command] for name,command in gate['SUITES']]
new=[row for row in rows if row['name']=='Feat Card Fractional Recovery Rates']
assert len(new)==1 and new[0]['returncode']==0 and new[0]['command']==['python3','tools/run_lua54.py','tools/test_feat_card_rates.lua']
targeted=re.findall(r'TARGETED_RESULT=(.*?) returncode=(\d+)',raw)
targeted=[(name,int(code)) for name,code in targeted if name and name not in ('" + label + "',' + label + ')]
assert len(targeted)==8 and all(code==0 for name,code in targeted)
assert 'LUA_SYNTAX_FILES=929' in raw and 'SYSTEMS_MATRIX 338/338; source_changed=0' in raw
verification={'kind':'independent source19 frozen CI proof','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'commit':COMMIT,'checkout_tree':identity['checkout_tree'],'run_id':RUN,'job_id':JOB,'total':338,'passed':338,
    'lua_files':929,'production_files':576,'source_files':len(sources),'source_bytes':identity['source_bytes'],
    'source_before':proof['source_before'],'source_after':proof['source_after'],'all_frozen_git_blobs_match_source_digest':True,
    'all_production_hashes_match_frozen_commit':True,'all_338_result_commands_match_exact_registry':True,
    'new_fractional_recovery_suite_passed':True,'all_returncodes_zero':True,'unique_log_prefixes':338,
    'receipt_sha256':proof['receipt_sha256'],'receipt_sha256_matches_proof':True,'targeted_boundary_and_syntax_checks':targeted,
    'CI_step_verified_all_actual_suite_log_hashes':True,'individual_suite_logs_materialized_locally':False,
    'artifact_zip_materialized_locally':False,'native_gmod_accepted':False,
    'reconstruction':'Exact contiguous unique4000-character EVIDENCE_CHUNK payloads in canonical decoded GitHub job log; original receipt SHA and independent Git blob digests verified. Actual per-suite stdout/stderr hashes were checked by successful CI verification step, not locally reconstructed.',
    'qualification':'Static/headless CI only. Source19 native character-sheet/manual acceptance, main integration and broader gameplay/co-op/audio acceptance are separate pending gates.'}
save('verification-core.json',verification)
print(json.dumps({key:verification[key] for key in ('commit','run_id','job_id','total','passed','lua_files','production_files','source_files','receipt_sha256')},indent=2))
