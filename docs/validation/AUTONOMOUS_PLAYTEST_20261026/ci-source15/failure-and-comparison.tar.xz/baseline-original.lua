local native=dofile
dofile=function(p)
 if p=="gamemodes/legend_of_deborah/gamemode/lod/sv_safe_teleport.lua" then return native(".build/autonomous-playtest-20261027/source15-ci/source14-sv_safe_teleport.lua") end
 if p=="tools/test_heavy_plumber.lua" then return native(".build/autonomous-playtest-20261027/source15-ci/source14-test_heavy_plumber.lua") end
 return native(p)
end
dofile(".build/autonomous-playtest-20261027/source15-ci/source14-test_stomp_contact.lua")
