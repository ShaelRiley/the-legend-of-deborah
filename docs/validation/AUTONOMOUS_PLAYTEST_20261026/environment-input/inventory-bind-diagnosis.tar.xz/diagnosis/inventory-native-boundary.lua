-- Production equipment import with existing native entity doubles; no engine-cheat claim.
local f=dofile('tools/test_equipment_economy_runtime.lua')
local E=LOD.Equipment
local p=f.actor('fresh-inventory-diagnostic')
local function count() local n=0;for _ in pairs(E:Ensure(p.ps).items) do n=n+1 end;return n end
assert(count()==0)
p:Give('weapon_pistol');p:Give('weapon_lod_crowbar');p:SelectWeapon('weapon_pistol');E:Sync(p)
assert(count()==2 and p:GetAmmoCount('357')==0)
print('INVENTORY_IMPORT_BASELINE records=2 reserve357=0')
p:Give('weapon_smg1');E:Sync(p)
assert(count()==3 and p:GetAmmoCount('357')==0)
print('INVENTORY_IMPORT_ONE_STARTER records=3 reserve357=0')
for _,class in ipairs({'weapon_shotgun','weapon_357','weapon_ar2'}) do p:Give(class) end
p:SetAmmo(300,'357');E:Sync(p)
assert(count()==6 and p:GetAmmoCount('357')==300)
print('INVENTORY_IMPORT_EXTERNAL_NATIVE_GRANTS records=6 reserve357=300 preserved; no bootstrap grant')
