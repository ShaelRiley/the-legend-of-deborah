-- Disposable reproduction: real progression, damage resolver and Event formatting.
local env=dofile('tools/test_equipment_economy_runtime.lua')
local root='gamemodes/legend_of_deborah/gamemode/lod/'
local V=getmetatable(Vector())
V.__sub=function(a,b) return Vector(a.x-b.x,a.y-b.y,a.z-b.z) end
V.__mul=function(a,b) return Vector(a.x*b,a.y*b,a.z*b) end
function V:LengthSqr() return self.x*self.x+self.y*self.y+self.z*self.z end
function V:GetNormalized() local n=math.sqrt(self:LengthSqr());return n>0 and self*(1/n) or Vector() end
function V:Dot(b) return self.x*b.x+self.y*b.y+self.z*b.z end
isstring=function(v) return type(v)=='string' end
net.Receive=function() end
util.AddNetworkString=function() end
ErrorNoHalt=function(err) error(err) end
function string.Trim(s) return s:match('^%s*(.-)%s*$') end
Color=Color or function(r,g,b,a) return {r=r,g=g,b=b,a=a} end
player={GetAll=function() return {} end}
dofile(root..'sh_die_logger.lua')
dofile(root..'sh_feedback_language.lua')
dofile(root..'sv_feedback_language.lua')
dofile(root..'sv_combat_feed_semantics.lua')
local sent={}
function LOD.CombatRolls:_Send(recipient,category,text,family,fields)
    sent[#sent+1]={recipient=recipient,text=text,family=family,event=fields.event}
end
local R,C=LOD.RPGAbilityRules,LOD.CharacterProgressionSystem
local ai=env.actor('soldier',true)
ai.LODConfig={name='Soldier'}
ai.GetClass=function() return 'lod_hostile' end
ai.GetPos=function() return Vector(-100,0,0) end
local hero=env.actor('hero')
hero.lastPlayerName='Henry' -- Source entity double is a Lua table; use formatter's state branch.
hero.Nick=function() return 'Henry' end
hero.GetForward=function() return Vector(1,0,0) end
hero.EyeAngles=function() return {Forward=hero.GetForward} end
local function setClass(actor,class)
    actor.LODProgressionState.classId=class
    C:_RecomputeProgressionState(actor.LODProgressionState)
end
local function resolve(sourceClass,targetClass)
    sent={};setClass(ai,sourceClass);setClass(hero,targetClass)
    local tags={physical=true}
    local damage=R:ResolveDamageContract({contributions={4},attackEvent={}},ai,hero,tags)
    print(string.format('CASE source=%s target=%s backstab=%s damage=%g messages=%d',sourceClass,targetClass,tostring(tags.backstab),damage,#sent))
    for _,row in ipairs(sent) do print('TEXT '..row.text..' recipient='..tostring(row.recipient.id)) end
    return damage,tags,sent
end
local damage,tags,rows=resolve('fighter','rogue')
assert(not tags.backstab and #rows==0,'Defender Rogue must not grant attacker Backstab')
damage,tags,rows=resolve('rogue','fighter')
assert(tags.backstab and damage==8 and #rows==1 and rows[1].recipient==hero)
assert(rows[1].text:find('Henry: BACKSTAB',1,true),'Expected original recipient-as-subject defect')
assert(not rows[1].text:find('Soldier',1,true),'Original notice omits actual source')
damage,tags,rows=resolve('rogue','rogue')
assert(tags.backstab and damage==8 and #rows==1)
print('BUG012_REPRODUCED: AI Rogue rear hit doubles 4 to 8 correctly, but Event prefixes the receiving Hero as Backstab subject and omits Soldier; target Rogue alone grants no Backstab')
