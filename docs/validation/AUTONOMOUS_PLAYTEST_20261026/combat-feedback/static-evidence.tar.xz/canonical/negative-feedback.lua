local native=dofile
dofile=function(path) if path=='gamemodes/legend_of_deborah/gamemode/lod/sv_feedback_language.lua' then return native('.build/autonomous-playtest-20261027/backstab-investigation/sv_feedback_language.original.lua') end return native(path) end
arg={}
dofile('tools/test_backstab_feedback.lua')
