local native=dofile
dofile=function(p) if p=="gamemodes/legend_of_deborah/gamemode/lod/sv_safe_teleport.lua" then return native(".build/autonomous-playtest-20261027/bug015-safe-floor/sv_safe_teleport.wide-corners.lua") end return native(p) end
dofile("tools/test_summon_card.lua")
