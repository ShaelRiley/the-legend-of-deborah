local realOpen=io.open
local hits=0
io.open=function(path,mode)
 if path=="gamemodes/legend_of_deborah/gamemode/lod/sv_feat_card_text.lua" then
  hits=hits+1
  print("REVIEW_ORIGINAL_FORMATTER_SELECTED",hits)
  return realOpen(".build/autonomous-playtest-20261027/bug019-law/native-source18-sv_feat_card_text.lua",mode)
 end
 return realOpen(path,mode)
end
dofile("tools/test_feat_card_rates.lua")
assert(hits>0,"Frozen formatter not exercised")
