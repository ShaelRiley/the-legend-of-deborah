LOD = LOD or {}
LOD.RPG = LOD.RPG or {}
LOD.RPG.FeatEffectSystem = LOD.RPG.FeatEffectSystem or {}

local RPG = LOD.RPG
local Catalog = RPG.IdentityCatalog
local FeatEffectSystem = RPG.FeatEffectSystem
local Feats = Catalog.LevelOneOrdinaryFeats

-- Gate E batch 1: the complete CON Health-Regeneration ladder.  Keep the
-- historical table name as a compatibility alias until the full Gate E catalog
-- is present; it is already the FeatDirector's ordinary pool at every feat level.
Catalog.OrdinaryFeats = Feats

local function regenDefinition(featId, displayName, requirement, prerequisite, rank, ceiling, baseRate)
    return {
        featId = featId,
        displayName = displayName,
        featFamilyId = "con_health_regeneration",
        rankIndex = rank,
        replacesLowerRank = rank > 1,
        repeatableFallback = false,
        governingAbilities = {"con"},
        abilityRequirements = {con = requirement},
        prerequisiteFeatIds = prerequisite and {prerequisite} or {},
        requiredCapabilityTags = {},
        incompatibleFeatIds = {},
        allowedActorTypes = {"hero", "human_soldier", "ai"},
        requiredSubsystemTags = {},
        synergyTags = {"health_regeneration", "maximum_hp"},
        oneRank = true,
        effectHandlerId = "health_regeneration",
        effectParams = {
            ceilingFraction = ceiling,
            damageFreeDelaySeconds = 5.0,
            baseMaxHPPerSecond = baseRate,
            description = string.format("%sAdds %d%% MaxHP to the regeneration ceiling; highest rank only. Stacks with a Fighter's innate 33%%. After 5.0 damage-free seconds, regenerate %g%% MaxHP/second times the CON regeneration multiplier toward the combined ceiling. Never restores Tetris overfill.",
                rank > 1 and "Replaces lower Recovery ranks. " or "Enables passive Health Regeneration. ", math.floor(ceiling * 100 + 0.5), baseRate * 100)
        },
        directorBaseWeight = 1.0,
        eligibilityText = string.format("CON %d%s", requirement,
            prerequisite and (" / requires " .. prerequisite) or ""),
        actorText = "Heroes, human Soldiers, AI"
    }
end

Feats.CON_REGEN_11 = regenDefinition("CON_REGEN_11", "Second Wind", 13, nil, 1, 0.22, 0.01)
Feats.CON_REGEN_22 = regenDefinition("CON_REGEN_22", "Rapid Recovery", 15,
    "CON_REGEN_11", 2, 0.44, 0.015)
Feats.CON_REGEN_33 = regenDefinition("CON_REGEN_33", "Unbroken", 17,
    "CON_REGEN_22", 3, 0.66, 0.02)

local function navigationDefinition(featId, displayName, requirement, prerequisite,
    familyId, rank, effectParams)
    return {
        featId = featId,
        displayName = displayName,
        featFamilyId = familyId,
        rankIndex = rank,
        replacesLowerRank = rank > 1,
        repeatableFallback = false,
        governingAbilities = {"wis"},
        abilityRequirements = {wis = requirement},
        prerequisiteFeatIds = prerequisite and {prerequisite} or {},
        requiredCapabilityTags = {"minimap"},
        incompatibleFeatIds = {},
        allowedActorTypes = {"hero", "human_soldier"},
        requiredSubsystemTags = {},
        synergyTags = {"minimap", "navigation", "utility_magic"},
        oneRank = true,
        effectHandlerId = "wis_navigation",
        effectParams = effectParams,
        directorBaseWeight = 1.0,
        eligibilityText = string.format("WIS %d%s", requirement,
            prerequisite and (" / requires " .. prerequisite) or ""),
        actorText = "Heroes and human Soldiers with minimap access"
    }
end

Feats.WIS_CARTOGRAPHER = navigationDefinition("WIS_CARTOGRAPHER", "Cartographer", 13,
    nil, "wis_breadcrumb_range", 1, {
        breadcrumbBonusCells = 8,
        description = "Adds +8 BreadcrumbCells along the canonical current-objective route after the normal WIS formula; current-floor and routing restrictions remain absolute."
    })
Feats.WIS_FRUGAL_MAP = navigationDefinition("WIS_FRUGAL_MAP", "Frugal Cartography", 15,
    nil, "wis_frugal_map", 1, {
        mapDrainMultiplier = 0.75,
        minimumMapDrainPerSecond = 3.0,
        description = "Multiplies WIS-scaled minimap drain by 0.75, with final drain never below 3.0 Magic/second; Magic regeneration remains disabled while open."
    })
Feats.WIS_INTERNAL_COMPASS = navigationDefinition("WIS_INTERNAL_COMPASS", "Internal Compass", 15,
    nil, "wis_internal_compass", 1, {
        description = "While your map panel is open, follow the ordinary current-objective breadcrumb trail even before finding this floor's map. Its walls remain hidden. Uses your existing breadcrumb range and normal map Magic cost."
    })
Feats.WIS_MAP_FINDER = navigationDefinition("WIS_MAP_FINDER", "Map Finder", 13,
    nil, "wis_map_finder", 1, {
        description = "See uncollected map pickups in the world through walls and ceilings, including maps on other floors. Does not reveal their maze layouts or grant ownership. No map panel or Magic expenditure is required."
    })

local function ammoFloorDefinition(featId, displayName, requirement, prerequisite, rank, fraction, speedMultiplier)
    return {
        featId = featId,
        displayName = displayName,
        featFamilyId = "int_ammo_regeneration_floor",
        rankIndex = rank,
        replacesLowerRank = rank > 1,
        repeatableFallback = false,
        governingAbilities = {"int"},
        abilityRequirements = {int = requirement},
        prerequisiteFeatIds = prerequisite and {prerequisite} or {},
        requiredCapabilityTags = {"firearm"},
        incompatibleFeatIds = {},
        allowedActorTypes = {"hero", "human_soldier"},
        requiredSubsystemTags = {},
        synergyTags = {"ammo_regeneration", "firearm_economy"},
        oneRank = true,
        effectHandlerId = "ammo_regeneration_floor",
        effectParams = {
            floorFraction = fraction,
            speedMultiplier = speedMultiplier,
            description = string.format(
                "Replaces lower ammo-regeneration ranks and sets ordinary regenerative firearm AmmoRegenFloorFraction to %.2f; each owned eligible family stops at ceil(MaxFamilyCapacity × %.2f) with %d%% faster per-round recovery (baseline interval / %.2f). Capacity and no-fire delay stay unchanged; no instant ammo, consumable, Wand-charge or AR2-secondary regeneration.",
                fraction, fraction, math.floor((speedMultiplier - 1) * 100 + 0.5), speedMultiplier)
        },
        directorBaseWeight = 1.0,
        eligibilityText = string.format("INT %d%s", requirement,
            prerequisite and (" / requires " .. prerequisite) or ""),
        actorText = "Player-controlled heroes and human Soldiers with regenerative firearm ammunition"
    }
end

Feats.INT_AMMO_FLOOR_44 = ammoFloorDefinition("INT_AMMO_FLOOR_44", "Field Supply", 13,
    nil, 1, 0.44, 1.22)
Feats.INT_AMMO_FLOOR_55 = ammoFloorDefinition("INT_AMMO_FLOOR_55", "Deep Reserves", 15,
    "INT_AMMO_FLOOR_44", 2, 0.55, 1.44)
Feats.INT_AMMO_FLOOR_66 = ammoFloorDefinition("INT_AMMO_FLOOR_66", "War Stock", 17,
    "INT_AMMO_FLOOR_55", 3, 0.66, 1.66)

local REGEN_RANKS = {
    CON_REGEN_11 = 1,
    CON_REGEN_22 = 2,
    CON_REGEN_33 = 3
}

local BREADCRUMB_RANKS = {
    WIS_CARTOGRAPHER = 1
}

local AMMO_FLOOR_RANKS = {
    INT_AMMO_FLOOR_44 = 1,
    INT_AMMO_FLOOR_55 = 2,
    INT_AMMO_FLOOR_66 = 3
}

local function ownsFeat(state, featId)
    for _, ownedId in ipairs(state and state.featIds or {}) do
        if ownedId == featId then return true end
    end
    return false
end

function FeatEffectSystem:HealthRegenProfile(state)
    local bestRank, bestDefinition = 0, nil
    for featId, rank in pairs(REGEN_RANKS) do
        if rank > bestRank and ownsFeat(state, featId) then
            bestRank = rank
            bestDefinition = Feats[featId]
        end
    end
    local params = bestDefinition and bestDefinition.effectParams or {}
    local innate = state and state.classId == "fighter" and 0.33 or 0
    local contribution = tonumber(params.ceilingFraction) or 0
    return {
        enabled = innate + contribution > 0,
        rank = bestRank,
        featId = bestDefinition and bestDefinition.featId or nil,
        ceilingFraction = innate + contribution,
        damageFreeDelaySeconds = tonumber(params.damageFreeDelaySeconds) or 5.0,
        baseMaxHPPerSecond = tonumber(params.baseMaxHPPerSecond) or 0.01
    }
end

function FeatEffectSystem:NavigationProfile(state)
    local bestRank, bestDefinition = 0, nil
    for featId, rank in pairs(BREADCRUMB_RANKS) do
        if rank > bestRank and ownsFeat(state, featId) then
            bestRank = rank
            bestDefinition = Feats[featId]
        end
    end
    local frugal = ownsFeat(state, "WIS_FRUGAL_MAP")
    local breadcrumbParams = bestDefinition and bestDefinition.effectParams or {}
    local frugalParams = frugal and Feats.WIS_FRUGAL_MAP.effectParams or {}
    return {
        internalCompassEnabled = ownsFeat(state, "WIS_INTERNAL_COMPASS"),
        mapFinderEnabled = ownsFeat(state, "WIS_MAP_FINDER"),
        breadcrumbRank = bestRank,
        breadcrumbFeatId = bestDefinition and bestDefinition.featId or nil,
        breadcrumbBonusCells = tonumber(breadcrumbParams.breadcrumbBonusCells) or 0,
        frugalMapEnabled = frugal,
        mapDrainMultiplier = tonumber(frugalParams.mapDrainMultiplier) or 1,
        minimumMapDrainPerSecond = tonumber(frugalParams.minimumMapDrainPerSecond) or 0
    }
end

function FeatEffectSystem:AmmoRegenProfile(state)
    local bestRank, bestDefinition = 0, nil
    for featId, rank in pairs(AMMO_FLOOR_RANKS) do
        if rank > bestRank and ownsFeat(state, featId) then
            bestRank = rank
            bestDefinition = Feats[featId]
        end
    end
    local params = bestDefinition and bestDefinition.effectParams or {}
    return {
        rank = bestRank,
        featId = bestDefinition and bestDefinition.featId or nil,
        floorFraction = tonumber(params.floorFraction) or 0.33,
        speedMultiplier = tonumber(params.speedMultiplier) or 1
    }
end

function FeatEffectSystem:ApplyDerived(state, derived)
    local profile = self:HealthRegenProfile(state)
    derived.healthRegenEnabled = profile.enabled
    derived.healthRegenRank = profile.rank
    derived.healthRegenCeilingFraction = profile.ceilingFraction
    derived.healthRegenDamageFreeDelaySeconds = profile.damageFreeDelaySeconds
    derived.healthRegenBaseMaxHPPerSecond = profile.baseMaxHPPerSecond

    local navigation = self:NavigationProfile(state)
    derived.internalCompassEnabled = navigation.internalCompassEnabled
    derived.mapFinderEnabled = navigation.mapFinderEnabled
    derived.breadcrumbFeatRank = navigation.breadcrumbRank
    derived.breadcrumbFeatBonusCells = navigation.breadcrumbBonusCells
    derived.breadcrumbCells = math.Clamp(
        math.floor((tonumber(derived.breadcrumbCells) or 6)
            + navigation.breadcrumbBonusCells), 2, 24)
    derived.frugalMapEnabled = navigation.frugalMapEnabled
    derived.mapDrainFeatMultiplier = navigation.mapDrainMultiplier
    derived.minimumMapDrainPerSecond = navigation.minimumMapDrainPerSecond

    local ammo = self:AmmoRegenProfile(state)
    derived.ammoRegenFloorRank = ammo.rank
    derived.ammoRegenFloorFraction = ammo.floorFraction
    derived.ammoRegenSpeedMultiplier = ammo.speedMultiplier
    derived.ammoRegenFloorRoundsByFamily = {}
    local ammoAuthority = LOD.DiceAmmo
    if ammoAuthority and ammoAuthority.RegenerativeProfiles
        and ammoAuthority.RegenFloorRounds
    then
        for weaponClass, weaponProfile in pairs(ammoAuthority.RegenerativeProfiles) do
            derived.ammoRegenFloorRoundsByFamily[weaponClass] =
                ammoAuthority:RegenFloorRounds(nil, weaponClass, weaponProfile, derived)
        end
    end
end

function FeatEffectSystem:HealthRegenPerSecond(maxHP, conRegenMultiplier, baseFraction)
    return math.max(0, tonumber(maxHP) or 0)
        * math.max(0, tonumber(baseFraction) or 0.01)
        * math.max(0, tonumber(conRegenMultiplier) or 1)
end

FeatEffectSystem.RegenActors = FeatEffectSystem.RegenActors
    or setmetatable({}, {__mode = "k"})

function FeatEffectSystem:TrackActor(actor, requireFreshDelay)
    if not IsValid(actor) then return end
    local rules = LOD.RPGAbilityRules
    local derived = rules and rules.Derived and rules:Derived(actor) or nil
    if not derived or derived.healthRegenEnabled ~= true then
        self.RegenActors[actor] = nil
        return
    end
    local maximum = math.max(1, actor:GetMaxHealth())
    local ceiling = math.min(maximum, math.max(1, math.floor(maximum
        * (tonumber(derived.healthRegenCeilingFraction) or 0))))
    if actor:Health() >= ceiling then
        self.RegenActors[actor] = nil
        return
    end
    self.RegenActors[actor] = true
    if requireFreshDelay or actor.LODRPGHealthRegenEligibleAt == nil then
        actor.LODRPGHealthRegenEligibleAt = CurTime()
            + (tonumber(derived.healthRegenDamageFreeDelaySeconds) or 5.0)
        actor.LODRPGHealthRegenAccumulator = 0
    end
end

function FeatEffectSystem:OnEffectiveDamage(actor, damage)
    if not IsValid(actor) or (tonumber(damage) or 0) <= 0 then return end
    local rules = LOD.RPGAbilityRules
    local derived = rules and rules.Derived and rules:Derived(actor) or nil
    if not derived or derived.healthRegenEnabled ~= true then return end
    -- EntityTakeDamage's final gamemode seam still precedes Source's HP write,
    -- so do not reject a full-health actor by inspecting pre-hit Health here.
    self.RegenActors[actor] = true
    actor.LODRPGHealthRegenEligibleAt = CurTime()
        + (tonumber(derived.healthRegenDamageFreeDelaySeconds) or 5.0)
    actor.LODRPGHealthRegenAccumulator = 0
end

function FeatEffectSystem:_TickActor(actor, elapsed)
    local run = LOD.RunManager and LOD.RunManager.State
    if run and (run.SimulationFrozen or run.Failed or run.LevelCleared or run.BuildReady == false) then return end
    if IsValid(actor) and actor.LODBossEncounter and LOD.BossEncounter and (#LOD.BossEncounter:Targets(actor.LODBossEncounter)==0 or actor.LODBossEncounter.dead) then return end
    if IsValid(actor) and actor.LODHector then self.RegenActors[actor] = nil; return end
    if IsValid(actor) and actor.LODArchetypeId == "warden" and LOD.Warden and #LOD.Warden:Targets() == 0 then return end
    if not IsValid(actor) or actor.LODDead or actor:Health() <= 0 or (actor:IsPlayer() and not actor:Alive()) then
        self.RegenActors[actor] = nil
        return
    end
    local rules = LOD.RPGAbilityRules
    local derived = rules and rules.Derived and rules:Derived(actor) or nil
    if not derived or derived.healthRegenEnabled ~= true then
        self.RegenActors[actor] = nil
        return
    end

    local maximum = math.max(1, actor:GetMaxHealth())
    local ceiling = math.min(maximum, math.max(1, math.floor(maximum
        * (tonumber(derived.healthRegenCeilingFraction) or 0))))
    if actor:Health() >= ceiling then
        actor.LODRPGHealthRegenAccumulator = 0
        self.RegenActors[actor] = nil
        return
    end
    if actor.LODRPGHealthRegenEligibleAt == nil then
        self:TrackActor(actor, true)
        return
    end
    if CurTime() < actor.LODRPGHealthRegenEligibleAt then return end

    local amount = self:HealthRegenPerSecond(maximum, derived.conRegenMultiplier,
        derived.healthRegenBaseMaxHPPerSecond) * elapsed
    local accumulated = (tonumber(actor.LODRPGHealthRegenAccumulator) or 0) + amount
    local whole = math.floor(accumulated)
    actor.LODRPGHealthRegenAccumulator = accumulated - whole
    if whole <= 0 then return end

    local before = actor:Health()
    actor:SetHealth(math.min(ceiling, before + whole))
    if actor:Health() > before then
        actor.LODRPGLastHealthRegenAt = CurTime()
    end
end

timer.Create("LOD_RPG_GateE_HealthRegen", 0.25, 0, function()
    for actor in pairs(FeatEffectSystem.RegenActors) do
        FeatEffectSystem:_TickActor(actor, 0.25)
    end
end)

function FeatEffectSystem:ValidateHealthRegen()
    local errors = {}
    local function expect(condition, message)
        if not condition then errors[#errors + 1] = message end
    end
    local expected = {
        CON_REGEN_11 = {1, 13, nil, 0.22},
        CON_REGEN_22 = {2, 15, "CON_REGEN_11", 0.44},
        CON_REGEN_33 = {3, 17, "CON_REGEN_22", 0.66}
    }
    for featId, values in pairs(expected) do
        local definition = Feats[featId]
        expect(definition ~= nil, "missing " .. featId)
        if definition then
            expect(definition.featFamilyId == "con_health_regeneration", featId .. " family")
            expect(definition.rankIndex == values[1], featId .. " rank")
            expect(definition.abilityRequirements.con == values[2], featId .. " requirement")
            expect((definition.prerequisiteFeatIds or {})[1] == values[3], featId .. " prerequisite")
            expect(definition.effectHandlerId == "health_regeneration", featId .. " handler")
            expect(definition.effectParams.ceilingFraction == values[4], featId .. " ceiling")
        end
    end

    local rankOne = self:HealthRegenProfile({featIds = {"CON_REGEN_11"}})
    local rankThree = self:HealthRegenProfile({featIds = {
        "CON_REGEN_11", "CON_REGEN_22", "CON_REGEN_33"
    }})
    expect(rankOne.enabled and rankOne.rank == 1 and rankOne.ceilingFraction == 0.22,
        "rank-one profile")
    expect(rankThree.enabled and rankThree.rank == 3 and rankThree.ceilingFraction == 0.66,
        "rank replacement profile")
    expect(self:HealthRegenPerSecond(100, 1.5, 0.01) == 1.5,
        "CON-scaled regeneration rate")

    local progression = LOD.CharacterProgressionSystem
    if progression and progression._FeatEligible then
        local state = {
            featIds = {},
            featQualificationAbilities = {con = 17},
            classId = "fighter",
            secondaryAbilities = {}
        }
        expect(not progression:_FeatEligible({}, state, Feats.CON_REGEN_22),
            "rank two must require Second Wind")
        state.featIds = {"CON_REGEN_11"}
        expect(progression:_FeatEligible({}, state, Feats.CON_REGEN_22),
            "rank two legal after Second Wind")
        expect(not progression:_FeatEligible({}, state, Feats.CON_REGEN_33),
            "rank three must require Rapid Recovery")
        state.featIds[#state.featIds + 1] = "CON_REGEN_22"
        expect(progression:_FeatEligible({}, state, Feats.CON_REGEN_33),
            "rank three legal after Rapid Recovery")
    else
        expect(false, "FeatDirector eligibility authority unavailable")
    end
    return #errors == 0, errors
end


function FeatEffectSystem:ValidateWISNavigation()
    local errors = {}
    local function expect(condition, message)
        if not condition then errors[#errors + 1] = message end
    end
    local expected = {
        WIS_CARTOGRAPHER = {"wis_breadcrumb_range", 1, 13, nil, 8, nil, nil},
        WIS_FRUGAL_MAP = {"wis_frugal_map", 1, 15, nil, nil, 0.75, 3.0}
    }
    for featId, values in pairs(expected) do
        local definition = Feats[featId]
        expect(definition ~= nil, "missing " .. featId)
        if definition then
            expect(definition.featFamilyId == values[1], featId .. " family")
            expect(definition.rankIndex == values[2], featId .. " rank")
            expect(definition.abilityRequirements.wis == values[3], featId .. " requirement")
            expect((definition.prerequisiteFeatIds or {})[1] == values[4], featId .. " prerequisite")
            expect(definition.effectHandlerId == "wis_navigation", featId .. " handler")
            expect(definition.effectParams.breadcrumbBonusCells == values[5], featId .. " breadcrumb bonus")
            expect(definition.effectParams.mapDrainMultiplier == values[6], featId .. " drain multiplier")
            expect(definition.effectParams.minimumMapDrainPerSecond == values[7], featId .. " drain floor")
        end
    end

    local surveyor = self:NavigationProfile({featIds = {"WIS_SURVEYOR"}})
    local cartographer = self:NavigationProfile({featIds = {
        "WIS_SURVEYOR", "WIS_CARTOGRAPHER"
    }})
    local combined = self:NavigationProfile({featIds = {
        "WIS_SURVEYOR", "WIS_CARTOGRAPHER", "WIS_FRUGAL_MAP"
    }})
    expect(surveyor.breadcrumbRank == 0 and surveyor.breadcrumbBonusCells == 0,
        "retired navigation ID is inert")
    expect(cartographer.breadcrumbRank == 1 and cartographer.breadcrumbBonusCells == 8,
        "Cartographer is one rank, +8 cells")
    expect(combined.frugalMapEnabled and combined.mapDrainMultiplier == 0.75
        and combined.minimumMapDrainPerSecond == 3.0, "Frugal Cartography profile")

    local derived = {breadcrumbCells = 10}
    self:ApplyDerived({featIds = {
        "WIS_SURVEYOR", "WIS_CARTOGRAPHER", "WIS_FRUGAL_MAP"
    }}, derived)
    expect(derived.breadcrumbCells == 18 and derived.breadcrumbFeatBonusCells == 8,
        "breadcrumb bonus must apply once after WIS")
    expect(derived.mapDrainFeatMultiplier == 0.75
        and derived.minimumMapDrainPerSecond == 3.0, "derived Frugal Cartography values")

    local rules = LOD.RPGAbilityRules
    if rules and rules.MapDrainPerSecondFromDerived then
        expect(math.abs(rules:MapDrainPerSecondFromDerived(100 / 15, {
            utilityMagicCostMultiplier = 1,
            mapDrainFeatMultiplier = 0.75,
            minimumMapDrainPerSecond = 3
        }) - (100 / 15) * 0.75) < 0.0001, "Frugal drain multiplication order")
        expect(rules:MapDrainPerSecondFromDerived(2, {
            utilityMagicCostMultiplier = 1,
            mapDrainFeatMultiplier = 0.75,
            minimumMapDrainPerSecond = 3
        }) == 3, "Frugal drain floor")
    else
        expect(false, "canonical map-drain authority unavailable")
    end

    local progression = LOD.CharacterProgressionSystem
    if progression and progression._FeatEligible then
        local state = {
            featIds = {},
            featQualificationAbilities = {wis = 13},
            classId = "wizard",
            secondaryAbilities = {}
        }
        expect(progression:_FeatEligible({}, state, Feats.WIS_CARTOGRAPHER),
            "Cartographer is available at WIS 13 without prerequisites")
        state.featIds = {"WIS_SURVEYOR"}
        expect(progression:_FeatEligible({}, state, Feats.WIS_CARTOGRAPHER),
            "stale navigation ID cannot block Cartographer")
        state.featQualificationAbilities.wis = 15
        expect(progression:_FeatEligible({}, state, Feats.WIS_FRUGAL_MAP),
            "Frugal Cartography independently legal")
    else
        expect(false, "FeatDirector eligibility authority unavailable")
    end
    return #errors == 0, errors
end

function FeatEffectSystem:ValidateAmmoRegenFloor()
    local errors = {}
    local function expect(condition, message)
        if not condition then errors[#errors + 1] = message end
    end
    local expected = {
        INT_AMMO_FLOOR_44 = {1, 13, nil, 0.44},
        INT_AMMO_FLOOR_55 = {2, 15, "INT_AMMO_FLOOR_44", 0.55},
        INT_AMMO_FLOOR_66 = {3, 17, "INT_AMMO_FLOOR_55", 0.66}
    }
    for featId, values in pairs(expected) do
        local definition = Feats[featId]
        expect(definition ~= nil, "missing " .. featId)
        if definition then
            expect(definition.featFamilyId == "int_ammo_regeneration_floor", featId .. " family")
            expect(definition.rankIndex == values[1], featId .. " rank")
            expect(definition.abilityRequirements.int == values[2], featId .. " requirement")
            expect((definition.prerequisiteFeatIds or {})[1] == values[3], featId .. " prerequisite")
            expect(definition.effectHandlerId == "ammo_regeneration_floor", featId .. " handler")
            expect(definition.effectParams.floorFraction == values[4], featId .. " floor fraction")
        end
    end

    local baseline = self:AmmoRegenProfile({featIds = {}})
    local rankOne = self:AmmoRegenProfile({featIds = {"INT_AMMO_FLOOR_44"}})
    local rankThree = self:AmmoRegenProfile({featIds = {
        "INT_AMMO_FLOOR_44", "INT_AMMO_FLOOR_55", "INT_AMMO_FLOOR_66"
    }})
    expect(baseline.rank == 0 and baseline.floorFraction == 0.33, "baseline ammo floor")
    expect(rankOne.rank == 1 and rankOne.floorFraction == 0.44, "Field Supply profile")
    expect(rankThree.rank == 3 and rankThree.floorFraction == 0.66,
        "War Stock must replace lower ranks")

    local derived = {}
    self:ApplyDerived({featIds = {
        "INT_AMMO_FLOOR_44", "INT_AMMO_FLOOR_55", "INT_AMMO_FLOOR_66"
    }}, derived)
    expect(derived.ammoRegenFloorRank == 3 and derived.ammoRegenFloorFraction == 0.66,
        "derived War Stock values")

    local ammo = LOD.DiceAmmo
    if ammo and ammo.RegenFloorRounds then
        expect(ammo:RegenFloorRounds(nil, "weapon_pistol", {cap = 54}, {
            ammoRegenFloorFraction = 0.44
        }) == 24, "Field Supply Pistol ceil")
        expect(ammo:RegenFloorRounds(nil, "weapon_shotgun", {cap = 21}, {
            ammoRegenFloorFraction = 0.55
        }) == 12, "Deep Reserves Shotgun ceil")
        expect(ammo:RegenFloorRounds(nil, "weapon_smg1", {cap = 75}, {
            ammoRegenFloorFraction = 0.66
        }) == 50, "War Stock SMG ceil")
        expect(ammo:RegenFloorRounds(nil, "weapon_357", {cap = 18}, {
            ammoRegenFloorFraction = 0.66
        }) == 12, "War Stock Magnum ceil")
    else
        expect(false, "canonical ammunition-regeneration authority unavailable")
    end

    local progression = LOD.CharacterProgressionSystem
    if progression and progression._FeatEligible then
        local state = {
            featIds = {},
            featQualificationAbilities = {int = 17},
            classId = "wizard",
            secondaryAbilities = {}
        }
        expect(not progression:_FeatEligible({}, state, Feats.INT_AMMO_FLOOR_55),
            "Deep Reserves must require Field Supply")
        state.featIds = {"INT_AMMO_FLOOR_44"}
        expect(progression:_FeatEligible({}, state, Feats.INT_AMMO_FLOOR_55),
            "Deep Reserves legal after Field Supply")
        state.featIds[#state.featIds + 1] = "INT_AMMO_FLOOR_55"
        expect(progression:_FeatEligible({}, state, Feats.INT_AMMO_FLOOR_66),
            "War Stock legal after Deep Reserves")
    else
        expect(false, "FeatDirector eligibility authority unavailable")
    end
    return #errors == 0, errors
end

concommand.Add("lod_rpg_gate_e_regen_validate", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or (IsValid(ply) and not ply:IsAdmin()) then return end
    local ok, errors = FeatEffectSystem:ValidateHealthRegen()
    if ok then
        print("[LOD:RPG-E] Health-Regeneration feat family PASS — 3/3 ranks, replacement semantics, CON rate")
    else
        ErrorNoHalt("[LOD:RPG-E] Health-Regeneration feat family FAILED\n")
        for _, message in ipairs(errors) do ErrorNoHalt("[LOD:RPG-E]  - " .. message .. "\n") end
    end
end)

concommand.Add("lod_rpg_gate_e_navigation_validate", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or (IsValid(ply) and not ply:IsAdmin()) then return end
    local ok, errors = FeatEffectSystem:ValidateWISNavigation()
    if ok then
        print("[LOD:RPG-E] WIS Navigation feat family PASS — 3/3 feats, replacement, drain order/floor")
    else
        ErrorNoHalt("[LOD:RPG-E] WIS Navigation feat family FAILED\n")
        for _, message in ipairs(errors) do ErrorNoHalt("[LOD:RPG-E]  - " .. message .. "\n") end
    end
end)

concommand.Add("lod_rpg_gate_e_ammo_validate", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or (IsValid(ply) and not ply:IsAdmin()) then return end
    local ok, errors = FeatEffectSystem:ValidateAmmoRegenFloor()
    if ok then
        print("[LOD:RPG-E] INT Ammo-Regen feat family PASS — 3/3 ranks, ceilings, cadence preserved")
    else
        ErrorNoHalt("[LOD:RPG-E] INT Ammo-Regen feat family FAILED\n")
        for _, message in ipairs(errors or {}) do ErrorNoHalt("[LOD:RPG-E]  - " .. message .. "\n") end
    end
end)

concommand.Add("lod_rpg_gate_e_regen_status", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or (IsValid(ply) and not ply:IsAdmin()) then return end
    if not IsValid(ply) then
        print("[LOD:RPG-E] Run this command from an attached player console.")
        return
    end
    local rules = LOD.RPGAbilityRules
    local derived = rules and rules:Derived(ply) or nil
    local maximum = math.max(1, ply:GetMaxHealth())
    local ceiling = math.floor(maximum * (tonumber(derived and derived.healthRegenCeilingFraction) or 0))
    local remaining = math.max(0, (ply.LODRPGHealthRegenEligibleAt or 0) - CurTime())
    local line = string.format("enabled=%s rank=%d HP=%d/%d ceiling=%d delay=%.2fs rate=%.2fHP/s",
        tostring(derived and derived.healthRegenEnabled == true),
        math.floor(tonumber(derived and derived.healthRegenRank) or 0),
        ply:Health(), maximum, ceiling, remaining,
        FeatEffectSystem:HealthRegenPerSecond(maximum,
            derived and derived.conRegenMultiplier,
            derived and derived.healthRegenBaseMaxHPPerSecond))
    print("[LOD:RPG-E] " .. line)
    ply:ChatPrint(line)
end)

concommand.Add("lod_rpg_test_regen", function(ply, _, args)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or not IsValid(ply) or not ply:IsAdmin() then return end
    local run = LOD.RunManager
    local ps = run and run:GetPlayerState(ply) or nil
    local state = ps and ps.progressionState or nil
    local progression = LOD.CharacterProgressionSystem
    if not state or not progression then
        ply:ChatPrint("RPG progression state is unavailable.")
        return
    end
    local rank = math.Clamp(math.floor(tonumber(args[1]) or 1), 0, 3)
    local kept = {}
    for _, featId in ipairs(state.featIds or {}) do
        if not REGEN_RANKS[featId] then kept[#kept + 1] = featId end
    end
    state.featIds = kept
    for featId in pairs(REGEN_RANKS) do state.featStackCounts[featId] = nil end
    local chain = {"CON_REGEN_11", "CON_REGEN_22", "CON_REGEN_33"}
    for index = 1, rank do
        state.featIds[#state.featIds + 1] = chain[index]
        state.featStackCounts[chain[index]] = 1
    end
    progression:_RecomputeProgressionState(state)
    progression:_ApplyPlayerMaxHP(ply, state)
    if rank > 0 then ply:SetHealth(1) end
    progression:SyncPlayer(ply)
    FeatEffectSystem:TrackActor(ply, rank > 0)
    if run.MarkUnranked then run:MarkUnranked("Gate E Health-Regeneration feat test") end
    ply:ChatPrint(string.format("Gate E regen rank %d configured%s.", rank,
        rank > 0 and "; HP set to 1 and the 5-second delay started" or ""))
end)

concommand.Add("lod_rpg_gate_e_navigation_status", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or (IsValid(ply) and not ply:IsAdmin()) then return end
    if not IsValid(ply) then
        print("[LOD:RPG-E] Run this command from an attached player console.")
        return
    end
    local rules = LOD.RPGAbilityRules
    local derived = rules and rules:Derived(ply) or nil
    local progressionState = rules and rules:ProgressionState(ply) or nil
    local baseDrain = 100 / 15
    local finalDrain = rules and rules.MapDrainPerSecond
        and rules:MapDrainPerSecond(ply, baseDrain) or baseDrain
    local line = string.format(
        "WIS=%d mod=%+d crumbs=%d featBonus=%d featRank=%d mapUtilityx=%.2f featDrainx=%.2f finalDrain=%.2f/s floor=%.2f/s open=%s",
        math.floor(tonumber(progressionState and progressionState.effectiveAbilities
            and progressionState.effectiveAbilities.wis) or 0),
        math.floor(tonumber(derived and derived.wisMod) or 0),
        rules and rules:BreadcrumbCells(ply) or 6,
        math.floor(tonumber(derived and derived.breadcrumbFeatBonusCells) or 0),
        math.floor(tonumber(derived and derived.breadcrumbFeatRank) or 0),
        rules and rules:UtilityMagicCostMultiplier(ply) or 1,
        tonumber(derived and derived.mapDrainFeatMultiplier) or 1,
        finalDrain,
        tonumber(derived and derived.minimumMapDrainPerSecond) or 0,
        tostring(ply:GetNW2Bool("LOD_MapMagicActive", false)))
    print("[LOD:RPG-E] " .. line)
    ply:ChatPrint(line)
end)

concommand.Add("lod_rpg_test_navigation", function(ply, _, args)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or not IsValid(ply) or not ply:IsAdmin() then return end
    local run = LOD.RunManager
    local ps = run and run:GetPlayerState(ply) or nil
    local state = ps and ps.progressionState or nil
    local progression = LOD.CharacterProgressionSystem
    if not state or not progression then
        ply:ChatPrint("RPG progression state is unavailable.")
        return
    end
    local mode = math.Clamp(math.floor(tonumber(args[1]) or 1), 0, 2)
    local navigationFeats = {
        WIS_SURVEYOR = true,
        WIS_CARTOGRAPHER = true,
        WIS_FRUGAL_MAP = true
    }
    local kept = {}
    for _, featId in ipairs(state.featIds or {}) do
        if not navigationFeats[featId] then kept[#kept + 1] = featId end
    end
    state.featIds = kept
    for featId in pairs(navigationFeats) do state.featStackCounts[featId] = nil end
    if mode >= 1 then
        state.featIds[#state.featIds + 1] = "WIS_CARTOGRAPHER"
        state.featStackCounts.WIS_CARTOGRAPHER = 1
    end
    if mode >= 2 then
        state.featIds[#state.featIds + 1] = "WIS_FRUGAL_MAP"
        state.featStackCounts.WIS_FRUGAL_MAP = 1
    end
    progression:_RecomputeProgressionState(state)
    progression:SyncPlayer(ply)
    if run.MarkUnranked then run:MarkUnranked("Gate E WIS Navigation feat test") end
    ply:ChatPrint(string.format(
        "Gate E navigation mode %d configured (0=none, 1=Cartographer, 2=Cartographer + Frugal).",
        mode))
end)

concommand.Add("lod_rpg_gate_e_ammo_status", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or (IsValid(ply) and not ply:IsAdmin()) then return end
    if not IsValid(ply) then
        print("[LOD:RPG-E] Run this command from an attached player console.")
        return
    end
    local rules = LOD.RPGAbilityRules
    local derived = rules and rules:Derived(ply) or nil
    local ammo = LOD.DiceAmmo
    local details = {}
    for _, profile in ipairs(ammo and ammo.RegenProfileSnapshot
        and ammo:RegenProfileSnapshot(ply) or {}) do
        details[#details + 1] = string.format("%s=%d/%d floor=%d interval=%.2fs",
            profile.label, profile.total, profile.cap, profile.floor,
            profile.roundIntervalSeconds)
    end
    local line = string.format("rank=%d floorFraction=%.2f %s",
        math.floor(tonumber(derived and derived.ammoRegenFloorRank) or 0),
        tonumber(derived and derived.ammoRegenFloorFraction) or 0.33,
        #details > 0 and table.concat(details, " ") or "no eligible owned firearm")
    print("[LOD:RPG-E] " .. line)
    ply:ChatPrint(line)
end)

concommand.Add("lod_rpg_test_ammo_floor", function(ply, _, args)
    local cv = GetConVar("lod_developer_mode")
    if not cv or not cv:GetBool() or not IsValid(ply) or not ply:IsAdmin() then return end
    local run = LOD.RunManager
    local ps = run and run:GetPlayerState(ply) or nil
    local state = ps and ps.progressionState or nil
    local progression = LOD.CharacterProgressionSystem
    if not state or not progression then
        ply:ChatPrint("RPG progression state is unavailable.")
        return
    end
    local rank = math.Clamp(math.floor(tonumber(args[1]) or 1), 0, 3)
    local kept = {}
    for _, featId in ipairs(state.featIds or {}) do
        if not AMMO_FLOOR_RANKS[featId] then kept[#kept + 1] = featId end
    end
    state.featIds = kept
    for featId in pairs(AMMO_FLOOR_RANKS) do state.featStackCounts[featId] = nil end
    local chain = {"INT_AMMO_FLOOR_44", "INT_AMMO_FLOOR_55", "INT_AMMO_FLOOR_66"}
    for index = 1, rank do
        local featId = chain[index]
        state.featIds[#state.featIds + 1] = featId
        state.featStackCounts[featId] = 1
    end
    progression:_RecomputeProgressionState(state)
    progression:SyncPlayer(ply)
    if run.MarkUnranked then run:MarkUnranked("Gate E INT Ammo-Regen feat test") end
    ply:ChatPrint(string.format(
        "Gate E ammo-regeneration rank %d configured (0=33%%, 1=44%%, 2=55%%, 3=66%%).",
        rank))
end)

return FeatEffectSystem

