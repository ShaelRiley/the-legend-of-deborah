local native=dofile
dofile=function(p) if p=="gamemodes/legend_of_deborah/gamemode/lod/sv_safe_teleport.lua" then return native(".build/autonomous-playtest-20261027/bug016-body-binding/sv_safe_teleport.source15.lua") end return native(p) end
dofile("tools/test_warp_hole.lua")
