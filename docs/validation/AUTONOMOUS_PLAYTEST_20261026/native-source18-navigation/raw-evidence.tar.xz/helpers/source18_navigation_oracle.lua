-- One-shot diagnostic only. Never calls FindPath/CanTraverse (they write graph
-- caches), map requests, collection, net sends, gameplay hooks or actor setters.
local expected={sv_minimap="918647339",cl_minimap="538781210",sv_floor_maps="2035166803",sv_phase_zero_runtime_optimization="3469563351"}
for name,crc in pairs(expected) do
    assert(util.CRC(file.Read("gamemodes/legend_of_deborah/gamemode/lod/"..name..".lua","GAME"))==crc,"wrong navigation source: "..name)
end
assert(game.GetMap()=="gm_flatgrass","expected native map")
local realm=SERVER and "server" or "client"
local p=SERVER and player.GetHumans()[1] or LocalPlayer()
assert(IsValid(p) and p:IsPlayer(),"real player required")
local function vec(v) return {v.x,v.y,v.z} end
local function cell(c) return c and {x=c.x,y=c.y,z=c.z} or nil end
local function key(c) return c and (c.x..":"..c.y..":"..c.z) or nil end
local function edge(a,b) return a<b and (a.."|"..b) or (b.."|"..a) end
local function copy4(t) local out={} for i=1,4 do out[i]=t and t[i]==true or false end return out end
local r={kind="source18_readonly_navigation_oracle",realm=realm,at=SysTime(),map=game.GetMap(),
    player_id=p:EntIndex(),player_birth=p:GetCreationID(),position=vec(p:GetPos()),alive=p:Alive(),
    NW_floor_mask=p:GetNW2Int("LOD_MapFloorMask",0),NW_build_serial=p:GetNW2Int("LOD_MapBuildSerial",0),
    NW_unlocked_level=p:GetNW2Int("LOD_MapUnlockedLevel",0),NW_internal_compass=p:GetNW2Bool("LOD_RPGInternalCompass",false),
    qualification="Developer read-only state/diagnostic BFS, not a new production routing authority or native traversal acceptance. No graph/cache/card/map/feat/player changes."}
if SERVER then
    local R,N,D=LOD.RunManager,LOD.MazeNavigator,LOD.EventDirector
    local s=R.State local g=assert(s.Graph)
    assert(#player.GetHumans()==1 and s.CampaignSeed==6102623 and s.BuildReady,"expected active sole-client campaign6102623")
    local MC=LOD.Config.Maze local pos=p:GetPos()
    local raw={x=math.floor((pos.x-MC.Origin.x)/MC.CellSize+(MC.Width+1)*.5+.5),
        y=math.floor((pos.y-MC.Origin.y)/MC.CellSize+(MC.Height+1)*.5+.5),z=math.floor((pos.z-MC.Origin.z)/MC.LevelHeight+.5)}
    local start=key(raw) local objective=LOD.ProgressionDirector:GetObjectiveGraphTarget()
    local goal=objective and key(objective.a)
    r.campaign=s.CampaignSeed r.level_seed=s.LevelSeed r.epoch=s.CampaignEpoch r.level=s.Level
    r.objective_stage=s.ObjectiveStage r.objective=objective r.raw_cell=raw r.raw_cell_exists=g.Cells[start]~=nil
    r.origin=vec(MC.Origin) r.cards=copy4(s.Cards) r.gates=copy4(s.GatesOpen)
    local blocked,events={},{}
    for i,m in ipairs(g.Progression.Gates or {}) do if not (s.GatesOpen and s.GatesOpen[i]) then blocked[m.edgeKey]="progression_gate_"..i end end
    if D.Context and D.Context.graph==g then
        for _,i in ipairs(D.Context.plan.instances) do
            if i.contract=="BLOCKADE" and D:IsCurrent(i) and i.state~="resolved" then
                events[i.placement.edgeKey]=i
            end
        end
    end
    local function allowed(a,b,ignoreEvents)
        local e=edge(a,b)
        return not blocked[e] and (ignoreEvents or not events[e])
            and (not N.CanTraverseProgressionDoors or N:CanTraverseProgressionDoors(g,a,b))
    end
    local function pathTo(wanted,ignoreEvents)
        if not g.Cells[start] or not wanted or not g.Cells[wanted] then return nil end
        local queue,seen,previous,at={start},{[start]=true},{},1
        while queue[at] do
            local a=queue[at] at=at+1
            if a==wanted then
                local reverse,route={},{} local k=a
                while k do reverse[#reverse+1]=k k=previous[k] end
                for j=#reverse,1,-1 do route[#route+1]=reverse[j] end return route
            end
            local neighbors={} for b in pairs(g.Cells[a].neighbors or {}) do neighbors[#neighbors+1]=b end table.sort(neighbors)
            for _,b in ipairs(neighbors) do
                if not seen[b] and g.Cells[b] and allowed(a,b,ignoreEvents) then seen[b]=true previous[b]=a queue[#queue+1]=b end
            end
        end
    end
    local function routeSummary(path)
        if not path then return {exists=false} end
        local out={exists=true,edges=#path-1,prefix={},first_floor_change=nil}
        for i,k in ipairs(path) do
            if i<=25 then out.prefix[#out.prefix+1]=cell(g.Cells[k]) end
            if i>1 and not out.first_floor_change and g.Cells[k].z~=g.Cells[path[i-1]].z then out.first_floor_change={from=cell(g.Cells[path[i-1]]),to=cell(g.Cells[k])} end
        end return out
    end
    local legal,hypothetical=pathTo(goal,false),pathTo(goal,true)
    r.diagnostic_legal_route=routeSummary(legal)
    r.diagnostic_ignore_only_event_blockades=routeSummary(hypothetical)
    r.classification=legal and "legal route exists: compare current server Compass/client display"
        or hypothetical and "event-barrier-consistent; confirm approachable live Skeleton and ordinary defeat/opening"
        or "no route under retained gate/jail/arena locks; inspect exact current objective/topology, not a confirmed defect"
    r.active_blockades={}
    for e,i in pairs(events) do
        local path=pathTo(i.placement.cellKey,false)
        r.active_blockades[#r.active_blockades+1]={id=i.id,archetype=i.archetype,state=i.state,edge=e,
            approach_cell=i.placement.cellKey,approach=routeSummary(path),
            hostile_id=IsValid(i.hostile) and i.hostile:EntIndex() or nil,
            hostile_alive=IsValid(i.hostile) and not i.hostile.LODDead and i.hostile:Health()>0,
            barrier_id=IsValid(i.barrier) and i.barrier:EntIndex() or nil,
            barrier_open=IsValid(i.barrier) and i.barrier:GetOpened() or false}
    end
    local maps=s.FloorMaps r.floor_maps={}
    if maps and maps.graph==g then
        r.party_mask=maps.mask r.party_map_serial=maps.serial
        for z,row in pairs(maps.plan.maps) do
            local waypoints={}
            for j=#row.path,1,-1 do local c=g.Cells[row.path[j]] if c then waypoints[#waypoints+1]={cell=cell(c),center={MC.Origin.x+(c.x-(MC.Width+1)*.5)*MC.CellSize,MC.Origin.y+(c.y-(MC.Height+1)*.5)*MC.CellSize,MC.Origin.z+c.z*MC.LevelHeight}} end end
            r.floor_maps[#r.floor_maps+1]={floor_zero_based=z,owned=maps.owned[z]==true,cell=cell(row.cell),entrance=cell(row.entrance),
                pickup_id=IsValid(row.entity) and row.entity:EntIndex() or nil,
                pickup_anchor=IsValid(row.entity) and vec(row.entity:GetPickupPosition()) or nil,
                protected_same_floor_entrance_walk=waypoints,distance=row.distance}
        end
    end
    local cache=g.LODPhaseZeroNavCache local tree=cache and cache.trees and cache.trees[start]
    r.existing_nav_cache={present=cache~=nil,signature=cache and cache.signature,events=cache and cache.events,
        current_start_tree_present=tree~=nil,objective_distance=tree and goal and tree.distance[goal] or nil}
else
    local m,s=assert(LOD.Minimap),assert(LOD.ClientState)
    local reach=m.cache and m.cache.reach local trail=m.compass
    r.state_synchronized=s.synchronized r.level=s.level r.objective_stage=s.objectiveStage r.objective=cell(s.objectiveA)
    r.cards=copy4(s.cards) r.gates=copy4(s.gates) r.map_open=m.open r.map_level=m.level r.layers=m.layers
    r.map_floor_mask=m.floorMask r.map_build_serial=m.buildSerial r.expected_cells=m.expectedCells
    r.received_cells=#m.cells r.expected_chunks=m.expectedChunks r.received_chunks=m.receivedChunks
    r.current_config_origin=vec(LOD.Config.Maze.Origin)
    r.client_compass=trail and {level=trail.level,serial=trail.serial,floor=trail.floor,stage=trail.stage,gates=trail.gates,
        origin=cell(trail.origin),length=trail.length,points=trail.points} or nil
    r.cached_display=reach and {start_key=reach.startKey,valid_trail=reach.validTrail,route_status=reach.routeStatus,has_route=reach.route~=nil} or nil
end
local name="legend_of_deborah/source18_navigation_oracle_"..realm.."_"..math.floor(SysTime()*1000)..".json"
file.Write(name,util.TableToJSON(r,true))
print("NAVIGATION_ORACLE18="..util.TableToJSON({file=name,realm=realm,classification=r.classification,map_open=r.map_open,party_mask=r.party_mask}))
