from pathlib import Path
import subprocess,time,json,hashlib
ROOT=Path('/home/deck/Downloads/the-legend-of-deborah')
OUT=Path('/home/deck/Downloads/the-legend-of-deborah/.build/autonomous-playtest-20261027/gate-overhead-ci-fixture')
commands=[('geometry-fullupdate', ['python3', 'tools/run_lua54.py', 'tools/test_geometry_fullupdate.lua']), ('crate-geometry', ['python3', 'tools/run_lua54.py', 'tools/test_great_crate_geometry.lua']), ('stair-headroom', ['python3', 'tools/run_lua54.py', 'tools/test_stair_headroom.lua']), ('semantic-negative-control', ['python3', 'tools/run_lua54.py', '/home/deck/Downloads/the-legend-of-deborah/.build/autonomous-playtest-20261027/gate-overhead-ci-fixture/semantic-negative-control.lua'])]
results=[]
for name,command in commands:
 started=time.monotonic();r=subprocess.run(command,cwd=ROOT,capture_output=True,timeout=600)
 (OUT/(name+".stdout.txt")).write_bytes(r.stdout);(OUT/(name+".stderr.txt")).write_bytes(r.stderr)
 results.append({"name":name,"command":command,"returncode":r.returncode,"seconds":round(time.monotonic()-started,3)})
 print(name,r.returncode,flush=True)
(OUT/"adjacent-results.json").write_text(json.dumps(results,indent=2)+"\n")
assert all(r["returncode"]==0 for r in results[:-1])
assert results[-1]["returncode"]!=0 and "Native gate initialization must publish its stock body to the server model table" in (OUT/"semantic-negative-control.stderr.txt").read_text()
print("ADJACENT_AND_NEGATIVE_PASS",flush=True)
