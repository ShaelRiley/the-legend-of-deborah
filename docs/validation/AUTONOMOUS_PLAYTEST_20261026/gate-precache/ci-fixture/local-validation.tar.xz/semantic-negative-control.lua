local actual=dofile
dofile=function(path)
 if path=="gamemodes/legend_of_deborah/entities/entities/lod_gate/init.lua" then return actual("/home/deck/Downloads/the-legend-of-deborah/.build/autonomous-playtest-20261027/gate-overhead-ci-fixture/gate-init-before-precache.lua") end
 return actual(path)
end
actual("tools/test_maze_overhead_walls.lua")
