from pathlib import Path
import concurrent.futures,ctypes,ctypes.util,hashlib,json,subprocess,time
ROOT=Path('/home/deck/Downloads/the-legend-of-deborah')
OUT=ROOT/'.build/autonomous-playtest-20261027/gate-precache-repair'
CHANGED=['gamemodes/legend_of_deborah/entities/entities/lod_gate/init.lua','tools/test_great_crate_gates.lua','tools/dungeon_event_fixture.lua']
def digest(data):return hashlib.sha256(data).hexdigest()
def manifest():
 files=subprocess.check_output(['git','ls-files','gamemodes','lua','tools'],cwd=ROOT,text=True).splitlines()
 return {name:digest((ROOT/name).read_bytes()) for name in files if Path(name).suffix in {'.lua','.py','.json','.sh'}}
before=manifest();(OUT/'source-manifest-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
tests=[
 ('great-crate-gates',['python3','tools/run_lua54.py','tools/test_great_crate_gates.lua']),
 ('great-crate-hull-runtime',['python3','tools/run_lua54.py','tools/test_great_crate_hull_runtime.lua']),
 ('great-crate-geometry',['python3','tools/run_lua54.py','tools/test_great_crate_geometry.lua']),
 ('great-crate-render',['python3','tools/run_lua54.py','tools/test_great_crate_render.lua']),
 ('progression-stock-props',['python3','tools/run_lua54.py','tools/test_progression_stock_props.lua']),
 ('gate-enemy-engagement',['python3','tools/run_lua54.py','tools/test_gate_enemy_engagement.lua']),
 ('geometry-fullupdate',['python3','tools/run_lua54.py','tools/test_geometry_fullupdate.lua']),
 ('neil-brute',['python3','tools/run_lua54.py','tools/test_neil_brute.lua']),
 ('event-quiz-generation',['python3','tools/test_crypto_sqlite.py','tools/test_event_quiz_generation.lua']),
 ('event-skeleton-blockade',['python3','tools/test_crypto_sqlite.py','tools/test_event_skeleton_blockade.lua']),
 ('event-skeleton-lifecycle',['python3','tools/test_crypto_sqlite.py','tools/test_event_skeleton_lifecycle.lua']),
 ('source-manifest',['python3','tools/test_dev_population_manifest.py']),
 ('changed-lua-syntax',['python3','tools/run_lua54.py','--syntax',*CHANGED])]
def run(item,cwd=ROOT):
 name,command=item;started=time.monotonic()
 result=subprocess.run(command,cwd=cwd,capture_output=True,timeout=600)
 (OUT/(name+'.stdout.txt')).write_bytes(result.stdout);(OUT/(name+'.stderr.txt')).write_bytes(result.stderr)
 receipt={'name':name,'command':command,'returncode':result.returncode,'seconds':round(time.monotonic()-started,3),'stdout_sha256':digest(result.stdout),'stderr_sha256':digest(result.stderr)}
 (OUT/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,result.returncode,flush=True);return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,tests))
negative=run(('original-source-negative-control',['python3',str(ROOT/'tools/run_lua54.py'),'tools/test_great_crate_gates.lua']),OUT/'before-source')
negative_expected=negative['returncode']!=0 and 'Fresh server gate must make its stock body eligible on the client' in (OUT/'original-source-negative-control.stderr.txt').read_text()
library=ctypes.CDLL(ctypes.util.find_library('luajit-5.1'));library.luaL_newstate.restype=ctypes.c_void_p
library.luaL_loadfile.argtypes=[ctypes.c_void_p,ctypes.c_char_p];library.luaL_loadfile.restype=ctypes.c_int
library.lua_close.argtypes=[ctypes.c_void_p];compiled=[]
for name in CHANGED:
 state=library.luaL_newstate()
 try:
  assert library.luaL_loadfile(state,str(ROOT/name).encode())==0,'LuaJIT compile failed: '+name
  compiled.append(name)
 finally:library.lua_close(state)
after=manifest();changed=[name for name in before if before[name]!=after.get(name)]
receipt={'kind':'BUG011 targeted static gate; not native acceptance','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'tests':results,'passed':sum(x['returncode']==0 for x in results),'total':len(results),'original_source_negative_control':negative,'negative_control_failed_as_expected':negative_expected,'luajit_compile_only':compiled,'source_unchanged':before==after,'changed_during_gate':changed,'native_gmod_accepted':False}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert all(x['returncode']==0 for x in results) and negative_expected and before==after
print('TARGETED_GATE_PASS',len(results),'LuaJIT',len(compiled),'negative-control expected failure; source unchanged',flush=True)
