dofile("tools/test_equipment_economy_runtime.lua")
local E=LOD.Equipment local biggest={bytes=0} local count=0
for family,def in pairs(E.Definitions) do if def.weapon or def.wearable then for _,level in ipairs({1,20,999}) do for seed=1,100 do local i=E:Generate(seed,level,family,"tooltip-size:"..seed) local text=E:ItemName(i).."\n"..E:Description(i).."\n"..def.name count=count+1 if #text>biggest.bytes then biggest={bytes=#text,family=family,level=level,seed=seed} end end end end end
print("GENERATED_TOOLTIP_SIZE_SAMPLE",count,biggest.bytes,biggest.family,biggest.level,biggest.seed)
