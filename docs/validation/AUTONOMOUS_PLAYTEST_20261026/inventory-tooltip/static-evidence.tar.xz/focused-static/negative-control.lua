local native=dofile
dofile=function(path)
 if path=="gamemodes/legend_of_deborah/gamemode/lod/cl_equipment_inventory.lua" then return native(".build/autonomous-playtest-20261027/bug010-tooltip/before-cl_equipment_inventory.lua") end
 return native(path)
end
native("tools/test_equipment_inventory_ui.lua")
