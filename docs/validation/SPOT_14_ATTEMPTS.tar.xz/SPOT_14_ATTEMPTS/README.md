# SPOT-14 attempt provenance

All attempt directories are retained without changing their outcome. Each executed
wrapped command has raw.log, receipt.json and its pre-command full source SHA256
manifest. These manifests identify the source but are not copies of every earlier
source file. preparation-01 retains the exact preparation script and failure note;
its original complete stdout was not captured. No gameplay test ran in that step.
The current final candidate patch is supplied separately. Manual export/build are
mutating preparation commands, not frozen-source gates. Earlier passes do not prove
the later reviewed source; the final aggregate reruns applicable production paths.
No native GMod, full campaign matrix, Workshop or VPS claim follows from this archive.
