from pathlib import Path
R=Path('/mnt/data/the-legend-of-deborah'); L=R/'gamemodes/legend_of_deborah/gamemode/lod'
(L/'sv_rpg_time_management.lua').write_text('''-- SPOT-14: registered ordinary feat; the existing clock owns presence/accounting.
local RPG = assert(LOD.RPG)
local Catalog = assert(RPG.IdentityCatalog)
local Feats = assert(Catalog.OrdinaryFeats)
local Effects = assert(RPG.FeatEffectSystem)
local ID = "INT_TIME_MANAGEMENT"
assert(not Feats[ID], "duplicate canonical feat " .. ID)
Feats[ID] = {
    featId=ID, displayName="Time Management", featFamilyId="int_time_management", rankIndex=1,
    replacesLowerRank=false, repeatableFallback=false, oneRank=true,
    governingAbilities={"int"}, abilityRequirements={int=17}, prerequisiteFeatIds={},
    requiredCapabilityTags={}, incompatibleFeatIds={}, allowedActorTypes={"hero"},
    requiredSubsystemTags={}, synergyTags={"intelligence", "utility"},
    effectHandlerId="time_management", directorBaseWeight=1.0,
    eligibilityText="INT 17", actorText="Cooperative Heroes only",
    effectParams={secondsPerIntBonus=60, description="While alive and deployed, add your positive effective INT modifier in minutes to the shared dungeon clock. Different Heroes stack. Death, leaving or Soldier play removes your allowance; losing it can cause TIME OVER. Returning restores only that allowance, never elapsed time or an expired clock. No Magic cost."}
}

-- Consume canonical recomputed effective INT. Qualification remains FeatDirector's
-- job (including Winning Personality); temporary gear never rewrites ownership.
function Effects:TimeManagementSeconds(state)
    local owned = false
    for _, id in ipairs(state and state.featIds or {}) do
        if id == ID then owned = true; break end
    end
    if not owned then return 0 end
    local modifier = tonumber(state.derivedStats and state.derivedStats.intMod) or 0
    if modifier ~= modifier or modifier == math.huge or modifier == -math.huge then return 0 end
    return math.Clamp(math.floor(modifier), 0, 10) * Feats[ID].effectParams.secondsPerIntBonus
end
''')
p=R/'gamemodes/legend_of_deborah/gamemode/shared.lua'
s=p.read_text();needle='    include("lod/sv_feat_card_text.lua")';assert s.count(needle)==1
p.write_text(s.replace(needle,'    include("lod/sv_rpg_time_management.lua")\n'+needle))
# Clock-local records; a deployed body is admitted only after the existing actual
# deployment boundary. Subsequent syncs update known records, never admit a body.
p=L/'sv_campaign_timeout.lua';s=p.read_text()
needle='function T:Sync(ply)\n';assert s.count(needle)==1
block='''-- SPOT-14: this is a reversible component of this exact clock, not an extension
-- transaction. Only bodies admitted at completed deployment enter this bounded
-- map. The ordinary service inspects it; no connected-player/world scan is added.
function T:TimeManagementPresence(ply, record)
    local s = Run.State
    local ps = IsValid(ply) and Run:GetPlayerState(ply) or nil
    if not ps or not ply:IsPlayer() or ply.LODTimeManagementDisconnected
        or not ply:Alive() or ply.LODHandledRunDeath or ps.eliminated or (ps.lives or 0) <= 0
        or ps ~= record.ps or ps.progressionState ~= record.progression
        or ps.heroSerial ~= record.heroSerial or Run:IdentityOf(ply) ~= record.identity
        or Run:IsSoldierControl(ply) or not Run:IsDungeonPlayer(ply)
        or ps.deploymentComplete ~= true or ps.deployedDungeonLevel ~= s.Level then
        record.heldSeconds = nil
        return false
    end
    -- Internal same-dungeon reconstruction may temporarily Spectate/Spawn an
    -- otherwise present Hero. Real death/role/disconnect invalidation above still
    -- wins; a completed deployment replaces this frozen, never-growing value.
    if record.heldSeconds ~= nil then return true end
    return s.BuildReady == true and s.Graph ~= nil and ps.respawnAt == nil
        and ply.LODRunInventoryReady == true and ply.LODRunSpawnSerial == record.life
        and ply:GetObserverMode() == OBS_MODE_NONE and not ply:GetNW2Bool("LOD_Staged", false)
        and ply:GetNW2Bool("LOD_Deployed", false)
end

function T:RegisterTimeManagement(ply)
    local ps = IsValid(ply) and Run:GetPlayerState(ply) or nil
    if not ps or not ps.progressionState then return false end
    local record = {ps=ps, progression=ps.progressionState, heroSerial=ps.heroSerial,
        identity=Run:IdentityOf(ply), life=ply.LODRunSpawnSerial, seconds=0}
    if not record.identity or not self:TimeManagementPresence(ply, record) then return false end
    local c = self:Clock()
    c.timeManagementActors = c.timeManagementActors or {}
    c.timeManagementActors[ply] = record
    return true
end

function T:ReconcileTimeManagement()
    local s, c, now = Run.State, self:Clock(), SysTime()
    -- Crucially, never let a late stat/role/join update revive an expired clock.
    if c.reconcilingTimeManagement or not c.deadline or c.scene or s.Failed or s.LevelCleared
        or now >= c.deadline then return false end
    c.reconcilingTimeManagement = true
    local effects = LOD.RPG and LOD.RPG.FeatEffectSystem
    local identities, recipients, total = {}, {}, 0
    for ply, record in pairs(c.timeManagementActors or {}) do
        local value = 0
        if self:TimeManagementPresence(ply, record) and effects and effects.TimeManagementSeconds then
            value = record.heldSeconds or effects:TimeManagementSeconds(record.progression)
        end
        record.seconds = value
        -- A duplicated identity/body can never stack with itself. Ordinary
        -- RunManager admission still owns the actual player/role slot.
        identities[record.identity] = math.max(identities[record.identity] or 0, value)
        if IsValid(ply) and not ply.LODTimeManagementDisconnected then
            recipients[#recipients+1] = ply
        else
            c.timeManagementActors[ply] = nil
        end
    end
    for _, seconds in pairs(identities) do total = total + seconds end
    local delta = total - (c.timeManagementSeconds or 0)
    c.timeManagementSeconds = total
    c.deadline = c.deadline + delta
    c.reconcilingTimeManagement = nil
    if delta == 0 then return false end
    local remaining = self:Remaining(c, now)
    for threshold in pairs(c.warned or {}) do
        if remaining > threshold then c.warned[threshold] = nil end
    end
    local fields = {event="time_management_changed", seconds=delta, allowance=total,
        remaining=remaining, epoch=s.CampaignEpoch, level=s.Level}
    log("TIME_MANAGEMENT_CHANGED", fields)
    local rolls = LOD.CombatRolls
    if rolls and rolls._Send and #recipients > 0 then
        rolls:_Send(recipients, 3, string.format("TIME MANAGEMENT — %+.0f seconds; party allowance %.0f minutes", delta, total/60),
            "resource", fields)
    end
    return true
end

function T:RefreshTimeManagement()
    local changed = self:ReconcileTimeManagement()
    if self:Expire() then return end
    if changed then self:Sync() end
end

function T:HoldTimeManagementForBuild()
    -- The pre-build expiry guard already reconciled the last actual presence.
    local c = self:Clock()
    if not c.deadline or c.scene or Run.State.Failed or Run.State.LevelCleared then return end
    for ply, record in pairs(c.timeManagementActors or {}) do
        if self:TimeManagementPresence(ply, record) then record.heldSeconds = record.seconds end
    end
end

'''
s=s.replace(needle,block+needle+'    if self:Expire() then return end\n')
old='''    if c.deadline or s.Failed or not s.BuildReady or s.LevelCleared
        or not Run:IsDungeonPlayer(ply) or Run:IsSoldierControl(ply) then return false end
    c.deadline = SysTime() + self.Duration'''
new='''    self:Expire()
    if s.Failed or c.scene or not s.BuildReady or s.LevelCleared
        or not Run:IsDungeonPlayer(ply) or Run:IsSoldierControl(ply) then return false end
    if c.deadline then
        self:RegisterTimeManagement(ply)
        self:RefreshTimeManagement()
        return false -- a later deployment still never restarts the clock
    end
    c.deadline = SysTime() + self.Duration
    self:RegisterTimeManagement(ply)
    self:ReconcileTimeManagement()'''
assert old in s;s=s.replace(old,new)
s=s.replace('    LOD.ProgressionDirector:Announce("PRISON COLLAPSE IN 30:00 — DUNGEON CLOCK STARTED")',
'''    local seconds = math.ceil(self:Remaining(c, SysTime()))
    LOD.ProgressionDirector:Announce(string.format("PRISON COLLAPSE IN %02d:%02d — DUNGEON CLOCK STARTED",
        math.floor(seconds/60), seconds%60))''')
s=s.replace('function T:ExtensionBinding()\n','function T:ExtensionBinding()\n    self:Expire()\n')
s=s.replace('function T:TryExtend(binding,commit)\n','function T:TryExtend(binding,commit)\n    self:Expire()\n')
s=s.replace('function T:Expire()\n','function T:Expire()\n    self:ReconcileTimeManagement()\n')
s=s.replace('''        if T:Clock().scene then return false,"TIME OVER" end
        local ok,result=base(self,...)''','''        if T:Clock().scene then return false,"TIME OVER" end
        if name == "BuildCurrentLevel" then T:HoldTimeManagementForBuild() end
        local ok,result=base(self,...)''')
needle='hook.Add("PlayerInitialSpawn","LOD_CampaignClockJoin",function(ply)\n'
add='''-- The normal spawn adapter returns only after Hero equipment/health, spectator
-- exit and position have committed. Initial staging uses Start at its own actual
-- deployment boundary. Neither early SyncPlayer nor PlayerSpawn can admit time.
local applyPlayerState = Run.ApplyPlayerState
function Run:ApplyPlayerState(ply, ...)
    local ok, result = applyPlayerState(self, ply, ...)
    if IsValid(ply) and ply:Alive() and ply.LODRunInventoryReady == true
        and not ply.LODHandledRunDeath and ply:GetObserverMode() == OBS_MODE_NONE
        and ply:GetNW2Bool("LOD_Deployed", false) and not ply:GetNW2Bool("LOD_Staged", false) then
        T:Start(ply)
    end
    return ok, result
end
local progression = LOD.CharacterProgressionSystem
if progression then
    local syncPlayer = progression.SyncPlayer
    function progression:SyncPlayer(ply, ...)
        local ok, result = syncPlayer(self, ply, ...)
        T:RefreshTimeManagement()
        return ok, result
    end
end
hook.Add("PlayerDisconnected", "LOD_CampaignClockLeave", function(ply)
    -- Set this even while the native entity is still valid. Later stale callbacks
    -- cannot readmit it; any replacement connection owns a different entity.
    ply.LODTimeManagementDisconnected = true
    T:RefreshTimeManagement()
end)
'''
assert needle in s;s=s.replace(needle,add+needle+'    ply.LODTimeManagementDisconnected = nil\n')
# Existing diagnostic remains one command and reports the current effective clock.
s=s.replace('''    print(string.format("[LOD:CLOCK] epoch=''','''    T:Expire()
    print(string.format("[LOD:CLOCK] allowance=%d seconds", c.timeManagementSeconds or 0))
    print(string.format("[LOD:CLOCK] epoch=''')
p.write_text(s)
# Extend, never relax, exact catalog inventory + actual shared-effect consumer.
p=R/'tools/test_checkpoint_d_closure.lua';s=p.read_text()
needle='local CANONICAL_FEATS = {\n';assert needle in s
s=s.replace(needle,needle+'    INT_TIME_MANAGEMENT = {ability = "int", req = {int = 17}, prereq = {}, family = "int_time_management", rank = 1, replaces = false},\n')
s=s.replace('local consumers = {\n','local consumers = {\n    time_management = Effects.TimeManagementSeconds,\n')
s=s.replace('135 ordinary feats and 9 capstones','136 ordinary feats and 9 capstones');p.write_text(s)
p=R/'tools/build_manual.py';s=p.read_text();assert 'len(feats)==135' in s;s=s.replace('len(feats)==135','len(feats)==136');p.write_text(s)
(R/'tools/test_spot14_gate.py').write_text('''#!/usr/bin/env python3
"""Finite SPOT-14 gate: all 85 SPOT-13 selections plus actual clock boundaries."""
import sys
import test_spot13_gate as inherited

gate = inherited.gate
gate.LABEL = 'SPOT14_GATE'
gate.SCOPE = 'SPOT-14 selected production/regression suites, not full campaign matrix'
gate.LUA += ['test_campaign_timeout.lua', 'test_spot14_time_management.lua']
if __name__ == '__main__':
    sys.exit(gate.main())
''')
