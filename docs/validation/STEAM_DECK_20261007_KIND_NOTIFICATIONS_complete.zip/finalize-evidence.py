"""Verify and package the recovered candidate after its complete frozen gate."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/c5c8aa2df0b3')
OLD = Path('/workspace/scratch/b6463ad6280a')
REPO = ROOT / 'the-legend-of-deborah'
PARENT = 'd02c9e4b5954f80bc7f8b549dc68328fbc5031ce'
PREFIX = 'STEAM_DECK_20261007_KIND_NOTIFICATIONS'
OUT = ROOT / 'resumed-matrix'
FOCUS = ROOT / 'isolated-focused'
PAIR = ROOT / 'isolated-paired'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

spec = importlib.util.spec_from_file_location('gate', REPO / 'tools/test_checkpoint_g_integration.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
matrix = read(OUT / 'receipt.json')
manifest = read(OUT / 'source_manifest.json')
assert gate.source_snapshot() == manifest, 'Source changed after the gate'
assert matrix['passed'] == matrix['total'] == len(gate.SUITES) == 313
assert matrix['lua_files'] == len(gate.LUA_FILES) == 884
assert not matrix['changed_during_gate']
assert matrix['source_before'] == matrix['source_after'] == gate.snapshot_digest(manifest)
assert [r['index'] for r in matrix['results']] == list(range(1, 314))
for row in matrix['results']:
    name, command = gate.SUITES[row['index'] - 1]
    assert row['name'] == name and row['command'] == command and row['returncode'] == 0
    assert read(OUT / (row['log_prefix'] + '.json')) == row
    for stream in ('stdout', 'stderr'):
        assert sha((OUT / (row['log_prefix'] + '.' + stream + '.txt')).read_bytes()) == row[stream + '_sha256']
focused = read(FOCUS / 'receipt.json')
assert focused['passed'] == focused['total'] == 29 and not focused['changed_during_gate']
assert focused['source_before'] == focused['source_after'] == matrix['source_before']
for row in focused['results']:
    assert row['returncode'] == 0 and row['passed']
    assert read(FOCUS / (row['name'] + '.json')) == row
    assert sha((FOCUS / row['log']).read_bytes()) == row['log_sha256']
paired = read(PAIR / 'receipt.json')
assert paired['parent_sha'] == PARENT and paired['submissions_equal']
for path, expected in paired['sources']['parent'].items():
    assert sha(subprocess.check_output(['git', 'show', PARENT + ':' + path], cwd=REPO)) == expected
for path, expected in paired['sources']['candidate'].items():
    assert manifest[path] == expected
for label, row in paired['results'].items():
    assert row['returncode'] == (1 if label == 'negative_control' else 0)
    for stream in ('stdout', 'stderr'):
        assert sha((PAIR / (label + '.' + stream)).read_bytes()) == row[stream + '_sha256']
    if 'signature_sha256' in row:
        assert sha((PAIR / (label + '.signature')).read_bytes()) == row['signature_sha256']
assert (PAIR / 'parent.signature').read_bytes() == (PAIR / 'candidate.signature').read_bytes()
assert paired['results']['parent']['native_kind_reads'] == 144000
assert paired['results']['candidate']['native_kind_reads'] == 0
assert paired['results']['candidate']['native_validity_calls'] == 14400
assert paired['results']['candidate']['signature_rows'] == 726
assert b'collision_entity_field_reads=0' in (PAIR / 'candidate.stdout').read_bytes()

native = read(OLD / 'kind-native.json')
perf_raw = (OLD / 'upload/performance_client_latest(20261007-202429).txt').read_text()
capture, _ = json.JSONDecoder().raw_decode(perf_raw[perf_raw.index('{'):])
assert capture == read(OLD / 'capture_202429.json')
assert capture['reason'] == 'complete' and not capture['preparation_timed_out']
assert capture['source'] == {'verified': True, 'checked': 14, 'mismatches': 0, 'missing': 0}
cpu = capture['cpu_profile']
assert cpu['server_status'] == 'received'
assert cpu['client']['reason'] == 'complete' and cpu['server']['reason'] == 'client-stop'
assert cpu['client']['seconds'] >= 180 and cpu['server']['seconds'] >= 180
native['profile_client_complete'] = True
native['profile_server_complete'] = True
native['recovered_summary_correction'] = 'Server completion verified from received client-stop profile, not literal reason complete.'
assert native['source_commit'] == PARENT and native['active'] == capture['active']
assert native['vr_idle_snapshots'] == 42 and native['zero_error_snapshots'] == 6
assert not capture['configuration_changes']
modules = capture['population']['source']['modules']
assert len(modules) == native['verified_git_modules'] == 44
for row in modules:
    exact = subprocess.check_output(['git', 'show', PARENT + ':' + row['path']], cwd=REPO)
    assert sha(exact) == row['installed'] == row['mounted']
for upload in native['uploads']:
    raw = (OLD / 'upload' / upload['name']).read_bytes()
    assert len(raw) == upload['bytes'] and sha(raw) == upload['sha256']
gdd = read(ROOT / 'governing-gdd.json')
assert gdd['documentId'] == '1OSpgiWyiGmUCLFdq--WmCSZe6KQIr7_UTkQZklPV8lY'
assert gdd['tabId'] == 't.bff19dm33vvw' and gdd['read_from_live_document']
changed = subprocess.check_output(['git', 'diff', '--name-only', PARENT], cwd=REPO).decode().splitlines()
checks = dict(parent_sha=PARENT, source_files=len(manifest),
              full_matrix={k:v for k,v in matrix.items() if k != 'results'},
              canonical_commands_verified=313, individual_receipts_verified=313,
              raw_stream_hashes_verified=626,
              full_gate_command=['python3', 'tools/test_checkpoint_g_integration.py', '--workers', '2',
                                 '--suite-timeout', '1800', '--output', str(OUT)],
              focused={k:v for k,v in focused.items() if k != 'results'},
              paired=paired, native=native, governing_gdd=gdd,
              changed_code_sha256={p:manifest[p] for p in changed if not p.startswith('docs/')},
              previous_attempts_preserved=True, cross_source_receipts_reused=False,
              verified_receipts_reused=matrix.get('recovery', {}).get('reused_verified_suites', 0),
              native_new_checkpoint_accepted=False)
files = {}
for folder, label in ((OUT, 'full-matrix'), (FOCUS, 'focused'), (PAIR, 'paired'),
                      (OLD / 'kind-parent', 'parent'), (OLD / 'kind-paired', 'earlier-paired'),
                      (OLD / 'kind-full', 'earlier-source-count-attempt'),
                      (OLD / 'kind-full-frozen', 'earlier-interrupted-attempt'),
                      (ROOT / 'isolated-matrix', 'interrupted-isolated-matrix'),
                      (ROOT / 'final-matrix', 'concurrent-edit-attempt'),
                      (ROOT / 'final-focused', 'concurrent-edit-focused')):
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            files[label + '/' + str(path.relative_to(folder))] = path.read_bytes()
for path, name in ((ROOT / 'resumed-matrix-driver.log', 'full-matrix/driver.log'),
                   (ROOT / 'isolated-matrix.log', 'interrupted-isolated-matrix/driver.log'),
                   (ROOT / 'resume_matrix.py', 'full-matrix/recovery-driver.py'),
                   (ROOT / 'final-matrix.log', 'concurrent-edit-attempt/driver.log'),
                   (ROOT / 'interrupted-validation.json', 'concurrent-edit-attempt/interruption.json'),
                   (ROOT / 'isolated-focused.log', 'focused/driver.log'),
                   (ROOT / 'governing-gdd.json', 'governing-gdd.json'),
                   (ROOT / 'parent-actions.json', 'parent-actions.json'),
                   (ROOT / 'run_isolated_pair.py', 'reproduce-pair.py'),
                   (ROOT / 'finalize_evidence.py', 'finalize-evidence.py'),
                   (OLD / 'capture_202429.json', 'native/parsed-capture.json'),
                   (OLD / 'kind-native.json', 'earlier-native-summary.json'),
                   (OLD / 'kind-full-frozen.log', 'earlier-interrupted-attempt/driver.log'),
                   (OLD / 'kind-full.log', 'earlier-source-count-attempt/driver.log')):
    files[name] = path.read_bytes()
for upload in native['uploads']:
    files['native/' + upload['name']] = (OLD / 'upload' / upload['name']).read_bytes()
for path in checks['changed_code_sha256']:
    files['tested-source/' + path] = (REPO / path).read_bytes()
files['native/summary.json'] = (json.dumps(native, indent=2) + '\n').encode()
files['verified-checks.json'] = (json.dumps(checks, indent=2) + '\n').encode()
files['REPRODUCE.md'] = b'''# Recovered exact-source gate

Run the command in verified-checks.json from the repository, with a new output
directory outside it. The complete gate has 313 canonical suites, 884 Lua syntax
files and unchanged pre/post source bytes. This local machine allowed 1800 seconds
per suite: the earlier 600-second B23 campaign attempt timed out. No suite, assertion,
seed or workload was removed. The interrupted isolated gate supplies 120
hash-verified passing canonical receipts under the unchanged complete source
manifest; its remaining 193 suites run fresh. recovery.json and the archived
recovery-driver.py preserve that procedure; cross-source attempts are not reused.

Focused: python3 tools/test_low_end_render_gate.py --workers 1 --suite-timeout 120
--output /absolute/new-directory. Pair: python3 tools/run_lua54.py
tools/test_low_end_render.lua --kind-probe <mesh.lua> <entity.lua> <signature>
<shared.lua>. Use archived parent sources and tested candidate sources. Native
kind reads must be 144000 versus zero, validity calls 144000 versus 14400,
and all 726 signature rows identical. The exact parent fails the --source work gate.

Earlier attempts retain their raw logs, source manifests and failures. Their
production bytes differ from this candidate. They are historical evidence only.
The source gate precedes final documentation and archive packaging; final production
and test bytes are verified against changed_code_sha256 before publication.
Native uploads describe the parent build. Their profiles and rendering observations
do not establish this candidate's FPS or native visuals; the 40-FPS target is open.
'''
patterns = [rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',
            rb'\bgh[pousr]_[A-Za-z0-9]{20,}\b', rb'\bgithub_pat_[A-Za-z0-9_]{20,}\b',
            rb'sv_setsteamaccount\s+["\']?[A-Fa-f0-9]{25,}']
for name, data in files.items():
    assert not any(re.search(p, data) for p in patterns), 'Credential-looking bytes in ' + name
files['archive-manifest.json'] = (json.dumps({name:dict(bytes=len(data), sha256=sha(data))
    for name,data in sorted(files.items())}, indent=2) + '\n').encode()
base = REPO / 'docs/validation' / PREFIX
archive = Path(str(base) + '_complete.zip')
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name,data in sorted(files.items()):
        info = zipfile.ZipInfo(name, (2026, 10, 7, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        z.writestr(info, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(files)
    for name,data in files.items():
        assert z.read(name) == data
checks.update(archive_name=archive.name, archive_bytes=archive.stat().st_size,
              archive_sha256=sha(archive.read_bytes()), archive_entries=len(files))
Path(str(base) + '_checks.json').write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps({k:checks[k] for k in ('source_files', 'canonical_commands_verified',
    'raw_stream_hashes_verified', 'archive_bytes', 'archive_entries', 'archive_sha256')}))
