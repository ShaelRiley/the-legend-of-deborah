# Recovered exact-source gate

Run the command in verified-checks.json from the repository, with a new output
directory outside it. The complete gate has 313 canonical suites, 884 Lua syntax
files and unchanged pre/post source bytes. This local machine allowed 1800 seconds
per suite: the earlier 600-second B23 campaign attempt timed out. No suite, assertion,
seed or workload was removed. The interrupted isolated gate supplies 120
hash-verified passing canonical receipts under the unchanged complete source
manifest; its remaining 193 suites run fresh. recovery.json and the archived
recovery-driver.py preserve that procedure; cross-source attempts are not reused.

Focused: python3 tools/test_low_end_render_gate.py --workers 1 --suite-timeout 120
--output /absolute/new-directory. Pair: python3 tools/run_lua54.py
tools/test_low_end_render.lua --kind-probe <mesh.lua> <entity.lua> <signature>
<shared.lua>. Use archived parent sources and tested candidate sources. Native
kind reads must be 144000 versus zero, validity calls 144000 versus 14400,
and all 726 signature rows identical. The exact parent fails the --source work gate.

Earlier attempts retain their raw logs, source manifests and failures. Their
production bytes differ from this candidate. They are historical evidence only.
The source gate precedes final documentation and archive packaging; final production
and test bytes are verified against changed_code_sha256 before publication.
Native uploads describe the parent build. Their profiles and rendering observations
do not establish this candidate's FPS or native visuals; the 40-FPS target is open.
