-- Run the final regression with the exact two unchanged parent authorities.
local native=dofile
function dofile(path)
 local name=path:match('([^/]+)$')
 if name=='sv_event_director.lua' or name=='sv_event_skeleton_blockade.lua' then
  return native('/workspace/scratch/24e007044045/staging-repair/base_'..name)
 end
 return native(path)
end
native('tools/test_staging_event_spawn.lua')
