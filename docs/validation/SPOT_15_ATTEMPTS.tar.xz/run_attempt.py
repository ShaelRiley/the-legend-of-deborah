import sys,subprocess,json,hashlib,pathlib,time,tarfile
r=pathlib.Path('/mnt/data/the-legend-of-deborah');name=sys.argv[1];cmd=sys.argv[2:];a=pathlib.Path('/mnt/data/spot15-work/attempts');out=a/(name+'.log')
assert not out.exists(),out
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=r).decode().split('\0')
manifest={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in sorted(set(names)) if n and (r/n).is_file()}
(a/(name+'.source.json')).write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
(a/(name+'.patch')).write_bytes(subprocess.check_output(['git','diff','--binary','HEAD'],cwd=r))
base=json.loads(pathlib.Path('/mnt/data/spot15-work/base-source.json').read_text())
with tarfile.open(a/(name+'.changed-source.tar.xz'),'w:xz') as t:
 for n,h in manifest.items():
  if base.get(n)!=h:t.add(r/n,arcname=n)
with out.open('wb') as f:
 result=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT)
(a/(name+'.receipt.json')).write_text(json.dumps({'command':cmd,'returncode':result.returncode,'log_sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2)+'\n')
print(name,'EXIT',result.returncode);print(out.read_text(errors='replace')[-2200:])
sys.exit(result.returncode)
