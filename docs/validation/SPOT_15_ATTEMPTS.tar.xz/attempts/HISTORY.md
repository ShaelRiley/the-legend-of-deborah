# SPOT-15 attempt history

Preparation01 completed the server edit script (exit 0); manual01 generated 166
chapters / 32 chunks (exit 0). lifecycle01 failed its old idempotency assertion
while the legacy geometry fixture still had BuildReady=false. lifecycle_probe
confirmed false/false/false for BuildReady/Failed/LevelCleared and retained the
same failure. The fixture now asserts build-lock rejection before marking its
separate idempotency phase ready. lifecycle02 passed without weakened production
checks. Early preparation/manual/lifecycle attempts retain their raw output and
implementation script, not full per-attempt source copies or contemporaneous
source manifests. Do not claim otherwise.

server01 exposed an actual integration defect: the revived Hero's deferred spawn
checked deployed-active rather than slot-active eligibility. SPOT-15 repaired the
existing Multiplayer revival callback to use RunManager's slot authority.
server02 then reached actual Soldier native loadout and failed because the reused
weapon double lacked GetPrimaryAmmoType. Only the native adapter was extended;
server03 passed 196 assertions. ui01 passed 229 assertions. gate01 passed all 90
selected suites on unchanged source, including those focused checks and 751 Lua
syntax checks. All 90 raw logs/hashes are retained. None is native acceptance.

The streaming-container launch failed before execution. No command or suite ran
for that request; the subsequent local-process launch is the recorded gate01.

Every server01-and-later source manifest is retained. Tracked changes are also
stored as original binary Git diffs. New-file source archives for server01/02
were captured before the next test edit; subsequent changed-source archives
cover all changed/new files relative to base-source.json. Original .tar.xz
source-copy containers are stored as decoded .tar payloads, with an index of
original and decoded hashes: recompression using Python lzma.compress (default
XZ/preset 6) reproduces their exact original bytes, verified during packaging.
The final frozen and independent gates are external receipts, not assumed by
this archive. Historical SPOT-01–14 results retain their original meaning.
