from pathlib import Path
import json,hashlib,subprocess
r=Path('/mnt/data/the-legend-of-deborah'); d=r/'gamemodes/legend_of_deborah/gamemode/lod'
paths=subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().strip('\0').split('\0')
Path('/mnt/data/spot15-work/base-source.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths},sort_keys=True,indent=2)+'\n')
p=d/'sv_run_manager.lua';s=p.read_text()
def replace(old,new,count=1):
 global s
 assert s.count(old)==count, (old[:120],s.count(old),count)
 s=s.replace(old,new)
replace('if ps.queue == "soldier" or ps.soldierRespawnWait == true then','if ps.queue == "soldier" or ps.queue == "spectator" or ps.soldierRespawnWait == true then')
replace('function RunManager:_SyncPlayerVars(ply)', '''-- This token identifies an existing lifecycle, never authorizes a client role.
function RunManager:TeamMenuContext(ply)
    local ps = self:GetPlayerState(ply)
    if not ps then return "" end
    local role = self:IsSoldierControl(ply) and "soldier"
        or ps.soldierRespawnWait and "soldier_wait"
        or ps.queue == "spectator" and "spectator"
        or ps.eliminated and "eliminated" or "hero"
    return table.concat({tostring(self.State.CampaignEpoch or 0), tostring(ps.ordinal or 0),
        tostring(ply.LODRunSpawnSerial or 0), role}, ":")
end

function RunManager:CanChangeTeam(ply)
    local state = self.State
    if not IsValid(ply) or not state or not state.BuildReady or state.Failed or state.LevelCleared then
        return false, "Team changes are unavailable during this transition."
    end
    if LOD.DeathTetris and LOD.DeathTetris.IsActiveFor and LOD.DeathTetris:IsActiveFor(ply) then
        return false, "Finish the current Tetris session first."
    end
    if LOD.Equipment and LOD.Equipment.InventoryLocked and LOD.Equipment:InventoryLocked(ply) then
        return false, "Finish the current minigame first."
    end
    if LOD.CampaignTimeout and LOD.CampaignTimeout:Expire() then return false, "Time over." end
    return true
end

function RunManager:_SyncPlayerVars(ply)''')
replace('    ply:SetNW2Bool("LOD_SoldierWaiting", ps and ps.soldierRespawnWait == true or false)', '''    ply:SetNW2Bool("LOD_SoldierWaiting", ps and ps.soldierRespawnWait == true or false)
    ply:SetNW2String("LOD_HeroQueue", ps and ps.queue or "hero")
    ply:SetNW2String("LOD_TeamMenuContext", self:TeamMenuContext(ply))''')
replace('''    if self.State.ActiveIdentity[id] then return true end

    local ps = self.State.PlayerState[id]''','''    local ps = self.State.PlayerState[id]
    if ps and ps.queue == "spectator" then
        self:PutInRestrictedSpectator(ply)
        return false
    end
    if self.State.ActiveIdentity[id] then return true end''')
replace('''function RunManager:JoinSoldierRole(ply)
    if not IsValid(ply) or not self.State.BuildReady or self.State.Failed then return false, "invalid state" end''','''function RunManager:JoinSoldierRole(ply)
    local allowed, reason = self:CanChangeTeam(ply)
    if not allowed then return false, reason end''')
replace('''    if ps.respawnAt and ps.respawnAt > CurTime() then
        return false, "soldier respawn delay active"
    end''','''    if math.max(ps.respawnAt or 0, ps.soldierReadyAt or 0) > CurTime() then
        return false, "soldier respawn delay active"
    end''')
a=s.index('function RunManager:ReturnToHeroQueue(ply)');b=s.index('\nfunction RunManager:BeginNewHero(ply)',a)
s=s[:a]+'''-- Both exits share the existing queue/retirement authority. Explicit spectators
-- preserve their dormant Hero but do not enter revival or automatic admission.
function RunManager:SetHeroQueueMode(ply, queue)
    if queue ~= "hero" and queue ~= "spectator" then return false, "invalid queue" end
    local allowed, reason = self:CanChangeTeam(ply)
    if not allowed then return false, reason end
    local id = self:IdentityOf(ply)
    local ps = id and self.State.PlayerState[id]
    if not ps then return false, "no player state" end
    local isSol = self:IsSoldierControl(ply)
    local inWait = ps.soldierRespawnWait == true
    local spectator = ps.queue == "spectator"
    if not isSol and not inWait and not spectator and not ps.eliminated and (ps.lives or 0) > 0 then
        return false, "active hero cannot return to hero queue"
    end
    if queue == "spectator" and not isSol and not inWait and not spectator then
        return false, "Only Soldiers may choose spectate only."
    end
    if isSol or inWait or spectator ~= (queue == "spectator") then
        -- Cancel already scheduled native Spawn callbacks before retiring this life.
        ply.LODRunSpawnSerial = (ply.LODRunSpawnSerial or 0) + 1
        ply.LODRunInventoryReady = false
        if LOD.Equipment and LOD.Equipment.ClearTransient then LOD.Equipment:ClearTransient(ply) end
        if LOD.RPGStatusElements then LOD.RPGStatusElements:ResetActorLife(ply) end
        self:RetireSoldier(ply)
        if ply.StripWeapons then ply:StripWeapons() end
        if ply.RemoveAllAmmo then ply:RemoveAllAmmo() end
        ply:SetNW2Bool("LOD_Deployed", false)
        ply:SetNW2Bool("LOD_Staged", false)
    end
    -- The death deadline survives cancellation of automatic Soldier respawning.
    if inWait then ps.soldierReadyAt = math.max(ps.soldierReadyAt or 0, ps.respawnAt or 0) end
    ps.queue = queue
    ps.soldierRespawnWait = nil
    ps.respawnAt = nil
    self.State.ActiveIdentity[id] = nil
    if queue == "hero" and not ps.eliminated and (ps.lives or 0) > 0 then
        if self:TryActivatePlayer(ply) then
            ply:UnSpectate()
            ply:Spawn() -- fresh Hero body; never re-use a living former Soldier
            return true
        end
    end
    self:PutInRestrictedSpectator(ply)
    self:_SyncPlayerVars(ply)
    return true
end

function RunManager:ReturnToHeroQueue(ply)
    return self:SetHeroQueueMode(ply, "hero")
end

function RunManager:SpectateOnly(ply)
    return self:SetHeroQueueMode(ply, "spectator")
end
''' + s[b:]
replace('''function RunManager:BeginNewHero(ply)
    local state, old''','''function RunManager:BeginNewHero(ply)
    local allowed, reason = self:CanChangeTeam(ply)
    if not allowed then return false, reason end
    local state, old''')
replace('''            ps.respawnAt = CurTime() + CC.Lives.RespawnDelay
            ps.soldierRespawnWait = true''','''            ps.respawnAt = CurTime() + CC.Lives.RespawnDelay
            ps.soldierReadyAt = ps.respawnAt
            ps.soldierRespawnWait = true''')
replace('''        ps.queue = "hero"
        ps.soldierRespawnWait = nil
        ps.respawnAt = nil''','''        if ps.queue ~= "spectator" then ps.queue = "hero" end
        ps.soldierRespawnWait = nil
        ps.soldierReadyAt = nil
        ps.respawnAt = nil''')
a=s.index('concommand.Add("lod_join_human_soldier"');b=s.index('\nhook.Add("ShutDown"',a)
s=s[:a]+'''local function teamCommand(method)
    return function(ply, _, args)
        if not IsValid(ply) then return end
        -- Legacy typed commands remain supported. Menu clicks additionally bind
        -- the exact campaign, Hero, body and role visible when the menu opened.
        local context = args and args[1]
        if context and context ~= RunManager:TeamMenuContext(ply) then
            if ply.ChatPrint then ply:ChatPrint("Team changed; reopen F3 and choose again.") end
            return
        end
        local ok, err = RunManager[method](RunManager, ply)
        if not ok and ply.ChatPrint then ply:ChatPrint(tostring(err)) end
    end
end
concommand.Add("lod_join_human_soldier", teamCommand("JoinSoldierRole"))
concommand.Add("lod_return_to_hero_queue", teamCommand("ReturnToHeroQueue"))
concommand.Add("lod_spectate_only", teamCommand("SpectateOnly"))
concommand.Add("lod_begin_new_hero", teamCommand("BeginNewHero"))
''' + s[b:]
p.write_text(s)
