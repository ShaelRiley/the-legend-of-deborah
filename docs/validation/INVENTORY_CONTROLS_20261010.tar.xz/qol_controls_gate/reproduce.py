import subprocess,json,hashlib,pathlib,sys,time,importlib.util
root=pathlib.Path.cwd();out=root.parent/'qol_controls_gate';out.mkdir(exist_ok=True)
chosen=['test_equipment_inventory_ui.lua','test_magic_mouse_bindings.lua','test_spot12_spellbook.lua','test_spot13_unread.lua','test_checkpoint_c_headless.lua','test_checkpoint_d_magic_grant_feats.lua','test_magic_wall.lua','test_equipment_delivery.lua','test_snapshot_delivery.lua','test_manual_document.py','test_instruction_manual.lua','test_manual_transport.lua','test_performance_capture.lua','test_population_transport.lua']
spec=importlib.util.spec_from_file_location('matrix',root/'tools/test_checkpoint_g_integration.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
selected=[(n,c) for n,c in m.SUITES if '--syntax' not in c and any('tools/'+s in c for s in chosen)]
assert len(selected)==14,len(selected)
before=m.source_snapshot();(out/'source_manifest.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
rows=[]
for i,(name,cmd) in enumerate(selected,1):
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=60)
 stem=f'{i:02}'
 (out/(stem+'.stdout.txt')).write_bytes(r.stdout);(out/(stem+'.stderr.txt')).write_bytes(r.stderr)
 row=dict(name=name,command=cmd,returncode=r.returncode,seconds=round(time.monotonic()-start,3),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),log_prefix=stem)
 rows.append(row);print(('PASS' if r.returncode==0 else 'FAIL')+' '+name,flush=True)
 if r.returncode:print((r.stdout+r.stderr).decode(errors='replace')[-2400:],flush=True)
changed=subprocess.check_output(['git','diff','--name-only']).decode().splitlines();lua=[p for p in changed if p.endswith('.lua')]
for name,cmd in [('Changed Lua parse',['python3','tools/run_lua54.py','--syntax',*lua]),('Installer shell syntax',['bash','-n','tools/install_dev.sh']),('Patch whitespace',['git','diff','--check'])]:
 r=subprocess.run(cmd,capture_output=True,timeout=60);stem=f'{len(rows)+1:02}';(out/(stem+'.stdout.txt')).write_bytes(r.stdout);(out/(stem+'.stderr.txt')).write_bytes(r.stderr)
 rows.append(dict(name=name,command=cmd,returncode=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),log_prefix=stem));print(('PASS' if r.returncode==0 else 'FAIL')+' '+name,flush=True)
after=m.source_snapshot();report=dict(parent=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),source_before=m.snapshot_digest(before),source_after=m.snapshot_digest(after),changed_during_gate=[k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)],source_files=len(before),changed_lua=len(lua),total=len(rows),passed=sum(r['returncode']==0 for r in rows),results=rows,native_accepted=False)
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='results'}));sys.exit(0 if report['passed']==report['total'] and before==after else 1)
