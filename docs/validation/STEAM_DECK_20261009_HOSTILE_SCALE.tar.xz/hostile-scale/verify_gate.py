import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent / 'the-legend-of-deborah'
sys.path.insert(0, str(repo))
import tools.test_checkpoint_g_integration as gate

manifest = json.loads((root / 'matrix-verified/source_manifest.json').read_text())
digest = gate.snapshot_digest(manifest)
assert gate.source_snapshot() == manifest, 'source changed after the frozen gate'
first = json.loads((root / 'matrix-verified/interruption.json').read_text())
assert first['source_after_observed'] == digest and not first['changed_after_observed']
continuation = json.loads((root / 'matrix-continuation/receipt.json').read_text())
assert continuation['total'] == continuation['passed'] == 251
assert continuation['source_before'] == continuation['source_after'] == digest
assert not continuation['changed_during_gate']

canonical = dict(gate.SUITES)
assert len(canonical) == len(gate.SUITES) == 317
coverage = {}
streams = 0
for directory in ('matrix-verified', 'matrix-continuation'):
    output = root / directory
    rows = [json.loads(p.read_text()) for p in sorted(output.glob('[0-9][0-9][0-9]-*.json'))]
    assert len(rows) == (66 if directory == 'matrix-verified' else 251)
    for row in rows:
        name = row['name']
        assert row['returncode'] == 0 and row['command'] == canonical[name]
        assert name not in coverage, 'duplicate canonical coverage'
        for stream in ('stdout', 'stderr'):
            p = output / (row['log_prefix'] + '.' + stream + '.txt')
            assert hashlib.sha256(p.read_bytes()).hexdigest() == row[stream + '_sha256']
            streams += 1
        coverage[name] = {'evidence_directory': directory, **row}
assert set(coverage) == set(canonical)
syntax = json.loads((root / 'lua-syntax.json').read_text())
assert syntax['returncode'] == 0 and syntax['files'] == len(gate.LUA_FILES) == 887
assert not (root / 'lua-syntax.stderr.txt').read_bytes()
assert len((root / 'lua-syntax.stdout.txt').read_text().splitlines()) == 887
parent = (root / 'scale_parent.trace').read_bytes()
candidate = (root / 'scale_candidate.trace').read_bytes()
focused = json.loads((root / 'focused-proof.json').read_text())
assert parent == candidate and hashlib.sha256(parent).hexdigest() == focused['trace_sha256']
assert focused['results']['parent_reject']['returncode'] == 1
proof = {'total': 317, 'passed': 317, 'lua_files': 887, 'source_files': len(manifest),
         'source_sha256': digest, 'source_unchanged': True, 'verified_streams': streams,
         'coverage_runs': {'matrix-verified': 66, 'matrix-continuation': 251},
         'trace_sha256': focused['trace_sha256'], 'native_gmod_accepted': False,
         'native_fps_measured': False, 'results': coverage}
(root / 'verified-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: v for k, v in proof.items() if k != 'results'}, indent=2))
