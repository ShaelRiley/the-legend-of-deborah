# Hostile visual scale key evidence

Parent main: b8b9cfd6c4efb711fa2d8fe18f15e1fc75681505.
The containing commit supplies the candidate source and the new test.

The 317 passing canonical checks span matrix-verified (66 completed receipts)
and matrix-continuation (251 remaining checks). Both use the identical frozen
source manifest. The first corrected session ended before an aggregate receipt;
its interruption.json records the independently observed unchanged source.
All 634 final raw streams, exact commands and results are independently checked
in verified-proof.json. The initial matrix directory contains retained failed
partial evidence and is not the final pass.

After extracting, verify the receipts against a checkout of the containing commit:

    python3 /path/to/hostile-scale/verify_release.py /path/to/the-legend-of-deborah

verify_gate.py is the original pre-packaging verifier. It requires the original
frozen source, including the pre-packaging development plan. verify_release.py
permits only the three documented release documentation/evidence paths to change.
source/ preserves all 11 changed production/test files; source.patch contains the
tracked diff, while the new test is preserved in source/tools/.

Paired traces use real production Lua with only Source API boundaries doubled.
focused-proof.json records the exact probe and rejecting negative-control commands.
Lua syntax output and its complete command are preserved separately. Native
GMod appearance, Steam Deck FPS and sustained 40 FPS remain unmeasured here.
