"""Verify preserved gate receipts against the published checkout after packaging."""
import hashlib
import json
import sys
from pathlib import Path

evidence = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo))
import tools.test_checkpoint_g_integration as gate

manifest = json.loads((evidence / 'matrix-verified/source_manifest.json').read_text())
current = gate.source_snapshot()
release_docs = {
    'docs/DEVELOPMENT_PLAN.md',
    'docs/validation/STEAM_DECK_20261009_HOSTILE_SCALE.md',
    'docs/validation/STEAM_DECK_20261009_HOSTILE_SCALE.tar.xz',
}
changed = {p for p in current.keys() | manifest.keys() if current.get(p) != manifest.get(p)}
assert changed <= release_docs, sorted(changed - release_docs)
proof = json.loads((evidence / 'verified-proof.json').read_text())
assert proof['source_sha256'] == gate.snapshot_digest(manifest)
assert proof['passed'] == proof['total'] == len(gate.SUITES) == 317
assert proof['lua_files'] == len(gate.LUA_FILES) == 887
commands = dict(gate.SUITES)
assert set(proof['results']) == set(commands)
streams = 0
for name, row in proof['results'].items():
    assert row['returncode'] == 0 and row['command'] == commands[name]
    directory = evidence / row['evidence_directory']
    original = json.loads((directory / (row['log_prefix'] + '.json')).read_text())
    assert original == {k: v for k, v in row.items() if k != 'evidence_directory'}
    for stream in ('stdout', 'stderr'):
        data = (directory / (row['log_prefix'] + '.' + stream + '.txt')).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row[stream + '_sha256']
        streams += 1
assert streams == proof['verified_streams'] == 634
parent = (evidence / 'scale_parent.trace').read_bytes()
candidate = (evidence / 'scale_candidate.trace').read_bytes()
assert parent == candidate
assert hashlib.sha256(parent).hexdigest() == proof['trace_sha256']
focused = json.loads((evidence / 'focused-proof.json').read_text())
assert focused['results']['parent_reject']['returncode'] == 1
for path in (evidence / 'source').rglob('*'):
    if path.is_file():
        relative = path.relative_to(evidence / 'source').as_posix()
        assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest[relative]
        assert path.read_bytes() == (repo / relative).read_bytes()
syntax = json.loads((evidence / 'lua-syntax.json').read_text())
assert syntax['returncode'] == 0 and syntax['files'] == 887
assert len((evidence / 'lua-syntax.stdout.txt').read_text().splitlines()) == 887
assert not (evidence / 'lua-syntax.stderr.txt').read_bytes()
print(json.dumps({'canonical_checks': 317, 'lua_files': 887,
                  'verified_streams': streams, 'source_files': len(manifest),
                  'only_release_documentation_changed': sorted(changed),
                  'native_fps_measured': False}, indent=2))
