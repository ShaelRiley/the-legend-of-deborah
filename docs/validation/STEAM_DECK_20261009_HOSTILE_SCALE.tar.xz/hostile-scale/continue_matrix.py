import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "the-legend-of-deborah"))
import tools.test_checkpoint_g_integration as gate
selected = set(json.loads((Path(__file__).parent / "remaining-suites.json").read_text()))
gate.SUITES = [(name, command) for name, command in gate.SUITES if name in selected]
assert len(gate.SUITES) == len(selected)
raise SystemExit(gate.main())
