"""Resume verified canonical suites against the identical frozen source snapshot."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

root=Path('/workspace/scratch/6c9c499b7513')
repo=root/'the-legend-of-deborah'
previous=root/'qol-complete-matrix-final'
output=root/'qol-complete-matrix-resumed'
spec=importlib.util.spec_from_file_location('canonical_matrix',repo/'tools/test_checkpoint_g_integration.py')
matrix=importlib.util.module_from_spec(spec);spec.loader.exec_module(matrix)
before=json.loads((previous/'source_manifest.json').read_text())
assert matrix.source_snapshot()==before, 'Cannot reuse results from changed source'
assert not output.exists(), 'Preserve earlier evidence'
output.mkdir()
(output/'source_manifest.json').write_text(json.dumps(before,indent=2)+'\n')
rows=[]
for path in sorted(previous.glob('*.json')):
    if path.name in ('source_manifest.json','receipt.json'):
        continue
    row=json.loads(path.read_text())
    name,command=matrix.SUITES[row['index']-1]
    assert row['name']==name and row['command']==command and row['returncode']==0
    for stream in ('stdout','stderr'):
        source=previous/(row['log_prefix']+'.'+stream+'.txt')
        assert hashlib.sha256(source.read_bytes()).hexdigest()==row[stream+'_sha256']
        shutil.copyfile(source,output/source.name)
    shutil.copyfile(path,output/path.name)
    rows.append(row)
completed={row['index'] for row in rows}
assert len(completed)==len(rows)==95
resume={'previous_folder':previous.name,'verified_completed_suites':len(rows),
    'previous_finished':False,'previous_exit_code':None,
    'reason':'Unified exec session became unavailable before a final receipt; only completed, byte-verified canonical results reused. Missing suites rerun against the identical source snapshot.',
    'source_before_resume':matrix.snapshot_digest(before)}
(output/'resume.json').write_text(json.dumps(resume,indent=2)+'\n')
print(f'RESUME_FROZEN_MATRIX {len(rows)} verified prior suites; {len(matrix.SUITES)-len(rows)} remaining',flush=True)

def run(entry):
    index,(name,command)=entry
    start=time.monotonic()
    try:
        process=subprocess.run(command,cwd=repo,capture_output=True,timeout=600)
        code,stdout,stderr=process.returncode,process.stdout,process.stderr
    except subprocess.TimeoutExpired as error:
        code,stdout=124,error.stdout or b''
        stderr=(error.stderr or b'')+b'\nTIMEOUT: 600s\n'
    stem=f'{index:03d}-'+re.sub(r'[^a-z0-9]+','-',name.lower()).strip('-')
    row={'index':index,'name':name,'command':command,'returncode':code,
         'seconds':round(time.monotonic()-start,3),'log_prefix':stem,
         'stdout_sha256':hashlib.sha256(stdout).hexdigest(),
         'stderr_sha256':hashlib.sha256(stderr).hexdigest()}
    (output/(stem+'.stdout.txt')).write_bytes(stdout)
    (output/(stem+'.stderr.txt')).write_bytes(stderr)
    (output/(stem+'.json')).write_text(json.dumps(row,indent=2)+'\n')
    return row,stdout,stderr

entries=[entry for entry in enumerate(matrix.SUITES,1) if entry[0] not in completed]
with ThreadPoolExecutor(max_workers=4) as pool:
    for future in as_completed([pool.submit(run,entry) for entry in entries]):
        row,stdout,stderr=future.result();rows.append(row)
        print(f"[{'PASS' if row['returncode']==0 else 'FAIL'}] {row['index']}/{len(matrix.SUITES)} {row['name']} ({row['seconds']}s)",flush=True)
        if row['returncode']:
            print((stdout+stderr).decode(errors='replace')[-6000:],flush=True)
after=matrix.source_snapshot()
changed=sorted(name for name in before.keys()|after.keys() if before.get(name)!=after.get(name))
receipt={'total':len(rows),'passed':sum(row['returncode']==0 for row in rows),
    'source_before':matrix.snapshot_digest(before),'source_after':matrix.snapshot_digest(after),
    'changed_during_gate':changed,'lua_files':len(matrix.LUA_FILES),'native_gmod_accepted':False,
    'results':sorted(rows,key=lambda row:row['index']),'resume':resume}
(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(f"SYSTEMS_MATRIX {receipt['passed']}/{receipt['total']}; source_changed={len(changed)}; prior_verified={len(completed)}",flush=True)
sys.exit(0 if receipt['passed']==receipt['total'] and not changed else 1)
