"""Independently verify the supplied native capture against published source."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/6c9c499b7513')
repo = root / 'the-legend-of-deborah'
parent = '9f88e548548e6283666f779f0109c564b8c31ca0'
performance = root / 'upload/performance_client_latest(10).txt'
console = root / 'upload/console_latest(20261007-032555).txt'
text = performance.read_text()
d = json.loads(text[text.index('{'):])
assert d['version'] == 'steam-deck-vr-idle-20261007'
assert d['reason'] == 'complete' and not d['preparation_timed_out']
assert d['cpu_profile']['server_status'] == 'received'
assert d['source'] == {'verified': True, 'checked': 10, 'mismatches': 0, 'missing': 0}
population = d['population']['source']
assert population['checked'] == 44 and population['verified']
assert population['missing'] == 0 and population['mismatches'] == 0
assert len(population['modules']) == 44
verified = {}
for row in population['modules']:
    name = row['path']
    data = subprocess.check_output(['git', 'show', parent + ':' + name], cwd=repo)
    digest = hashlib.sha256(data).hexdigest()
    assert row['installed'] == row['mounted'] == digest, name
    verified[name] = digest

vr = []
def walk(value, path='capture'):
    if isinstance(value, dict):
        state = value.get('vr')
        if isinstance(state, dict) and 'idle' in state:
            vr.append((path + '.vr', state))
        for key, child in value.items():
            walk(child, path + '.' + key)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            walk(child, path + '[' + str(i) + ']')
walk(d)
assert len(d['windows']) == 36 and len(vr) >= 40
for path, state in vr:
    assert state['version'] == 'deborah-vr-idle-20261007', path
    assert state['idle'] and not state['active'], path
    for key in ('players', 'runtime_hooks', 'recurring_timers', 'pending_once', 'method_overrides', 'native_resources'):
        assert state[key] == 0, (path, key)
    assert not state['local_tracking'] and not state.get('adapter_think', False), path
    assert not any(state['resource_counts'].values()) if isinstance(state['resource_counts'], dict) else not state['resource_counts']
    source = state['source']
    assert source == {'bridge_checked': 2, 'verified': True, 'checked': 139, 'mismatches': 0, 'missing': 0}, path

for realm in ('client', 'server'):
    profile = d['cpu_profile'][realm]
    for state in ('state_start', 'state_end'):
        resources = profile[state]['resources']
        assert resources['install'].strip() == parent + ' clean'
        assert resources['lua_errors'] == (0 if realm == 'client' else 1)
console_text = console.read_text()
warning = "AddCSLuaFile: Couldn't find 'weapons/gmod_tool/shared.lua'"
assert console_text.count(warning) == 1
assert d['active']['fps'] == d['active']['frames'] / d['active']['seconds']
proof = {
    'parent_sha': parent,
    'raw_files': {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                  for p in (performance, console)},
    'version': d['version'], 'active': d['active'], 'windows': len(d['windows']),
    'reason': d['reason'], 'preparation_timed_out': d['preparation_timed_out'],
    'render_source_checks': d['source'],
    'population_source_checks': {k: population[k] for k in ('checked', 'verified', 'missing', 'mismatches')},
    'independently_verified_published_source_sha256': verified,
    'vr_resource_snapshots_verified': len(vr), 'native_idle_gate_passed': True,
    'native_headset_activation_accepted': False,
    'native_fps_gate_passed': False,
    'client_lua_errors': 0, 'server_lua_errors': 1,
    'startup_warning': warning,
    'startup_warning_fix_requires_new_native_boot': True,
    'render_phase_cpu_ms_per_second': d['cpu_profile']['client']['rows'][0]['ms_per_second'],
    'top_client_rows': d['cpu_profile']['client']['rows'][1:4],
    'top_server_rows': d['cpu_profile']['server']['rows'][:3],
    'profiling_limits': d['cpu_profile']['client']['timing'],
    'population': {k: d['population'][k] for k in ('ready', 'frozen', 'level', 'developerDense', 'developerMode', 'plannedBodies', 'aliveBodies')},
    'wall_batches': d['wall_batches'],
    'comparison_limit': 'Different generated mazes and work durations; this is not a controlled before/after FPS comparison.'
}
(root / 'qol-native-verification.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: proof[k] for k in ('parent_sha', 'active', 'windows', 'vr_resource_snapshots_verified', 'native_idle_gate_passed', 'native_fps_gate_passed', 'client_lua_errors', 'server_lua_errors')}, indent=2))
