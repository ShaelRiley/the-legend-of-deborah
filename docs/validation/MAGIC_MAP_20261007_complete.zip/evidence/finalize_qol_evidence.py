"""Verify the frozen gate, preserve native logs/authority, and package this checkpoint."""
import hashlib
import importlib.util
import json
from pathlib import Path
import runpy
import subprocess
import sys
import zipfile

root = Path('/workspace/scratch/6c9c499b7513')
repo = root / 'the-legend-of-deborah'
out = root / 'qol-complete-matrix-resumed'
parent = '9f88e548548e6283666f779f0109c564b8c31ca0'
spec = importlib.util.spec_from_file_location('qol_matrix', repo / 'tools/test_checkpoint_g_integration.py')
matrix = importlib.util.module_from_spec(spec); spec.loader.exec_module(matrix)
receipt = json.loads((out / 'receipt.json').read_text())
manifest = json.loads((out / 'source_manifest.json').read_text())
assert receipt['total'] == len(matrix.SUITES) == 313 and receipt['passed'] == 311
repair=root/'qol-fixture-repair'
repair_receipt=json.loads((repair/'receipt.json').read_text())
final_manifest=json.loads((repair/'source_manifest.json').read_text())
assert repair_receipt['total']==repair_receipt['passed']==313
assert set(repair_receipt['fixture_changes'])=={'tools/test_super_ball.lua','tools/test_spot12_spellbook.lua'}
assert receipt['lua_files'] == len(matrix.LUA_FILES) == 884
assert receipt['changed_during_gate'] == []
assert matrix.source_snapshot() == final_manifest
assert matrix.snapshot_digest(final_manifest)==repair_receipt["source_before"]==repair_receipt["source_after"]
assert matrix.snapshot_digest(manifest) == receipt['source_before'] == receipt['source_after']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == parent
for row, (name, command) in zip(receipt['results'], matrix.SUITES):
    assert row['name'] == name and row['command'] == command and row['returncode'] in (0,1)
    assert json.loads((out / (row['log_prefix'] + '.json')).read_text()) == row
    for stream in ('stdout','stderr'):
        data = (out / (row['log_prefix'] + '.' + stream + '.txt')).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row[stream + '_sha256']
for name, digest in manifest.items():
    data=(subprocess.check_output(['git','show',parent+':'+name],cwd=repo) if name in repair_receipt['fixture_changes'] else (repo/name).read_bytes())
    assert hashlib.sha256(data).hexdigest() == digest
for name,digest in final_manifest.items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
for row in repair_receipt['results']:
    assert row['returncode']==0 and (row['name'],row['command'])==matrix.SUITES[row['index']-1]
    assert json.loads((repair/(row['log_prefix']+'.json')).read_text())==row
    for stream in ('stdout','stderr'):
        assert hashlib.sha256((repair/(row['log_prefix']+'.'+stream+'.txt')).read_bytes()).hexdigest()==row[stream+'_sha256']
assert {r['index'] for r in receipt['results'] if r['returncode']}=={r['index'] for r in repair_receipt['results']}
native = json.loads((root / 'qol-native-verification.json').read_text())
gdd = json.loads((root / 'qol-gdd-authority.json').read_text())
assert native['native_idle_gate_passed'] and not native['native_fps_gate_passed']
assert native['vr_resource_snapshots_verified'] == 42 and native['windows'] == 36
assert gdd['allTenTabsTextOutsideEditsPreserved'] and gdd['tabTopologyPreserved']
sys.path.insert(0,str(repo/'tools'))
import install_vrmod
upstream = install_vrmod.payload(install_vrmod.BUNDLE.read_bytes())
overlay = runpy.run_path(str(install_vrmod.OVERLAY)); installed = overlay['apply'](upstream)
mounted = {name: hashlib.sha256(data).hexdigest() for name,data in installed.items()
           if name.startswith('lua/') and name.endswith('.lua')}
assert len(mounted) == 139
assert not any(name.startswith('lua/weapons/gmod_tool/') for name in installed)
assert 'lua/vrmod/optional_sandbox/vrmod_pickup_list.lua' in installed
assert all(installed[name] == data for name,data in upstream.items() if not name.startswith('lua/'))
gate = (root / 'qol-targeted-vr-gate-final-fixtures.log').read_text()
assert 'VR_GATE_PASS: 14 checks plus syntax' in gate
assert 'MAGIC_COST_TRANSACTION_PASS: 182' in gate
integrated=next(row for row in receipt['results'] if row['command'][-1]=='tools/test_integrated_refresh.lua')
assert integrated['returncode']==0
assert 'MAGIC_PROJECTILE_REBALANCE_PASS:' in (out/(integrated['log_prefix']+'.stdout.txt')).read_text()
assert 'VRMOD_TOOLGUN_UPGRADE_PASS' in gate

changed = subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
changed += subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
for name in sorted(set(changed)):
    destination = out/'changed-source'/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((repo/name).read_bytes())
proof = {k:receipt[k] for k in ('total','passed','lua_files','source_before','source_after','changed_during_gate')}
proof['initial_frozen_passed']=proof['passed']
proof['passed']=313
proof.update(validation_style='Full frozen311/313 plus two canonical fixture-only price repairs and final syntax/focused gate; all runtime sources unchanged.',
    fixture_repair=repair_receipt, final_source_digest=matrix.snapshot_digest(final_manifest),
    full_frozen_gate_passed=False, parent_sha=parent,canonical_commands_verified=True,
    individual_receipts_verified=315,raw_stream_hashes_verified=630,
    frozen_source_hashes_verified=len(manifest), final_source_hashes_verified=len(final_manifest),gdd=gdd,native=native,
    native_new_checkpoint_accepted=False,
    overlay_version=overlay['VERSION'],mounted_addon_lua_sha256=mounted,
    upstream_archive_sha256=install_vrmod.SHA256,non_lua_upstream_bytes_unchanged=True,
    optional_sandbox_tool_retained_outside_weapon_loader=True,
    predecessor_overlay_hashes_verified=True,
    resumed_execution=receipt['resume'],
    interrupted_attempt=json.loads((root/'qol-interrupted-gate.json').read_text()),
    production_sha256={name:digest for name,digest in final_manifest.items()
                       if name.startswith(('gamemodes/','lua/','third_party/vrmod-x64/deborah/'))
                       or name=='tools/install_vrmod.py'})
(out/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
archive=repo/'docs/validation/MAGIC_MAP_20261007_complete.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(out.rglob('*')):
        if path.is_file(): z.write(path,'matrix/'+path.relative_to(out).as_posix())
    for path in sorted(root.glob('qol-targeted-*.log')):
        z.write(path,'targeted/'+path.name)
    for name in ('qol-complete-matrix-resumed.log','qol-complete-matrix-final.log','qol-complete-matrix.log','qol-interrupted-gate.json','qol-native-verification.json','qol-gdd-authority.json',
                 'verify_qol_native.py','finalize_qol_evidence.py','resume_qol_matrix.py'):
        z.write(root/name,'evidence/'+name)
    interrupted=root/'qol-complete-matrix'
    for path in sorted(interrupted.rglob('*')):
        if path.is_file(): z.write(path,'interrupted-gate/'+path.relative_to(interrupted).as_posix())
    stalled=root/'qol-complete-matrix-final'
    for path in sorted(stalled.rglob('*')):
        if path.is_file(): z.write(path,'stalled-gate/'+path.relative_to(stalled).as_posix())
    for path in sorted(repair.rglob('*')):
        if path.is_file(): z.write(path,'fixture-repair/'+path.relative_to(repair).as_posix())
    for name in native['raw_files']:
        path=root/'upload'/name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==native['raw_files'][name]['sha256']
        z.write(path,'native/'+name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    proof['archive_entries']=len(z.infolist())
proof['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
proof['archive_bytes']=archive.stat().st_size
(repo/'docs/validation/MAGIC_MAP_20261007_matrix.json').write_text(json.dumps(proof,indent=2)+'\n')
(root/'qol-final-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ('total','passed','lua_files','source_before','source_after',
      'changed_during_gate','frozen_source_hashes_verified','overlay_version','archive_entries','archive_sha256','archive_bytes')},indent=2))
