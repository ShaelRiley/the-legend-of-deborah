import sys
from pathlib import Path
sys.path.insert(0,str(Path('/workspace/scratch/6473023bfe43/the-legend-of-deborah/tools')))
import test_spot10_gate as gate
gate.LABEL='ALIGNED_HUD_GATE'
gate.SCOPE='Shared native HUD alignment, portrait lifecycle, feed/history/event parity, HUD consumers and saved camera/map Options'
gate.LUA=['test_hud_text_work.lua','test_status_portrait.lua','test_feedback_language.lua','validate_spot05_die_logger.lua','test_equipment_block.lua','test_spot15_team_menu.lua','test_player_options.lua','test_minimap_transport.lua','test_status_elements.lua','test_campaign_timeout.lua','test_character_sheet_layout.lua','test_soldier_character_sheet.lua','test_snapshot_delivery.lua','test_native_resource_lifecycle.lua']
gate.SQLITE_LUA=set()
gate.EXTRA_SUITES=[]
raise SystemExit(gate.main())
