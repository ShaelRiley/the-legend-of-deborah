from pathlib import Path
import hashlib,json,os,subprocess,zipfile

repo=Path(os.environ.get('LOD_REPO','/workspace/scratch/6473023bfe43/the-legend-of-deborah'))
p=Path(__file__).resolve().parent
subprocess.run(['python3',str(p/'verify_evidence.py')],cwd=repo,check=True)
v=json.loads((p/'verification.json').read_text())
code=json.loads((p/'validated-code-manifest.json').read_text())
for name,digest in code.items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
checks=(f"The frozen final source passes **20/20 focused checks, 314/314 canonical suites "
        f"and 885 Lua parses**. All {v['frozen_files']:,} source files remain unchanged during "
        "both gates. Every canonical and focused command/receipt and all 628 matrix "
        "stream hashes plus 20 focused log hashes are independently checked. Only "
        "documentation/evidence packaging follows; all three changed code/test hashes "
        "are rechecked before publication. The adjacent checks JSON and ZIP preserve "
        "raw native uploads, live normalized GDD tabs, primary Facepunch draw source, "
        "exact parent/candidate sources, paired drawing traces/work counts, the expected "
        "failing parent work gate, final full/focused commands, receipts, raw streams "
        "and source manifests. No failed or interrupted candidate gate contributes accepted results.\n")
report=(p/'report-draft.md').read_text().replace('VALIDATION_RESULTS',checks)
assert 'VALIDATION_RESULTS' not in report
(repo/'docs/validation/STEAM_DECK_20261008_ALIGNED_TEXT.md').write_text(report)
plan=repo/'docs/DEVELOPMENT_PLAN.md'
old=("HUDText. These are headless work counts, not FPS savings. Freeze source for\n"
     "focused checks, all 314 canonical suites and 885 Lua parses; independently verify\n"
     "commands, receipts, streams and source hashes before non-force main publication.\n"
     "Validation pending.")
new=("HUDText. These are headless work counts, not FPS savings. The frozen source\n"
     f"passes 20/20 focused checks, 314/314 canonical suites and 885 Lua parses. All\n"
     f"{v['frozen_files']:,} source files remain unchanged during both gates; every command/receipt,\n"
     "628 matrix stream hashes and 20 focused log hashes are independently checked.\n"
     "Only documentation/evidence packaging follows; all three changed code/test\n"
     "hashes are rechecked before non-force main publication.")
s=plan.read_text();assert s.count(old)==1
plan.write_text(s.replace(old,new))
archive=repo/'docs/validation/STEAM_DECK_20261008_ALIGNED_TEXT.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(p.rglob('*')):
        if f.is_file() and '__pycache__' not in f.parts: z.write(f,f.relative_to(p))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    members=len(z.namelist())
    for name,digest in code.items(): assert hashlib.sha256(z.read('candidate/'+name)).hexdigest()==digest
summary={'version':'steam-deck-shared-aligned-hud-text-20261008',
 'parent_head':'0a10367a3d0c3a6e12198df978b13376a483f8e7',
 'parent_tree':'d21d786bce4e39d8410bee6afdf2ecdfdb580a6b',
 'gdd_document':'1OSpgiWyiGmUCLFdq--WmCSZe6KQIr7_UTkQZklPV8lY',
 'gdd_revision':'ANLCKQnrYkXEQkWhbY2lFbkh3C5XrRI-q4oBgGMtvVIvs78hQeS96NzZ3OIRtG4TjIZ4DGBr3d0o_ye6s_-butEXqxYjMR0xgyBfcEiqPQ',
 'gdd_tabs':['00','01','06','07'],'verification':v,'code_sha256':code,
 'paired':{'drawing_scenarios':750,'trace_sha256':v['trace_sha256'],'trace_bytes':v['trace_bytes'],
 'aligned_labels':1200,'native_font_selections':[12000,1200],'native_text_measurements':[12000,1200],
 'outline_color_allocations':[1200,0],'coordinate_ceil_operations':[24000,24000],
 'native_glyph_submissions':[12000,12000],'existing_feed_submissions':[42000,42000],
 'parent_work_gate_passed':False,'native_fps_certified':False},
 'native_capture':json.loads((p/'native-summary.json').read_text()),
 'archive':{'filename':archive.name,'bytes':archive.stat().st_size,
 'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members}}
(repo/'docs/validation/STEAM_DECK_20261008_ALIGNED_TEXT_CHECKS.json').write_text(json.dumps(summary,indent=2)+'\n')
subprocess.run(['python3',str(p/'verify_evidence.py'),'--after-packaging'],cwd=repo,check=True)
print(json.dumps(summary['archive'],indent=2))
