from pathlib import Path
import hashlib,json

p=Path(__file__).resolve().parent
raw=(p/'native/performance_client_latest(20261008-075438).txt').read_text()
d=json.loads(raw[raw.index('{'):])
def sha(f): return hashlib.sha256(f.read_bytes()).hexdigest()
summary={
 'capture':'2026-10-08T02:54:53-05:00',
 'parent_head':'0a10367a3d0c3a6e12198df978b13376a483f8e7',
 'raw_files':{f.name:sha(f) for f in sorted((p/'native').iterdir()) if f.is_file()},
 'reason':d['reason'],'preparation_timed_out':d['preparation_timed_out'],
 'configuration_changes':d['configuration_changes'],'configuration':d['start_configuration'],
 'active':d['active'],'all':d['all'],'total_seconds':d['total_seconds'],
 'client_source':d['source'],'population_source':d['population']['source'],
 'profile_seconds':{r:d['cpu_profile'][r]['seconds'] for r in ('client','server')},
 'server_profile_status':d['cpu_profile']['server_status'],
 'profile_timing':d['cpu_profile']['client']['timing'],
 'client_profile_rows':d['cpu_profile']['client']['rows'],
 'server_profile_rows':d['cpu_profile']['server']['rows'],
 'resources':{r:d[r+'_resources'] for r in ('start','end')},
 'population':{k:d['population'][k] for k in ('seed','campaign','layoutSeed','layoutAttempt','mazeAttempt','ceiling','aliveWanderers','aliveBodies','plannedBodies','gates','entry')},
 'console_material_warnings':(p/'native/console_latest(20261008-075438).txt').read_text().count('is multiply defined in material'),
 'target_fps':40,'native_fps_accepted':False,
 'attribution':'Scene/layout differs from preceding capture; 29.651 FPS does not isolate the prior source change. Headless text operation counts do not establish a native FPS gain.'
}
(p/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('active','profile_seconds','server_profile_status','native_fps_accepted')},indent=2))
