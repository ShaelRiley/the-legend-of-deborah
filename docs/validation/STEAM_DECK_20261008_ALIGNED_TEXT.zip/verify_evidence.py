from pathlib import Path
import hashlib,json,os,subprocess,sys

repo=Path(os.environ.get('LOD_REPO','/workspace/scratch/6473023bfe43/the-legend-of-deborah'))
p=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'tools'))
import test_checkpoint_g_integration as g
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((p/'gate/matrix/source_manifest.json').read_text())
receipt=json.loads((p/'gate/matrix/receipt.json').read_text())
assert receipt['passed']==receipt['total']==len(g.SUITES)==314
assert receipt['lua_files']==885 and not receipt['changed_during_gate']
assert receipt['source_before']==receipt['source_after']==g.snapshot_digest(manifest)
current=g.source_snapshot()
changed={n for n in manifest.keys()|current.keys() if manifest.get(n)!=current.get(n)}
if '--after-packaging' in sys.argv:
    allowed={'docs/DEVELOPMENT_PLAN.md','docs/validation/STEAM_DECK_20261008_ALIGNED_TEXT.md',
             'docs/validation/STEAM_DECK_20261008_ALIGNED_TEXT_CHECKS.json','docs/validation/STEAM_DECK_20261008_ALIGNED_TEXT.zip'}
    assert changed<=allowed,changed
else: assert not changed,changed
for row,expected in zip(receipt['results'],g.SUITES):
    assert (row['name'],row['command'])==expected and row['returncode']==0
    stem=row['log_prefix']
    assert json.loads((p/'gate/matrix'/(stem+'.json')).read_text())==row
    for channel in ('stdout','stderr'):
        assert sha(p/'gate/matrix'/(stem+'.'+channel+'.txt'))==row[channel+'_sha256']
focus=json.loads((p/'gate/focus/receipt.json').read_text())
assert focus['passed']==focus['total']==20 and focus['lua_files']==885
assert not focus['changed_during_gate']
assert focus['source_before']==focus['source_after']==receipt['source_before']
lua=['test_hud_text_work.lua','test_status_portrait.lua','test_feedback_language.lua',
     'validate_spot05_die_logger.lua','test_equipment_block.lua','test_spot15_team_menu.lua',
     'test_player_options.lua','test_minimap_transport.lua','test_status_elements.lua',
     'test_campaign_timeout.lua','test_character_sheet_layout.lua','test_soldier_character_sheet.lua',
     'test_snapshot_delivery.lua','test_native_resource_lifecycle.lua']
expected={n:['python3','tools/run_lua54.py','tools/'+n] for n in lua}
expected.update({'manual_catalog_parity':['python3','tools/run_lua54.py','tools/export_manual_catalog.lua','--check'],
 'test_manual_document.py':['python3','tools/test_manual_document.py'],
 'test_dev_population_manifest.py':['python3','tools/test_dev_population_manifest.py'],
 'test_great_crate_assets.py':['python3','tools/test_great_crate_assets.py'],
 'git_diff_check':['git','diff','HEAD','--check'],
 'lua_syntax':['python3','tools/run_lua54.py','--syntax']+g.LUA_FILES})
assert {r['name'] for r in focus['results']}==expected.keys()
for row in focus['results']:
    assert row['command']==expected[row['name']] and row['returncode']==0
    assert json.loads((p/'gate/focus'/(row['name']+'.json')).read_text())==row
    assert sha(p/'gate/focus'/row['log'])==row['log_sha256']
code=json.loads((p/'validated-code-manifest.json').read_text())
assert len(code)==3
for name,digest in code.items():
    assert sha(repo/name)==digest and sha(p/'candidate'/name)==digest
base='0a10367a3d0c3a6e12198df978b13376a483f8e7'
for name in ('cl_ui_theme.lua','cl_combat_roll_feed_semantics.lua'):
    original=subprocess.check_output(['git','show',base+':gamemodes/legend_of_deborah/gamemode/lod/'+name],cwd=repo)
    assert (p/'parent'/name).read_bytes()==original
    assert (p/'candidate'/name).read_bytes()==(repo/'gamemodes/legend_of_deborah/gamemode/lod'/name).read_bytes()
paired=json.loads((p/'paired-receipt.json').read_text())
assert paired['parent']['trace_sha256']==paired['candidate']['trace_sha256']
for label in ('parent','candidate'):
    row=paired[label];assert row['returncode']==0 and row['trace_bytes']==14857836
    expected_command=['python3','tools/run_lua54.py','tools/test_hud_text_work.lua','--probe',
      str(p/label/'cl_ui_theme.lua'),str(p/label/'cl_combat_roll_feed_semantics.lua'),str(p/(label+'.trace.txt'))]
    assert row['command']==expected_command
    assert sha(p/(label+'.trace.txt'))==row['trace_sha256']
    for channel in ('stdout','stderr'): assert sha(p/(label+'.'+channel+'.txt'))==row[channel+'_sha256']
    stdout=(p/(label+'.stdout.txt')).read_text()
    assert 'HUD_TEXT_WORK_PASS traces=750' in stdout
    assert 'native_draws=42000->42000' in stdout
    expected_aligned=('measurements=12000->12000 font_selections=12000->12000 colors=1200->1200' if label=='parent'
        else 'measurements=12000->1200 font_selections=12000->1200 colors=1200->0')
    assert expected_aligned in row['work_result']
    assert 'ceilings=24000->24000 native_draws=12000->12000' in row['work_result']
assert (p/'parent.trace.txt').read_bytes()==(p/'candidate.trace.txt').read_bytes()
assert paired['negative']['returncode']==1
assert paired['negative']['command']==['python3','tools/run_lua54.py','tools/test_hud_text_work.lua','--gate',str(p/'parent/cl_ui_theme.lua'),str(p/'parent/cl_combat_roll_feed_semantics.lua')]
for channel in ('stdout','stderr'): assert sha(p/('parent-negative.'+channel+'.txt'))==paired['negative'][channel+'_sha256']
assert 'aligned HUD repeats native font/metric/allocation work' in (p/'parent-negative.stderr.txt').read_text()
native=json.loads((p/'native-summary.json').read_text())
for name,digest in native['raw_files'].items(): assert sha(p/'native'/name)==digest
raw=(p/'native/performance_client_latest(20261008-075438).txt').read_text()
d=json.loads(raw[raw.index('{'):])
assert d['reason']=='complete' and not d['configuration_changes'] and not d['preparation_timed_out']
assert d['start_resources']['install'].strip()==base+' clean'
assert d['source']['verified'] and d['source']['checked']==15 and not d['source']['mismatches'] and not d['source']['missing']
assert d['population']['source']['verified'] and d['population']['source']['checked']==46
assert not d['population']['source']['mismatches'] and not d['population']['source']['missing']
for row in d['population']['source']['modules']:
    parent_bytes=subprocess.check_output(['git','show',base+':'+row['path']],cwd=repo)
    assert hashlib.sha256(parent_bytes).hexdigest()==row['mounted']==row['installed']
assert d['cpu_profile']['server_status']=='received'
for realm in ('client','server'): assert d['cpu_profile'][realm]['seconds']>=179
for stage in ('start','end'):
    r=d[stage+'_resources'];assert r['lua_errors']==0 and r['vr']['idle'] and r['vr']['source']['verified']
    assert r['wall_models']==1284
assert d['active']['frames']==5080 and abs(d['active']['fps']-29.651004467174783)<1e-10
revision='ANLCKQnrYkXEQkWhbY2lFbkh3C5XrRI-q4oBgGMtvVIvs78hQeS96NzZ3OIRtG4TjIZ4DGBr3d0o_ye6s_-butEXqxYjMR0xgyBfcEiqPQ'
for tab in ('00','01','06','07'):
    authority=json.loads((p/'authority'/('gdd-'+tab+'.json')).read_text())
    assert authority['documentId']=='1OSpgiWyiGmUCLFdq--WmCSZe6KQIr7_UTkQZklPV8lY' and authority['revisionId']==revision
result={'passed':True,'canonical_suites':314,'canonical_commands_checked':314,
 'matrix_raw_stream_hashes_checked':628,'matrix_individual_receipts_checked':314,
 'frozen_files':len(manifest),'source_digest':receipt['source_before'],
 'focused_checks':20,'focused_commands_checked':20,'focused_log_hashes_checked':20,
 'lua_syntax_files':885,'code_files_checked':len(code),'drawing_scenarios':750,
 'trace_sha256':paired['candidate']['trace_sha256'],'trace_bytes':paired['candidate']['trace_bytes'],
 'parent_source_files_checked':2,'native_parent_population_hashes_checked':46,'native_fps_certified':False}
if '--after-packaging' not in sys.argv: (p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
else: assert json.loads((p/'verification.json').read_text())==result
print(json.dumps(result,indent=2))
