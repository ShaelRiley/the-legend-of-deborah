#!/usr/bin/env python3
"""Replay the October 10 native capture verification, without running game tests.

Usage: python3 verify_capture.py CAPTURE_DIRECTORY REPOSITORY
The directory must contain the two original, renamed latest.txt uploads.
Read-only except for deterministic verification.json in CAPTURE_DIRECTORY.
"""
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys

BUILD = "db51ecc024472b6b273af7f55cece5bc7b843c63"
INPUT_HASHES = {
    "console_latest.txt": "34b7c249058cfdb12ebd5423211ae74923a89cbbc9efd9c7b10e95f511a44b07",
    "performance_client_latest.txt": "11a4ae479aba21bd934455e4ee59bb0acaeff0f60c311fc85f9d2dd03ae11295",
}
capture, repo = map(Path, sys.argv[1:3])
sha = lambda data: hashlib.sha256(data).hexdigest()
for filename, expected in INPUT_HASHES.items():
    assert sha((capture / filename).read_bytes()) == expected, filename
raw = (capture / "performance_client_latest.txt").read_text()
report, _ = json.JSONDecoder().raw_decode(raw[raw.index("{"):])
baseline = report["comparison"]["baseline"]
phases = {"unprofiled": baseline, "profiled": report}
assert report["comparison"]["reason"] == "complete"
assert baseline["comparison"]["reason"] == "awaiting-profile"
assert report["comparison"]["order"] == ["unprofiled", "profiled"]
preferences = {
    "lod_wall_batches": "0", "lod_reduced_effects": "1",
    "lod_third_person": "0", "lod_map_scale": "1", "lod_map_opacity": "1",
}
configuration = baseline["start_configuration"]
summary = {"build": BUILD, "input_sha256": INPUT_HASHES, "phases": {}}
for name, phase in phases.items():
    assert phase["reason"] == "complete" and phase["requested_seconds"] == 60
    assert phase["source"] == {"verified": True, "checked": 19, "mismatches": 0, "missing": 0}
    assert phase["population_status"]["state"] == "received"
    assert phase["preparation_timed_out"] is False
    assert phase["configuration_changes"] == []
    assert phase["start_configuration"] == phase["end_configuration"] == configuration
    assert all(configuration[k] == v for k, v in preferences.items())
    assert (configuration["map"], configuration["width"], configuration["height"]) == ("gm_flatgrass", 1280, 800)
    source = phase["population"]["source"]
    assert source["installLabel"].strip() == BUILD + " clean"
    assert source["verified"] and source["checked"] == 54
    assert source["missing"] == source["mismatches"] == 0
    assert len(source["modules"]) == len({m["path"] for m in source["modules"]}) == 54
    for module in source["modules"]:
        frozen = subprocess.check_output(["git", "show", BUILD + ":" + module["path"]], cwd=repo)
        assert sha(frozen) == module["mounted"] == module["installed"], module["path"]
        assert sha((repo / module["path"]).read_bytes()) == sha(frozen), module["path"]
    for scope in ("all", "active"):
        frames = phase[scope]
        assert math.isclose(frames["fps"], frames["frames"] / frames["seconds"], rel_tol=1e-12)
    population = phase["population"]
    assert population["ready"] and not population["frozen"]
    assert (population["campaign"], population["seed"], population["layoutSeed"], population["level"]) == (654759237, 536325463, 337421413, 1)
    assert population["plannedBodies"] == 49
    assert [f["target"] for f in population["roaming"]["floors"]] == [18, 18]
    assert sum(f["living"] for f in population["roaming"]["floors"]) == population["aliveWanderers"]
    assert population["aliveBodies"] == population["aliveWanderers"] == (36 if name == "unprofiled" else 29)
    assert len(phase["windows"]) == 12
    for window in phase["windows"]:
        renderer = window["renderer"]
        assert renderer["status"] == "native" and renderer["hidden"] == 0
        assert renderer["reason"] == "wall-batches-disabled"
        assert renderer["section"]["ready"] and renderer["section"]["complete"]
        assert renderer["section"]["instances"] == renderer["section"]["applied"] == 1476
    view = phase["comparison_view"]
    first, last = view["first_sample"], view["last_sample"]
    distance = math.sqrt(sum((last[a] - first[a]) ** 2 for a in "xyz"))
    samples = [first] + [w["comparison_view"] for w in phase["windows"]] + [last]
    stationary = all(sample == first for sample in samples)
    assert not stationary and distance > 2500
    active_windows = [w for w in phase["windows"] if w["active_seconds"] > 0]
    summary["phases"][name] = {
        "source_modules_independently_verified": 54, "client_sources_reported_verified": 19,
        "all": phase["all"], "active": phase["active"],
        "windows": [{k: w[k] for k in ("active_frames", "active_seconds", "fps")} for w in phase["windows"]],
        "active_windows_at_least_40_fps": sum(w["fps"] >= 40 for w in active_windows),
        "active_window_count": len(active_windows), "stationary": stationary,
        "endpoint_displacement_source_units": distance, "first_view": first, "last_view": last,
        "alive_bodies_snapshot": population["aliveBodies"],
        "wandering_floors": population["roaming"]["floors"],
    }

cpu = report["cpu_profile"]
assert baseline.get("cpu_profile") is None
assert cpu["server_status"] == "received"
summary["profiles"] = {}
for realm, rows, reason in (("client", 270, "complete"), ("server", 369, "client-stop")):
    profile = cpu[realm]
    assert profile["reason"] == reason and len(profile["rows"]) == rows
    assert 60 <= profile["seconds"] < 61
    assert "inclusive" in profile["timing"] and "GPU unmeasured" in profile["timing"]
    assert all(row["calls"] == row["completed"] and row["calls"] >= 0 for row in profile["rows"])
    assert len({r["name"] for r in profile["rows"]}) == rows
    if realm == "server":
        for state in (profile["state_start"], profile["state_end"]):
            assert (state["campaign"], state["seed"]) == (654759237, 337421413)
    summary["profiles"][realm] = {
        "rows": rows, "seconds": profile["seconds"], "reason": reason,
        "all_calls_completed": True, "timing": profile["timing"],
        "largest_inclusive_rows": sorted(profile["rows"], key=lambda r: r["milliseconds"], reverse=True)[:12],
    }

def dictionaries(value, path="report"):
    if isinstance(value, dict):
        yield path, value
        for k, v in value.items():
            yield from dictionaries(v, path + "." + k)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            yield from dictionaries(v, f"{path}[{i}]")

vr_paths, error_paths, installs = [], [], []
for path, item in dictionaries(report):
    if "lua_errors" in item:
        assert item["lua_errors"] == 0, path
        error_paths.append(path)
    if "install" in item:
        assert item["install"].strip() == BUILD + " clean", path
        installs.append(path)
    if "vr" in item:
        vr = item["vr"]
        assert vr["idle"] and vr["active"] is False and vr["local_tracking"] is False, path
        assert all(vr[k] == 0 for k in ("players", "native_resources", "recurring_timers", "runtime_hooks", "pending_once", "method_overrides")), path
        assert not vr.get("adapter_think", False), path
        assert all(v == 0 for v in (vr["resource_counts"].values() if isinstance(vr["resource_counts"], dict) else vr["resource_counts"])), path
        source = vr["source"]
        assert source["verified"] and source["checked"] == 139 and source["bridge_checked"] == 2
        assert source["missing"] == source["mismatches"] == 0
        vr_paths.append(path)
assert vr_paths and error_paths and installs
console = (capture / "console_latest.txt").read_text().splitlines()
assert any("server_status=received server_rows=369" in line for line in console)
assert all(v == "0" for line in console for v in re.findall(r"lua_errors=(\d+)", line))
# Telemetry contains binding names such as OnLuaError/ErrorNoHalt, not errors.
plain = [(i, line) for i, line in enumerate(console, 1) if not line.startswith(("[LOD:POPULATION]", "[LOD:CRATE]", "[LOD:CRATE-BRAND]"))]
lua_errors = [(i, line) for i, line in plain if re.search(r"\[ERROR\]|Lua Error|\bLUA_ERROR\b", line, re.I)]
assert not lua_errors, lua_errors
material_warnings = [(i, line) for i, line in plain if "multiply defined in material" in line or "Must use $normalmapalphaenvmapmask" in line or "which is not a texture value" in line]
summary.update({
    "configuration": configuration, "fixed_preferences": preferences,
    "workload": {"campaign": 654759237, "level_seed": 536325463, "layout_seed": 337421413, "level": 1, "native_wall_models": 1476, "initial_living_wanderers": 36, "planned_bodies": 49},
    "vr_idle_samples": len(vr_paths), "zero_lua_error_samples": len(error_paths),
    "exact_install_samples": len(installs), "console_lua_errors": lua_errors,
    "material_warnings": material_warnings,
    "stationary_pair_valid": False, "profiler_overhead_attribution_valid": False,
    "sustained_40_fps_accepted": False,
    "limitation": "View, active-time coverage, combat and living population changed. Timing rows overlap and include diagnostic overhead; GPU is unmeasured. Native control and appearance acceptance needs observations.",
})
(capture / "verification.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
print(json.dumps({"result": "verified below-target native evidence; stationary pair invalid", "build": BUILD, "source_modules": 54, "profile_rows": {k: v["rows"] for k, v in summary["profiles"].items()}, "unprofiled_fps": baseline["active"]["fps"], "profiled_fps": report["active"]["fps"], "vr_idle_samples": len(vr_paths), "zero_lua_error_samples": len(error_paths), "verification_sha256": sha((capture / "verification.json").read_bytes())}, sort_keys=True))
