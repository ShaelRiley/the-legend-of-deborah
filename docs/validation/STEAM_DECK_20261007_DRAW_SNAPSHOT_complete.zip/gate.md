# Static geometry draw snapshot checkpoint

Parent: verified clean main `8f6667098481dbcd034efe9013b05a95086f386b`.
The stalled thread's Magic/Q/M/toolgun correction is already published; all four
Actions workflows pass on that exact commit. Continue the author-authorized
Steam Deck optimization rather than repeating that completed work.

Live GDD navigation: 00 -> 01 -> 07, LOD-IMPL-001 through -004, revision
`ANLCKQn7d-0muOCBGrHxJZ-shoI_Yvc0LXT2Tt_EkfyBDDkUHTdJFncQC8CWpGDv3yesApEO0O5wBPR-vHKFlvLi0w2D5-CQrk7BKIzGhQ`.
No new design or tuning values. Preserve native walls and all geometry, collision,
population, combat, materials, warning outlines, meshes, UVs and current controls.

## Evidence and finite source gate

The latest exact-source `9f88e54` native capture measures 23.7135 active FPS
over 129.082559 active seconds; sustained >=40 FPS remains unmet. Idle VR has
zero recurring work/resources in all 42 snapshots. Static geometry is the largest
measured custom client callback at 138.412 inclusive milliseconds per second.
Nested profiler rows overlap; this is neither GPU timing nor a controlled
before/after comparison. The intervening cost/input correction does not change
the static geometry authority.

Before implementation, define this bounded change: reuse the generated box's
already-validated scalar snapshot in the existing owner mesh/transform cache,
avoiding a second set of native vector/angle component reads in the same pass.
The entity renderer must still read bounds and pose on every pass; immediate
mutations, cameras and culling are not deferred. General direct mesh APIs retain
their existing behavior when no matching snapshot is provided.

Extend the existing production renderer probe with native vector-boundary doubles
and run the exact parent/candidate modules through that same probe. In the fixed
120-box/120-pass scene, require identical draws, meshes, matrices, UV/material/tint
and resource ceilings, while reducing native vector component reads to one set
per box/pass. Retain visible-corner and conservative-plane oracles, nested views,
geometry/pose/kind/hidden mutations, malformed views, datatable/full-update and
Lua-refresh recovery, direct API behavior, cache eviction and cleanup. Exercise
all three production floor/stair/grate routes plus unmatched snapshot fallback.

Run focused renderer/geometry/palette/native-lifetime/capture/profile/population
and accepted Magic/Q/M/VR regressions, full Lua syntax and the complete frozen
integration matrix. Verify unchanged source during the frozen gate and the exact
published tree/parent. Source operation counts do not certify hardware FPS.
The next native gate is the existing three-minute gm_flatgrass capture with native
walls and Reduced Effects, retaining the same Proton/windowed/graphics settings.
No Workshop publication or VPS deployment is included.

## Implemented source and paired results

The existing scalar box snapshot is passed through Draw/DrawSlab/DrawGrate into
the canonical weak-owner cache. Raw owner/vector/angle identity is checked without
native equality metamethods. Bounds, UV displacement/yaw and transform values
share the already-validated scalars; the entity renderer still obtains all four
native geometry getters every pass. Cache compilation, LRU renewal, eviction,
materials, model matrices and draw submission remain the same authorities.

| Fixed 120 boxes / 120 passes | Exact parent | Candidate |
| --- | ---: | ---: |
| Native vector component reads | 273,600 | 129,600 |
| Native geometry getters | 57,600 | 57,600 |
| Repeated mesh-key formats / matrix allocations | 0 / 0 | 0 / 0 |
| Camera absolute-value operations | 1,800 | 1,800 |
| Cached native axis component reads | 1,080 | 1,080 |
| Initial peak native meshes | 61 | 61 |

The 120 sorted submission records are byte-identical (positions, orientations,
mesh vertices/normals/UVs, tint and blend), SHA256
`2ca01812775223408159fa32f182cea61241a0020fdb96d26fee0601be2929a1`.
Both sources pass all 173 visible-corner and 73 conservative-plane cases,
including three intersections without an inside corner. The exact parent fails
the new repeated-native-read requirement as an explicit negative control.
All floor/stair/underdeck/grate routes and unmatched-owner/argument fallback are
exercised; direct APIs, mutations, eviction, cleanup and refresh retain their gates.
The decrease is 52.63% of measured vector component accesses, not total rendering
time or measured FPS. Complete integration validation remains the publication gate.
