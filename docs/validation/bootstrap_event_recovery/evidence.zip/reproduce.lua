local F=dofile('tools/event_expansion_fixture.lua')
local R,D,Run=F.R,F.D,F.Run
local plan=D.Plan
local captured
D.Plan=function(self,g,options) captured=g;return plan(self,g,options) end
Run.State.Level=1
for n=1,48 do
 local seed=LOD.Seeds.Derive(198761983,'bootstrap:'..n)
 local p,reason=F.Build(seed)
 print('BOOT_SAMPLE '..n..' '..seed..' '..tostring(p~=nil)..' '..tostring(p and table.concat(p.selected,',') or reason))
 if not p then
  print('BOOT_DIAGNOSTIC '..WalletJSONEncode(D.LastPlanDiagnostics))
  local def=R.Definitions.skeleton_blockade
  local valid,total=0,0
  for _,cell in ipairs(captured.CriticalPath) do
   total=total+1
   if def.Place(def,D,captured,cell,{}) then valid=valid+1 end
  end
  print('BOOT_AVAILABLE '..valid..'/'..total)
  break
 end
end
