local e=dofile('tools/music_test_fixture.lua')
CLIENT=true;CreateConVar('lod_music_enabled','1')
dofile('gamemodes/legend_of_deborah/gamemode/lod/cl_music.lua')
local D=LOD.MusicDirector;D.ServerOn=true
local p=LOD.Music.Plan(e.catalog(),{set='all'},1,'bench',4,1);D.Plans[p.id]=p
D.Current={plan=p.id,epoch=1,sequence=1,role='T0',targets={{block=p.floors[1],weight=1}}}
e.step();e.complete(1,16);e.step(40)
local selections=0;local original=D.Desired
function D:Desired() selections=selections+1;return original(self) end
local writes=e.volumeWrites
for i=1,120 do e.now=e.now+1/120;D:Tick() end
print('after selections='..selections..' volume_writes='..(e.volumeWrites-writes)..' frames=120 simulated_seconds=1 voices=1')
