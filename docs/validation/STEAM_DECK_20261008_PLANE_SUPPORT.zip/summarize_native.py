from pathlib import Path
import hashlib,json,re

p=Path(__file__).resolve().parent
raw=(p/'native/performance_client_latest(20261008-152110).txt').read_text()
d=json.loads(raw[raw.index('{'):])
console=(p/'native/console_latest(20261008-152110).txt').read_text()
population=[]
for line in console.splitlines():
 if line.startswith('[LOD:POPULATION] '):
  population.append(json.loads(line.partition('] ')[2]))
for pattern in (r'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----',
 r'\b(?:github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9]{20,})\b',
 r'\bsv_setsteamaccount\s+["\x27]?[A-Fa-f0-9]{32}\b'):
 assert not re.search(pattern,raw+console),'Native evidence contains a credential marker'
def sha(f): return hashlib.sha256(f.read_bytes()).hexdigest()
summary={
 'capture':'2026-10-08T10:21:10-05:00','parent_head':'30d180fdb07da51001e3f029c72ff05e8deaa7c2',
 'raw_files':{f.name:sha(f) for f in sorted((p/'native').iterdir()) if f.is_file()},
 'reason':d['reason'],'preparation_timed_out':d['preparation_timed_out'],
 'configuration_changes':d['configuration_changes'],'configuration':d['start_configuration'],
 'active':d['active'],'all':d['all'],'total_seconds':d['total_seconds'],
 'client_source':d['source'],'population_source':d['population']['source'],
 'profile_seconds':{r:d['cpu_profile'][r]['seconds'] for r in ('client','server')},
 'server_profile_status':d['cpu_profile']['server_status'],
 'profile_timing':d['cpu_profile']['client']['timing'],
 'client_profile_rows':d['cpu_profile']['client']['rows'],
 'server_profile_rows':d['cpu_profile']['server']['rows'],
 'resources':{r:d[r+'_resources'] for r in ('start','end')},
 'population':{k:d['population'][k] for k in ('seed','campaign','layoutSeed','layoutAttempt','mazeAttempt','ceiling','aliveWanderers','aliveBodies','plannedBodies','gates','entry')},
 'last_console_entry':population[-1]['entry'],
 'console_material_warnings':console.count('is multiply defined in material'),
 'target_fps':40,'native_fps_accepted':False,
 'attribution':'The maze/wall/body workload differs from the preceding capture. Neither FPS nor portrait timing changes isolate the aligned-HUD source change. Static support arithmetic counts do not establish a native FPS gain.'
}
(p/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'active_fps':d['active']['fps'],'profiles':summary['profile_seconds'],
 'console_admission_denials':summary['last_console_entry']['stats']['admissionDenied'],
 'native_fps_accepted':False}))
