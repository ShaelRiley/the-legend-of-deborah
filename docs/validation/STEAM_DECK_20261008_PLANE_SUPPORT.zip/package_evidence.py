from pathlib import Path
import hashlib,json,os,subprocess,zipfile

repo=Path(os.environ.get('LOD_REPO','/workspace/scratch/6473023bfe43/the-legend-of-deborah'))
p=Path(__file__).resolve().parent
subprocess.run(['python3',str(p/'verify_evidence.py')],cwd=repo,check=True)
v=json.loads((p/'verification.json').read_text())
code=json.loads((p/'validated-code-manifest.json').read_text())
for name,digest in code.items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
checks=(f"The frozen final source passes **29/29 focused checks, 314/314 canonical suites "
 f"and 885 Lua parses**. All {v['frozen_files']:,} source files remain unchanged during "
 "both gates. Every canonical and focused command/receipt and all 628 matrix "
 "stream hashes plus 29 focused log hashes are independently checked. Only "
 "documentation/evidence packaging follows; both changed code/test hashes are "
 "rechecked before publication. The adjacent checks JSON and ZIP preserve raw "
 "native uploads, fresh live normalized GDD tabs, exact parent/candidate sources, "
 "paired traces/work counts, the expected failing parent work gate, all three "
 "fixture failures, complete full/focused commands, receipts, raw streams and "
 "source manifests. No failed fixture contributes accepted results.\n")
report=(p/'report-draft.md').read_text().replace('VALIDATION_RESULTS',checks)
assert 'VALIDATION_RESULTS' not in report
(repo/'docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT.md').write_text(report)
plan=repo/'docs/DEVELOPMENT_PLAN.md'
old=("and accepted renderer/cache/resource regressions. Freeze source for the finite\n"
 "29-check renderer gate, 314 canonical suites and 885 Lua parses; independently\n"
 "verify commands, receipts, streams and source/code hashes before publication.\n"
 "Validation pending.")
new=("and accepted renderer/cache/resource regressions. The frozen source passes\n"
 f"29/29 focused checks, 314/314 canonical suites and 885 Lua parses. All {v['frozen_files']:,}\n"
 "source files remain unchanged during both gates; every command/receipt, 628\n"
 "matrix stream hashes and 29 focused log hashes are independently checked.\n"
 "Earlier fixture failures remain preserved and unused. Only documentation/\n"
 "evidence packaging follows; both changed code/test hashes are rechecked before\n"
 "non-force main publication.")
s=plan.read_text();assert s.count(old)==1
plan.write_text(s.replace(old,new))
archive=repo/'docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts: z.write(f,f.relative_to(p))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 members=len(z.namelist())
 for name,digest in code.items(): assert hashlib.sha256(z.read('candidate/'+name)).hexdigest()==digest
summary={'version':'steam-deck-exact-plane-support-20261008',
 'parent_head':'30d180fdb07da51001e3f029c72ff05e8deaa7c2',
 'parent_tree':'b0c8b44d3ce2b51ca84fe1755779a64c366abd9b',
 'gdd_document':'1OSpgiWyiGmUCLFdq--WmCSZe6KQIr7_UTkQZklPV8lY',
 'gdd_revision':'AHj4eMRd4acJKKEDgqukO9zGvoMQvxlbUMdF6nZCAXYFhQm-CNvzGIub5PLIO_oXk6fEWbrk_V-_2bJc4m1wqQvkXjzdDNhY5wQfHSd7Pg',
 'gdd_tabs':['00','01','05','07'],'verification':v,'code_sha256':code,
 'paired':{'render_pass_scenarios':300,'trace_sha256':v['trace_sha256'],'trace_bytes':v['trace_bytes'],
 'work_passes':240,'entities':120,'rotated_entities':30,'plane_support_absolute_values':[111600,0],
 'native_geometry_getters':[115200,115200],'camera_basis_component_reads':[2160,2160],
 'native_mesh_submissions':[28800,28800],'native_wireframe_submissions':[9600,9600],
 'parent_work_gate_passed':False,'native_fps_certified':False},
 'native_capture':json.loads((p/'native-summary.json').read_text()),
 'archive':{'filename':archive.name,'bytes':archive.stat().st_size,
 'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members}}
(repo/'docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT_CHECKS.json').write_text(json.dumps(summary,indent=2)+'\n')
subprocess.run(['python3',str(p/'verify_evidence.py'),'--after-packaging'],cwd=repo,check=True)
print(json.dumps(summary['archive'],indent=2))
