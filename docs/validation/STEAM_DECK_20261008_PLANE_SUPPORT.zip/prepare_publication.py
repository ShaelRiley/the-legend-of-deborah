from pathlib import Path
import hashlib,json,subprocess

repo=Path('/workspace/scratch/6473023bfe43/the-legend-of-deborah')
p=Path(__file__).resolve().parent
base='30d180fdb07da51001e3f029c72ff05e8deaa7c2'
files=['gamemodes/legend_of_deborah/entities/entities/lod_static_box/cl_init.lua','tools/test_low_end_render.lua',
       'docs/DEVELOPMENT_PLAN.md','docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT.md',
       'docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT_CHECKS.json',
       'docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT.zip']
def git(*args): return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
assert git('rev-parse','HEAD')==base
staged=git('diff','--cached','--name-only').splitlines()
assert set(staged)==set(files),staged
assert not git('diff','--name-only')
code=json.loads((p/'validated-code-manifest.json').read_text())
for name,digest in code.items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
entries=[]
for name in files:
    data=(repo/name).read_bytes()
    mode,sha,stage,path=git('ls-files','--stage','--',name).split(None,3)
    assert mode=='100644' and stage=='0' and path==name
    assert sha==git('hash-object','--',name)
    entries.append({'path':name,'mode':mode,'type':'blob','sha':sha,
                    'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
meta={'parent':base,'parent_tree':git('rev-parse','HEAD^{tree}'),
      'staged_tree':git('write-tree'),'files':entries}
(p/'publication-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
