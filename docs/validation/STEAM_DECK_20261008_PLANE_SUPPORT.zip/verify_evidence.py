from pathlib import Path
import hashlib,json,os,subprocess,sys

repo=Path(os.environ.get('LOD_REPO','/workspace/scratch/6473023bfe43/the-legend-of-deborah'))
p=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'tools'))
import test_checkpoint_g_integration as g
import test_low_end_render_gate as focused
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((p/'gate/matrix/source_manifest.json').read_text())
receipt=json.loads((p/'gate/matrix/receipt.json').read_text())
assert receipt['passed']==receipt['total']==len(g.SUITES)==314
assert receipt['lua_files']==885 and not receipt['changed_during_gate']
assert receipt['source_before']==receipt['source_after']==g.snapshot_digest(manifest)
current=g.source_snapshot()
changed={n for n in manifest.keys()|current.keys() if manifest.get(n)!=current.get(n)}
if '--after-packaging' in sys.argv:
 allowed={'docs/DEVELOPMENT_PLAN.md','docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT.md',
          'docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT_CHECKS.json','docs/validation/STEAM_DECK_20261008_PLANE_SUPPORT.zip'}
 assert changed<=allowed,changed
else: assert not changed,changed
for row,expected in zip(receipt['results'],g.SUITES):
 assert (row['name'],row['command'])==expected and row['returncode']==0
 stem=row['log_prefix']
 assert json.loads((p/'gate/matrix'/(stem+'.json')).read_text())==row
 for channel in ('stdout','stderr'):
  assert sha(p/'gate/matrix'/(stem+'.'+channel+'.txt'))==row[channel+'_sha256']
focus=json.loads((p/'gate/focus/receipt.json').read_text())
assert focus['passed']==focus['total']==29 and focus['lua_files']==885
assert not focus['changed_during_gate']
assert focus['source_before']==focus['source_after']==receipt['source_before']
assert len(focused.gate.LUA)==23
expected={n:['python3','tools/test_crypto_sqlite.py' if n in focused.gate.SQLITE_LUA else 'tools/run_lua54.py','tools/'+n] for n in focused.gate.LUA}
expected.update({'manual_catalog_parity':['python3','tools/run_lua54.py','tools/export_manual_catalog.lua','--check'],
 'test_manual_document.py':['python3','tools/test_manual_document.py'],
 'test_dev_population_manifest.py':['python3','tools/test_dev_population_manifest.py'],
 'test_great_crate_assets.py':['python3','tools/test_great_crate_assets.py'],
 'git_diff_check':['git','diff','HEAD','--check'],
 'lua_syntax':['python3','tools/run_lua54.py','--syntax']+g.LUA_FILES})
assert {r['name'] for r in focus['results']}==expected.keys()
for row in focus['results']:
 assert row['command']==expected[row['name']] and row['returncode']==0
 assert json.loads((p/'gate/focus'/(row['name']+'.json')).read_text())==row
 assert sha(p/'gate/focus'/row['log'])==row['log_sha256']
code=json.loads((p/'validated-code-manifest.json').read_text())
assert len(code)==2
for name,digest in code.items():
 assert sha(repo/name)==digest and sha(p/'candidate'/name)==digest
base='30d180fdb07da51001e3f029c72ff05e8deaa7c2'
source={'cl_init.lua':'gamemodes/legend_of_deborah/entities/entities/lod_static_box/cl_init.lua',
 'cl_textured_box.lua':'gamemodes/legend_of_deborah/gamemode/lod/cl_textured_box.lua',
 'shared.lua':'gamemodes/legend_of_deborah/entities/entities/lod_static_box/shared.lua'}
for name,path in source.items():
 original=subprocess.check_output(['git','show',base+':'+path],cwd=repo)
 assert (p/'parent'/name).read_bytes()==original
 assert (p/'candidate'/name).read_bytes()==(repo/path).read_bytes()
paired=json.loads((p/'paired-receipt.json').read_text())
assert paired['parent']['trace_sha256']==paired['candidate']['trace_sha256']=='bd7532831b3d2a97349e8f9cb1ffa71eb8830c106807117dbf9d4a5b02e318b7'
for label in ('parent','candidate','negative'):
 row=paired[label];source='parent' if label=='negative' else label
 expected_cmd=['python3','tools/run_lua54.py','tools/test_low_end_render.lua',
  '--support-gate' if label=='negative' else '--support-probe',str(p/source/'cl_textured_box.lua'),
  str(p/source/'cl_init.lua'),str(p/(label+'.trace.txt')),str(p/source/'shared.lua')]
 assert row['command']==expected_cmd
 for channel in ('stdout','stderr'): assert sha(p/(label+'.'+channel+'.txt'))==row[channel+'_sha256']
 if label!='negative':
  assert row['returncode']==0 and row['trace_bytes']==17519028
  assert sha(p/(label+'.trace.txt'))==row['trace_sha256']
  assert 'passes=300' in row['parity_result']
  assert ('absolute_values=111600' if label=='parent' else 'absolute_values=0 ') in row['work_result']
  assert 'native_geometry_getters=115200 camera_basis_reads=2160 native_draws=28800 wireframes=9600' in row['work_result']
assert (p/'parent.trace.txt').read_bytes()==(p/'candidate.trace.txt').read_bytes()
assert paired['negative']['returncode']==1 and not (p/'negative.trace.txt').exists()
assert 'unchanged view axes repeat plane-support arithmetic' in (p/'negative.stderr.txt').read_text()
for name,expected in [('first','SetupDataTables'),('second',"field 'angles'"),('third','support pass leaked native state')]:
 assert expected in (p/('fixture-'+name+'.stderr.txt')).read_text()
assert not (p/'fixture-final.stderr.txt').read_text()
native=json.loads((p/'native-summary.json').read_text())
for name,digest in native['raw_files'].items(): assert sha(p/'native'/name)==digest
raw=(p/'native/performance_client_latest(20261008-152110).txt').read_text()
d=json.loads(raw[raw.index('{'):])
assert d['reason']=='complete' and not d['configuration_changes'] and not d['preparation_timed_out']
assert d['start_resources']['install'].strip()==base+' clean'
assert d['source']['verified'] and d['source']['checked']==15 and not d['source']['mismatches'] and not d['source']['missing']
assert d['population']['source']['verified'] and d['population']['source']['checked']==46
assert not d['population']['source']['mismatches'] and not d['population']['source']['missing']
for row in d['population']['source']['modules']:
 parent_bytes=subprocess.check_output(['git','show',base+':'+row['path']],cwd=repo)
 assert hashlib.sha256(parent_bytes).hexdigest()==row['mounted']==row['installed']
assert d['cpu_profile']['server_status']=='received'
for realm in ('client','server'): assert d['cpu_profile'][realm]['seconds']>=179
for stage in ('start','end'):
 r=d[stage+'_resources'];assert r['lua_errors']==0 and r['vr']['idle'] and r['vr']['source']['verified']
 assert r['wall_models']==1338
assert d['active']['frames']==4452 and abs(d['active']['fps']-26.719207078602064)<1e-10
assert native['last_console_entry']['stats']['admissionDenied']==12339
revision='AHj4eMRd4acJKKEDgqukO9zGvoMQvxlbUMdF6nZCAXYFhQm-CNvzGIub5PLIO_oXk6fEWbrk_V-_2bJc4m1wqQvkXjzdDNhY5wQfHSd7Pg'
tabs={'00':'t.dkjl8amu37zv','01':'t.l29tf4evc12u','05':'t.8p7v8fnmr641','07':'t.bff19dm33vvw'}
for tab,id in tabs.items():
 authority=json.loads((p/'authority'/('gdd-'+tab+'.json')).read_text())
 assert authority['documentId']=='1OSpgiWyiGmUCLFdq--WmCSZe6KQIr7_UTkQZklPV8lY' and authority['revisionId']==revision and authority['tabId']==id
result={'passed':True,'canonical_suites':314,'canonical_commands_checked':314,
 'matrix_raw_stream_hashes_checked':628,'matrix_individual_receipts_checked':314,
 'frozen_files':len(manifest),'source_digest':receipt['source_before'],
 'focused_checks':29,'focused_commands_checked':29,'focused_log_hashes_checked':29,
 'lua_syntax_files':885,'code_files_checked':len(code),'render_pass_scenarios':300,
 'trace_sha256':paired['candidate']['trace_sha256'],'trace_bytes':paired['candidate']['trace_bytes'],
 'parent_source_files_checked':3,'native_parent_population_hashes_checked':46,
 'preserved_fixture_failures':3,'native_fps_certified':False}
if '--after-packaging' not in sys.argv: (p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
else: assert json.loads((p/'verification.json').read_text())==result
print(json.dumps(result,indent=2))
