from pathlib import Path
import hashlib,json,subprocess

repo=Path('/workspace/scratch/6473023bfe43/the-legend-of-deborah')
p=Path(__file__).resolve().parent
def sha(f): return hashlib.sha256(f.read_bytes()).hexdigest()
receipt={}
for label in ('parent','candidate','negative'):
 source='parent' if label=='negative' else label
 cmd=['python3','tools/run_lua54.py','tools/test_low_end_render.lua',
      '--support-gate' if label=='negative' else '--support-probe',
      str(p/source/'cl_textured_box.lua'),str(p/source/'cl_init.lua'),
      str(p/(label+'.trace.txt')),str(p/source/'shared.lua')]
 r=subprocess.run(cmd,cwd=repo,capture_output=True)
 for channel in ('stdout','stderr'): (p/(label+'.'+channel+'.txt')).write_bytes(getattr(r,channel))
 row={'command':cmd,'returncode':r.returncode,
      **{channel+'_sha256':sha(p/(label+'.'+channel+'.txt')) for channel in ('stdout','stderr')}}
 if label!='negative':
  assert r.returncode==0,r.stderr.decode()
  row.update(trace_sha256=sha(p/(label+'.trace.txt')),trace_bytes=(p/(label+'.trace.txt')).stat().st_size)
  row['work_result']=next(s for s in r.stdout.decode().splitlines() if s.startswith('LOW_END_SUPPORT_WORK'))
  row['parity_result']=next(s for s in r.stdout.decode().splitlines() if s.startswith('LOW_END_SUPPORT_PARITY'))
 else:
  assert r.returncode!=0 and b'unchanged view axes repeat plane-support arithmetic' in r.stderr
 receipt[label]=row
 assert label=='negative' or 'passes=300' in row['parity_result']
 print(label, json.dumps(row),flush=True)
assert receipt['parent']['trace_sha256']==receipt['candidate']['trace_sha256']
assert (p/'parent.trace.txt').read_bytes()==(p/'candidate.trace.txt').read_bytes()
(p/'paired-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('EXACT_PARENT_CANDIDATE_TRACE_PASS')
