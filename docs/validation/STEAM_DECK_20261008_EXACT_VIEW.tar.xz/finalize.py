from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/809c83fce64f/the-legend-of-deborah')
TASK = Path(__file__).resolve().parent
NATIVE = TASK.parent / 'playtest'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()

pair = json.loads((TASK / 'paired-receipt.json').read_text())
native = json.loads((TASK / 'native-summary.json').read_text())
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert parent == pair['parent_sha'] == native['parent_sha']
for path, expected in pair['changed_code_hashes'].items():
    assert sha(ROOT / path) == expected, path
for label, row in ((k, pair[k]) for k in ('parent', 'candidate', 'negative')):
    for stream in ('stdout', 'stderr'):
        assert sha(TASK / 'paired' / (label + '.' + stream + '.txt')) == row[stream + '_sha256']
    if label != 'negative':
        trace = TASK / 'paired' / (label + '.trace.txt')
        assert sha(trace) == row['trace_sha256']
        assert trace.stat().st_size == row['trace_bytes']
assert pair['parent']['trace_sha256'] == pair['candidate']['trace_sha256']
assert pair['negative']['returncode'] != 0
assert b'duplicate exact views repeat box visibility arithmetic' in (TASK / 'paired' / 'negative.stderr.txt').read_bytes()
for path, expected in native['raw_file_sha256'].items():
    assert sha(NATIVE / path) == expected

matrix = json.loads((TASK / 'matrix' / 'receipt.json').read_text())
focused = json.loads((TASK / 'focused' / 'receipt.json').read_text())
spec = importlib.util.spec_from_file_location('matrix_authority', ROOT / 'tools/test_checkpoint_g_integration.py')
authority = importlib.util.module_from_spec(spec)
spec.loader.exec_module(authority)
assert matrix['total'] == len(authority.SUITES) == 315
failed = [row for row in matrix['results'] if row['returncode']]
assert all(row['returncode'] == 124 for row in failed), 'A substantive suite failure needs repair'
retry = json.loads((TASK / 'matrix-retry' / 'receipt.json').read_text()) if failed else None
if retry:
    assert retry['total'] == retry['passed'] == len(failed)
    assert not retry['changed_during_gate']
    assert retry['source_before'] == retry['source_after'] == matrix['source_before']
    assert {r['name'] for r in retry['results']} == {r['name'] for r in failed}
assert not matrix['changed_during_gate']
assert matrix['source_before'] == matrix['source_after']
frozen = json.loads((TASK / 'matrix' / 'source_manifest.json').read_text())
assert digest(frozen) == matrix['source_before']
assert authority.source_snapshot() == frozen
for row, expected in zip(matrix['results'], authority.SUITES):
    assert (row['name'], row['command']) == expected
    receipt = json.loads((TASK / 'matrix' / (row['log_prefix'] + '.json')).read_text())
    assert receipt == row
    for stream in ('stdout', 'stderr'):
        assert sha(TASK / 'matrix' / (row['log_prefix'] + '.' + stream + '.txt')) == row[stream + '_sha256']
    final = next(r for r in retry['results'] if r['name'] == row['name']) if row['returncode'] else row
    assert final['returncode'] == 0 and (final['name'], final['command']) == expected
if retry:
    for row in retry['results']:
        assert json.loads((TASK / 'matrix-retry' / (row['log_prefix'] + '.json')).read_text()) == row
        for stream in ('stdout', 'stderr'):
            assert sha(TASK / 'matrix-retry' / (row['log_prefix'] + '.' + stream + '.txt')) == row[stream + '_sha256']
assert focused['passed'] == focused['total'] == 29
assert focused['lua_files'] == matrix['lua_files'] == 885
assert not focused['changed_during_gate']
assert focused['source_before'] == focused['source_after'] == matrix['source_before']
for row in focused['results']:
    assert row['passed'] and row['returncode'] == 0
    assert sha(TASK / 'focused' / row['log']) == row['log_sha256']

verified = {
    'passed': True, 'parent_sha': parent,
    'canonical_suites': matrix['passed'] + len(failed), 'canonical_commands_checked': len(matrix['results']),
    'first_matrix_passed': matrix['passed'], 'first_matrix_total': matrix['total'],
    'preserved_timeout_failures': [{'name': r['name'], 'seconds': r['seconds']} for r in failed],
    'timeout_retry_seconds': 600 if retry else None,
    'matrix_stream_hashes_checked': (len(matrix['results']) + len(failed)) * 2,
    'focused_checks': focused['passed'], 'focused_log_hashes_checked': len(focused['results']),
    'lua_syntax_files': matrix['lua_files'], 'source_digest': matrix['source_before'],
    'frozen_files': len(frozen), 'render_scenarios': 330,
    'trace_sha256': pair['candidate']['trace_sha256'], 'trace_bytes': pair['candidate']['trace_bytes'],
    'production_code_hashes': pair['changed_code_hashes'],
    'native_parent_active_fps': native['active']['fps'],
    'native_parent_population_hashes_checked': native['population_source_hashes_independently_verified'],
    'native_parent_client_hashes_reported_verified': native['client_source_reported']['checked'],
    'native_fps_certified': False,
}
(TASK / 'verification.json').write_text(json.dumps(verified, indent=2) + '\n')
dest = ROOT / 'docs/validation/STEAM_DECK_20261008_EXACT_VIEW.tar.xz'
with tarfile.open(dest, 'w:xz', preset=6) as archive:
    for folder in ('matrix', 'matrix-retry', 'focused', 'paired', 'parent'):
        for path in sorted((TASK / folder).rglob('*')):
            if path.is_file(): archive.add(path, arcname=str(path.relative_to(TASK)))
    for name in ('paired-receipt.json', 'native-summary.json', 'verification.json', 'finalize.py',
                 'focused.stdout.txt', 'focused.stderr.txt', 'matrix.stdout.txt', 'matrix.stderr.txt', 'gdd-scope.json',
                 'run_timeout_retries.py'):
        archive.add(TASK / name, arcname=name)
    if retry:
        for name in ('matrix-retry.stdout.txt', 'matrix-retry.stderr.txt'):
            archive.add(TASK / name, arcname=name)
    for path in sorted(NATIVE.iterdir()):
        if path.is_file(): archive.add(path, arcname='native/' + path.name)
    for path in pair['changed_code_hashes']:
        archive.add(ROOT / path, arcname='changed-source/' + path)
print(json.dumps({**verified, 'archive': str(dest), 'archive_bytes': dest.stat().st_size, 'archive_sha256': sha(dest)}, indent=2))
