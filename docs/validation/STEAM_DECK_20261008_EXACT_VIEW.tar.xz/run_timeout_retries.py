from pathlib import Path
import importlib.util
import json
import sys

root = Path('/workspace/scratch/809c83fce64f/the-legend-of-deborah')
task = Path(__file__).resolve().parent
receipt = json.loads((task / 'matrix/receipt.json').read_text())
failed = [row for row in receipt['results'] if row['returncode']]
assert failed and all(row['returncode'] == 124 for row in failed)
spec = importlib.util.spec_from_file_location('matrix', root / 'tools/test_checkpoint_g_integration.py')
matrix = importlib.util.module_from_spec(spec)
spec.loader.exec_module(matrix)
assert matrix.snapshot_digest(matrix.source_snapshot()) == receipt['source_after'] == receipt['source_before']
names = {row['name'] for row in failed}
matrix.SUITES = [entry for entry in matrix.SUITES if entry[0] in names]
assert len(matrix.SUITES) == len(failed)
for name, cmd in matrix.SUITES:
    assert next(row['command'] for row in failed if row['name'] == name) == cmd
sys.argv = ['canonical_timeout_retries', '--output', str(task / 'matrix-retry'),
            '--suite-timeout', '600', '--workers', '2']
raise SystemExit(matrix.main())
