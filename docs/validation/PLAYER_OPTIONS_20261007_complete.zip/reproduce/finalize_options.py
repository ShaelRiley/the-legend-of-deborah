import hashlib
import importlib.util
import json
import re
import subprocess
import zipfile
from pathlib import Path

base=Path('/workspace/scratch/01bf015eab4d')
repo=base/'the-legend-of-deborah'
matrix=base/'options-matrix-final'
parent='bed0d45645a082583a5b42d92617742355fb3fce'
spec=importlib.util.spec_from_file_location('gate',repo/'tools/test_checkpoint_g_integration.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
receipt=json.loads((matrix/'receipt.json').read_text())
assert receipt['passed']==receipt['total']==len(gate.SUITES)==313
assert receipt['source_before']==receipt['source_after'] and not receipt['changed_during_gate']
manifest=json.loads((matrix/'source_manifest.json').read_text())
assert gate.source_snapshot()==manifest and gate.snapshot_digest(manifest)==receipt['source_after']
for row in receipt['results']:
    name,command=gate.SUITES[row['index']-1]
    assert (row['name'],row['command'],row['returncode'])==(name,command,0)
    assert json.loads((matrix/(row['log_prefix']+'.json')).read_text())==row
    for stream in ['stdout','stderr']:
        assert hashlib.sha256((matrix/(row['log_prefix']+'.'+stream+'.txt')).read_bytes()).hexdigest()==row[stream+'_sha256']
paired=json.loads((base/'options-paired/receipt.json').read_text())
assert len(paired)==2 and paired[0]['returncode']==0 and paired[1]['returncode']!=0
for row in paired:
    for stream in ['stdout','stderr']:
        assert hashlib.sha256((base/'options-paired'/(row['label']+'.'+stream+'.txt')).read_bytes()).hexdigest()==row[stream+'_sha256']
probe=(base/'options-paired/candidate.stdout.txt').read_text()
values=re.search(r'frames=(\d+) draw_submissions=(\d+) default_bytes_equal=true parent_lua_kib=([\d.]+) candidate_lua_kib=([\d.]+)',probe)
assert values and values.group(1,2)==('10000','90000')
assert float(values[3])>6000 and float(values[4])<4
assert 'transparent map still paints' in (base/'options-paired/negative-control.stderr.txt').read_text()
legacy=json.loads((base/'options-map-parent/manifest.json').read_text())
assert legacy['parent']==parent
raw=subprocess.check_output(['git','show',parent+':'+legacy['path']],cwd=repo)
assert raw==(base/'options-map-parent/cl_minimap_magic_quadrants.lua').read_bytes()
assert hashlib.sha256(raw).hexdigest()==legacy['sha256']
native=json.loads((base/'options-native.json').read_text())
assert native['verified_git_modules']==44 and native['idle_vr_snapshots']==42 and native['lua_errors']==0
assert native['active']['frames']==2799 and native['population']['aliveBodies']==64
ci=json.loads((base/'options-baseline-ci.json').read_text())
assert len(ci)==4 and all(r['sha']==parent and r['conclusion']=='success' for r in ci)
gdd_path=repo/'docs/briefs/PLAYER_OPTIONS_20261007_gdd.json'
gdd=json.loads(gdd_path.read_text());assert gdd['readbackVerified'] and gdd['occurrencesChanged']==[1]*5
changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=repo).decode().split('\0')
code=[name for name in changed if name and not name.startswith('docs/')]
code+=['docs/manual/book.json','docs/manual/manual.html']
code=sorted(set(code))
assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==manifest[name] for name in code)
doc=repo/'docs/validation/PLAYER_OPTIONS_20261007.md'
completion=f'''

## Completed frozen source gate

The complete matrix passes **313/313 suites and {len(gate.LUA_FILES)} Lua syntax
files**. Every canonical command, individual receipt and all 626 raw stream
hashes are independently checked. Source digest `{receipt['source_after']}`
covers {len(manifest):,} files with zero changes during the gate. Movement,
camera/Options, map input/caches/Magic, booklet, opt-in profile transport,
installer, population/AI/safety, lifecycle and existing VR regressions pass.
The Options camera/movement gate passes 4,768 assertions; the map gate covers
81 combined scenarios. No duplicate matrix suite is added.

The exact parent negative control fails at transparent-map painting; the
candidate passes. The paired 10,000-callback probe preserves 90,000 identical
default submissions and records {float(values[3]):,.3f} KiB versus
{float(values[4]):.3f} KiB Lua allocation. Timings in this doubled headless
environment are retained as raw evidence and are not native FPS claims.

The interrupted first inspection is preserved: its CPU-profile fixture still
listed the previous ten client sources. Extending that fixture to the same
fourteen sources passes the focused gate and this complete frozen rerun.
Only coordination/evidence files are finalized afterward; all production,
booklet and test bytes retain their tested hashes. Native visual/camera and
sustained >=40 FPS acceptance remain open.
'''
doc.write_text(doc.read_text()+completion)
archive=repo/'docs/validation/PLAYER_OPTIONS_20261007_complete.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for label,folder in [('matrix',matrix),('paired',base/'options-paired'),('parent',base/'options-map-parent'),('interrupted',base/'options-matrix')]:
        for path in sorted(folder.rglob('*')):
            if path.is_file(): z.write(path,label+'/'+str(path.relative_to(folder)))
    for name in ['options-matrix-final.log','options-matrix.log','options-native.json','options-native-summary.txt','options-baseline-ci.json']:
        z.write(base/name,'logs/'+name)
    for name in ['options-map-probe.lua','options-native-verify.py','finalize_options.py']:
        z.write(base/name,'reproduce/'+name)
    for row in native['uploads']:
        p=base/'upload'/row['name'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
        z.write(p,'native/'+row['name'])
    for name in code: z.write(repo/name,'candidate/'+name)
    z.write(gdd_path,'author/'+gdd_path.name)
    z.write(doc,'gate.md')
archive_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
proof=dict(parent_sha=parent,gdd_document_id=gdd['documentId'],gdd_revision=gdd['revisionAfter'],
    full_matrix={k:v for k,v in receipt.items() if k!='results'},
    verified_canonical_commands=313,verified_individual_receipts=313,verified_raw_stream_hashes=626,
    verified_source_files=len(manifest),tested_code_sha256={name:manifest[name] for name in code},
    paired=paired,paired_frames=10000,paired_default_submissions=90000,
    parent_lua_kib=float(values[3]),candidate_lua_kib=float(values[4]),
    native_uploads=native['uploads'],native_source=native['source_commit'],native_active=native['active'],
    native_verified_git_modules=44,native_idle_vr_snapshots=42,baseline_actions=ci,
    native_new_checkpoint_accepted=False,archive_name=archive.name,archive_bytes=archive.stat().st_size,
    archive_sha256=archive_hash)
check=repo/'docs/validation/PLAYER_OPTIONS_20261007_checks.json'
check.write_text(json.dumps(proof,indent=2)+'\n')
doc.write_text(doc.read_text()+f'''

The [independent verification receipt](PLAYER_OPTIONS_20261007_checks.json) and
[complete raw evidence](PLAYER_OPTIONS_20261007_complete.zip) retain the source
manifest, all 313 command receipts and stdout/stderr, the interrupted inspection,
paired/negative-control proof, exact parent/candidate sources, author amendment,
baseline CI and original native uploads. Archive: {archive.stat().st_size:,} bytes;
SHA256 `{archive_hash}`.
''')
plan=repo/'docs/DEVELOPMENT_PLAN.md'
text=plan.read_text();needle='The accompanying bounded performance change removes per-frame quadrant\nrectangle records; paired default drawing submissions remain identical.'
assert needle in text
plan.write_text(text.replace(needle,needle+f' The frozen gate passes\n313/313 suites and {len(gate.LUA_FILES)} Lua syntax files; the paired 10,000-frame probe\nallocates {float(values[4]):.3f} KiB versus {float(values[3]):,.3f} KiB. These are headless operation\ncounts, not native FPS.',1))
allowed={'docs/DEVELOPMENT_PLAN.md',str(doc.relative_to(repo))}
now=gate.source_snapshot()
assert all(now[name]==digest for name,digest in manifest.items() if name not in allowed)
assert all(now[name]==manifest[name] for name in code)
print(json.dumps(dict(passed=receipt['passed'],syntax_files=len(gate.LUA_FILES),source_files=len(manifest),
    source_digest=receipt['source_after'],code_files=len(code),archive_bytes=archive.stat().st_size,archive_sha256=archive_hash),indent=2))
