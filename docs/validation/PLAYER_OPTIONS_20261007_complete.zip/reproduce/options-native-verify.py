import hashlib
import json
import subprocess
from pathlib import Path

base=Path('/workspace/scratch/01bf015eab4d')
repo=base/'the-legend-of-deborah'
source='00dd5ea74c4df55bc013fe4a5d94cc273a151c8d'
path=base/'upload/performance_client_latest(20261007-172716).txt'
text=path.read_text(); data=json.loads(text[text.index('\n{')+1:])
assert data['reason']=='complete' and not data['preparation_timed_out']
assert not data['configuration_changes']
assert data['source']==dict(verified=True,checked=10,missing=0,mismatches=0)
population=data['population']
assert population['source']['installLabel'].strip()==source+' clean'
modules=population['source']['modules']
assert len(modules)==44 and population['source']['verified']
for module in modules:
    raw=subprocess.check_output(['git','show',source+':'+module['path']],cwd=repo)
    assert hashlib.sha256(raw).hexdigest()==module['installed']==module['mounted'],module['path']
snapshots=[]
error_counts=[]
def walk(value,path='root'):
    if isinstance(value,dict):
        if 'lua_errors' in value: error_counts.append(value['lua_errors'])
        if 'vr' in value and isinstance(value['vr'],dict): snapshots.append((path,value['vr']))
        for key,item in value.items(): walk(item,path+'.'+key)
    elif isinstance(value,list):
        for index,item in enumerate(value): walk(item,path+f'[{index}]')
walk(data)
assert len(snapshots)==42,len(snapshots)
assert len(error_counts)>=6 and all(n==0 for n in error_counts),error_counts
for label,vr in snapshots:
    assert vr['idle'] and not vr['active'] and not vr.get('adapter_think',False),label
    assert all(vr[k]==0 for k in ['players','runtime_hooks','recurring_timers','method_overrides','pending_once','native_resources']),label
    assert vr['source']==dict(verified=True,checked=139,bridge_checked=2,missing=0,mismatches=0),label
assert data['start_resources']['lua_errors']==data['end_resources']['lua_errors']==0
uploads=[]
for name in ['performance_client_latest(20261007-172716).txt','console_latest(20261007-172716).txt']:
    p=base/'upload'/name
    uploads.append(dict(name=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
out=dict(source_commit=source,active=data['active'],all=data['all'],reason=data['reason'],elapsed_seconds=data['elapsed_seconds'],
    total_seconds=data['total_seconds'],preparation_timed_out=data['preparation_timed_out'],configuration_changes=data['configuration_changes'],
    start_configuration=data['start_configuration'],source=data['source'],verified_git_modules=len(modules),
    idle_vr_snapshots=len(snapshots),wall_models=data['end_resources']['wall_models'],
    client_start_entities=data['start_resources']['entities'],client_end_entities=data['end_resources']['entities'],
    population={k:population[k] for k in ['aliveBodies','aliveWanderers','plannedBodies','ready','frozen','level','campaign','seed','layoutSeed']},
    lua_errors=0,uploads=uploads,cpu_profile=data['cpu_profile'])
(base/'options-native.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['cpu_profile','uploads','start_configuration']},indent=2))
