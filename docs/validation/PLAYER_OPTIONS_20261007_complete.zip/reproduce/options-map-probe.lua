-- Paired production callbacks: warmed headless Lua allocations, not native FPS.
local fixture=dofile('tools/test_minimap_player_marker.lua')
local root='gamemodes/legend_of_deborah/gamemode/lod/'
local legacy=assert(arg[1])
ScrW=function() return 1280 end;ScrH=function() return 1080 end
fixture.preferences.lod_map_scale.value=1
fixture.preferences.lod_map_opacity.value=1
fixture.Map.gridWidth=21;fixture.Map.open=true
fixture.player.magic=10
local commands=0
local function capture()
 local args={}
 surface.SetDrawColor=function(...) args[#args+1]={'color',...} end
 surface.DrawRect=function(...) args[#args+1]={'rect',...} end
 draw.SimpleText=function(text,font,x,y,color,h,v) args[#args+1]={'text',text,font,x,y,color.r,color.g,color.b,color.a,h,v} end
 fixture.hooks.PostDrawHUD.LOD_MinimapQuadrantPresentation()
 return args
end
local function signature(rows)
 local text={}
 for _,row in ipairs(rows) do for _,v in ipairs(row) do text[#text+1]=type(v)=='number' and string.format('%.17g',v) or tostring(v) end end
 return table.concat(text,'|')
end
local new=fixture.hooks.PostDrawHUD.LOD_MinimapQuadrantPresentation
local newSignature=signature(capture())
dofile(legacy)
local old=fixture.hooks.PostDrawHUD.LOD_MinimapQuadrantPresentation
local oldSignature=signature(capture())
assert(newSignature==oldSignature,'default draw submissions differ')
surface.SetDrawColor=function() commands=commands+1 end
surface.DrawRect=function() commands=commands+1 end
draw.SimpleText=function() commands=commands+1 end
local function measure(fn)
 fn();collectgarbage('collect');collectgarbage('collect');collectgarbage('stop')
 local before=collectgarbage('count');local started=os.clock();local calls=commands
 for _=1,10000 do fn() end
 local seconds=os.clock()-started;local allocated=collectgarbage('count')-before
 collectgarbage('restart');collectgarbage('collect')
 assert(commands-calls==90000,'draw work changed')
 return allocated,seconds
end
local oldKB,oldSeconds=measure(old)
local newKB,newSeconds=measure(new)
print(string.format('probe parent_kib=%.6f candidate_kib=%.6f',oldKB,newKB))
assert(oldKB>6000 and newKB<4,'quadrant table allocation reduction not proved')
print(string.format('MAP_OPTIONS_PAIRED_PASS frames=10000 draw_submissions=90000 default_bytes_equal=true parent_lua_kib=%.6f candidate_lua_kib=%.6f parent_cpu_seconds=%.6f candidate_cpu_seconds=%.6f',oldKB,newKB,oldSeconds,newSeconds))
