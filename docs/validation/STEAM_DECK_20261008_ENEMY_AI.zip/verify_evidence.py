from pathlib import Path
import hashlib,json,os,subprocess,sys

repo=Path(os.environ.get('LOD_REPO','/workspace/scratch/6473023bfe43/the-legend-of-deborah'))
p=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'tools'))
import test_checkpoint_g_integration as g
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((p/'gate/matrix/source_manifest.json').read_text())
receipt=json.loads((p/'gate/matrix/receipt.json').read_text())
assert receipt['passed']==receipt['total']==len(g.SUITES)==314
assert receipt['lua_files']==885 and not receipt['changed_during_gate']
assert receipt['source_before']==receipt['source_after']==g.snapshot_digest(manifest)
current=g.source_snapshot()
changed={n for n in manifest.keys()|current.keys() if manifest.get(n)!=current.get(n)}
if '--after-packaging' in sys.argv:
    allowed={'docs/DEVELOPMENT_PLAN.md','docs/validation/STEAM_DECK_20261008_ENEMY_AI.md',
             'docs/validation/STEAM_DECK_20261008_ENEMY_AI_CHECKS.json','docs/validation/STEAM_DECK_20261008_ENEMY_AI.zip'}
    assert changed<=allowed,changed
else: assert not changed,changed
for row,expected in zip(receipt['results'],g.SUITES):
    assert (row['name'],row['command'])==expected and row['returncode']==0
    stem=row['log_prefix']
    assert json.loads((p/'gate/matrix'/(stem+'.json')).read_text())==row
    for channel in ('stdout','stderr'):
        assert sha(p/'gate/matrix'/(stem+'.'+channel+'.txt'))==row[channel+'_sha256']
focus=json.loads((p/'gate/focus/receipt.json').read_text())
assert focus['passed']==focus['total']==21 and focus['lua_files']==885
assert not focus['changed_during_gate']
assert focus['source_before']==focus['source_after']==receipt['source_before']
lua=['test_enemy_ai_work.lua','test_enemy_close_defense.lua','test_entry_safety_hotpath.lua',
     'test_bestiary_b29.lua','test_bestiary_b29_dispatch.lua','test_bestiary_b29_combat.lua',
     'test_status_elements.lua','test_enemy_roster.lua','test_hostile_route_cache.lua',
     'test_watcher_dispatch.lua','test_enemy_update.lua','test_enemy_attack_animation.lua',
     'test_skeleton_animation.lua','test_cleanup_lifecycle.lua','test_population_transport.lua']
expected={n:['python3','tools/run_lua54.py','tools/'+n]+(['--runtime'] if n=='test_bestiary_b29.lua' else []) for n in lua}
expected.update({'manual_catalog_parity':['python3','tools/run_lua54.py','tools/export_manual_catalog.lua','--check'],
 'test_manual_document.py':['python3','tools/test_manual_document.py'],
 'test_dev_population_manifest.py':['python3','tools/test_dev_population_manifest.py'],
 'test_great_crate_assets.py':['python3','tools/test_great_crate_assets.py'],
 'git_diff_check':['git','diff','HEAD','--check'],
 'lua_syntax':['python3','tools/run_lua54.py','--syntax']+sorted(str(f.relative_to(repo)) for base in ('gamemodes','lua','tools') for f in (repo/base).rglob('*.lua'))})
assert {r['name'] for r in focus['results']}==expected.keys()
for row in focus['results']:
    assert row['command']==expected[row['name']] and row['returncode']==0
    assert json.loads((p/'gate/focus'/(row['name']+'.json')).read_text())==row
    assert sha(p/'gate/focus'/row['log'])==row['log_sha256']
code=json.loads((p/'validated-code-manifest.json').read_text())
assert len(code)==9
for name,digest in code.items():
    assert sha(repo/name)==digest and sha(p/'candidate'/name)==digest
base='0388d032b48a3b310d0429b44ca44791842aea52'
for name in ('sv_enemy_melee.lua','sv_entry_safety.lua'):
    original=subprocess.check_output(['git','show',base+':gamemodes/legend_of_deborah/gamemode/lod/'+name],cwd=repo)
    assert (p/'parent'/name).read_bytes()==original
paired=json.loads((p/'paired-receipt.json').read_text())
assert paired['parent']['trace_sha256']==paired['candidate']['trace_sha256']
for label in ('parent','candidate'):
    row=paired[label];assert row['returncode']==0 and row['trace_rows']==20608
    assert sha(p/(label+'.trace.txt'))==row['trace_sha256']
    for channel in ('stdout','stderr'): assert sha(p/(label+'.'+channel+'.txt'))==row[channel+'_sha256']
assert (p/'parent.trace.txt').read_bytes()==(p/'candidate.trace.txt').read_bytes()
assert paired['negative']['returncode']!=0
for channel in ('stdout','stderr'): assert sha(p/('parent-negative.'+channel+'.txt'))==paired['negative'][channel+'_sha256']
assert 'close defense repeats native Lua-field reads' in (p/'parent-negative.stderr.txt').read_text()
native=json.loads((p/'native-summary.json').read_text())
for name,digest in native['raw_files'].items(): assert sha(p/'native'/name)==digest
raw=(p/'native/performance_client_latest(20261008-012700).txt').read_text()
d=json.loads(raw[raw.index('{'):])
assert d['reason']=='complete' and not d['configuration_changes'] and not d['preparation_timed_out']
assert d['start_resources']['install'].strip()==base+' clean'
assert d['source']['verified'] and d['source']['checked']==15
assert d['population']['source']['verified'] and d['population']['source']['checked']==45
for row in d['population']['source']['modules']:
    parent_bytes=subprocess.check_output(['git','show',base+':'+row['path']],cwd=repo)
    assert hashlib.sha256(parent_bytes).hexdigest()==row['mounted']==row['installed']
assert d['cpu_profile']['server_status']=='received'
for realm in ('client','server'): assert d['cpu_profile'][realm]['seconds']>=179
for stage in ('start','end'):
    r=d[stage+'_resources'];assert r['lua_errors']==0 and r['vr']['idle'] and r['vr']['source']['verified']
result={'passed':True,'canonical_suites':314,'canonical_commands_checked':314,
 'matrix_raw_stream_hashes_checked':628,'matrix_individual_receipts_checked':314,
 'frozen_files':len(manifest),'source_digest':receipt['source_before'],
 'focused_checks':21,'focused_commands_checked':21,'focused_log_hashes_checked':21,
 'lua_syntax_files':885,'code_files_checked':len(code),'trace_rows':20608,
 'trace_sha256':paired['candidate']['trace_sha256'],'parent_source_files_checked':2,
 'native_parent_population_hashes_checked':45,'native_fps_certified':False}
if '--after-packaging' not in sys.argv: (p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
else: assert json.loads((p/'verification.json').read_text())==result
print(json.dumps(result,indent=2))
