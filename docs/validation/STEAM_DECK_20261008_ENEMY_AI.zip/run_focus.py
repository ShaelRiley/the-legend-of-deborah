import sys
from pathlib import Path
sys.path.insert(0,str(Path('/workspace/scratch/6473023bfe43/the-legend-of-deborah/tools')))
import test_spot10_gate as gate
gate.LABEL='ENEMY_AI_GATE'
gate.SCOPE='Shared close-defense and sanctuary work; status, primary attacks, production dispatch, motion, callback freshness and cleanup regressions'
gate.LUA=['test_enemy_ai_work.lua','test_enemy_close_defense.lua','test_entry_safety_hotpath.lua','test_bestiary_b29.lua','test_bestiary_b29_dispatch.lua','test_bestiary_b29_combat.lua','test_status_elements.lua','test_enemy_roster.lua','test_hostile_route_cache.lua','test_watcher_dispatch.lua','test_enemy_update.lua','test_enemy_attack_animation.lua','test_skeleton_animation.lua','test_cleanup_lifecycle.lua','test_population_transport.lua']
gate.SQLITE_LUA=set()
gate.EXTRA_SUITES=[]
raise SystemExit(gate.main())
