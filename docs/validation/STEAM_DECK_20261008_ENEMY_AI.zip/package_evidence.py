from pathlib import Path
import hashlib,json,os,subprocess,zipfile

repo=Path(os.environ.get('LOD_REPO','/workspace/scratch/6473023bfe43/the-legend-of-deborah'))
p=Path(__file__).resolve().parent
subprocess.run(['python3',str(p/'verify_evidence.py')],cwd=repo,check=True)
v=json.loads((p/'verification.json').read_text())
code=json.loads((p/'validated-code-manifest.json').read_text())
for name,digest in code.items(): assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
checks=(f"The frozen final source passes **21/21 focused checks, 314/314 canonical suites "
        f"and 885 Lua parses**. All {v['frozen_files']:,} source files remain unchanged during "
        "both gates. Every canonical and focused command/receipt and all 628 matrix "
        "stream hashes plus 21 focused log hashes are independently checked. Only "
        "documentation/evidence packaging follows; all nine authority/test file hashes "
        "are rechecked before publication. The adjacent checks JSON and ZIP preserve "
        "raw native uploads, exact parent/candidate sources, paired traces/work counts, "
        "the expected failing parent work gate, prior failed/interrupted attempts, "
        "final complete/focused commands, receipts, raw streams and source manifests.\n")
report=(p/'report-draft.md').read_text().replace('VALIDATION_RESULTS',checks)
(repo/'docs/validation/STEAM_DECK_20261008_ENEMY_AI.md').write_text(report)
plan=repo/'docs/DEVELOPMENT_PLAN.md'
s=plan.read_text().replace(
 "headless work counts, not hardware FPS. Freeze source for targeted checks,\n"
 "the full 314-suite matrix and 885 Lua parses; independently verify all receipts,\n"
 "streams and source hashes before non-force main publication. Validation pending.",
 f"headless work counts, not hardware FPS. The frozen source passes 21/21 focused\n"
 f"checks, 314/314 canonical suites and 885 Lua parses. All {v['frozen_files']:,} source files\n"
 "remain unchanged during both gates; every command/receipt and all 628 matrix\n"
 "stream hashes are independently checked. The installer/runtime manifest now\n"
 "covers close-defense (50 installer / 46 runtime sources); absent/mixed sources,\n"
 "transport and cached hashing pass. Earlier fixture failures and interrupted\n"
 "attempts are preserved and not reused. Only documentation/evidence packaging\n"
 "follows; all nine authority/test hashes are rechecked before publication.")
assert s!=plan.read_text() and 'Validation pending.' not in s.split('# Previous checkpoint',1)[0]
plan.write_text(s)
archive=repo/'docs/validation/STEAM_DECK_20261008_ENEMY_AI.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(p.rglob('*')):
        if f.is_file() and '__pycache__' not in f.parts: z.write(f,f.relative_to(p))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    members=len(z.namelist())
    for name,digest in code.items(): assert hashlib.sha256(z.read('candidate/'+name)).hexdigest()==digest
summary={'version':'steam-deck-shared-enemy-ai-20261008',
 'parent_head':'0388d032b48a3b310d0429b44ca44791842aea52',
 'parent_tree':'9ee10e078ae993700d699cbb86411faf8230c5dc',
 'gdd_document':'1OSpgiWyiGmUCLFdq--WmCSZe6KQIr7_UTkQZklPV8lY',
 'gdd_revision':'AHj4eMRd4acJKKEDgqukO9zGvoMQvxlbUMdF6nZCAXYFhQm-CNvzGIub5PLIO_oXk6fEWbrk_V-_2bJc4m1wqQvkXjzdDNhY5wQfHSd7Pg',
 'verification':v,'code_sha256':code,
 'paired':{'trace_rows':20608,'trace_sha256':v['trace_sha256'],
 'close_defense_calls':3600,'entity_lua_field_reads':[161400,134400],'status_queries':[12000,12000],
 'admission_calls':5001,'exact_cell_queries':[5001,2001],'position_queries':[15003,12003],
 'parent_work_gate_passed':False,'native_fps_certified':False},
 'native_capture':json.loads((p/'native-summary.json').read_text()),
 'manifest_coverage':{'installer_sources':50,'runtime_population_sources':46},
 'archive':{'filename':archive.name,'bytes':archive.stat().st_size,
 'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members}}
(repo/'docs/validation/STEAM_DECK_20261008_ENEMY_AI_CHECKS.json').write_text(json.dumps(summary,indent=2)+'\n')
subprocess.run(['python3',str(p/'verify_evidence.py'),'--after-packaging'],cwd=repo,check=True)
print(json.dumps(summary['archive'],indent=2))
