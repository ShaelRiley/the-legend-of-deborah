import hashlib, importlib.util, json, subprocess, zipfile
from pathlib import Path

root = Path('/workspace/scratch/6c9c499b7513')
repo = root/'the-legend-of-deborah'
out = root/'hud-complete-matrix-final'
parent = '7de6a8359af27713526a4d0108c110bac3bee9ed'
spec = importlib.util.spec_from_file_location('hud_matrix', repo/'tools/test_checkpoint_g_integration.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
receipt = json.loads((out/'receipt.json').read_text())
manifest = json.loads((out/'source_manifest.json').read_text())
assert receipt['total'] == receipt['passed'] == len(m.SUITES) == 311
assert receipt['lua_files'] == len(m.LUA_FILES) == 883
assert receipt['changed_during_gate'] == []
assert m.source_snapshot() == manifest
assert m.snapshot_digest(manifest) == receipt['source_before'] == receipt['source_after']
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip() == parent
for row, (name, command) in zip(receipt['results'], m.SUITES):
    assert row['name'] == name and row['command'] == command and row['returncode'] == 0
    assert json.loads((out/(row['log_prefix']+'.json')).read_text()) == row
    for stream in ('stdout','stderr'):
        data = (out/(row['log_prefix']+'.'+stream+'.txt')).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row[stream+'_sha256']
for path, digest in manifest.items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest() == digest
for source, fixture in [('cl_ui_theme.lua','hud_text_parent_ui.lua'),
                        ('cl_combat_roll_feed_semantics.lua','hud_text_parent_semantics.lua')]:
    original = subprocess.check_output(['git','show',parent+':gamemodes/legend_of_deborah/gamemode/lod/'+source],cwd=repo)
    assert (repo/'tools/fixtures'/fixture).read_bytes() == (root/('hud-parent-'+source)).read_bytes() == original
native = json.loads((root/'hud-native-verification.json').read_text())
assert native['parent_sha'] == parent and native['source_modules_verified'] == 42
assert native['server_status'] == 'received' and native['client_server_end_lua_errors'] == 0
paired = (root/'hud-targeted-paired.log').read_text()
assert 'HUD_TEXT_WORK_PASS traces=201' in paired and 'measurements=46200->0' in paired
changed = subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
changed += subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
for path in sorted(set(changed)):
    target = out/'changed-source'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((repo/path).read_bytes())
verification = {k:receipt[k] for k in ('total','passed','lua_files','source_before','source_after','changed_during_gate')}
verification.update(parent_sha=parent,canonical_commands_verified=True,individual_receipts_verified=311,
                    raw_stream_hashes_verified=622,frozen_source_hashes_verified=len(manifest),
                    native_gmod_accepted=False,native_fps_gate_passed=False,
                    paired_result=paired.splitlines()[-1],render_fingerprint_sources=10,
                    population_fingerprint_sources=44,native_parent_evidence=native,
                    parent_fixtures_exact=True,
                    production_sha256={p:h for p,h in manifest.items() if p.startswith(('gamemodes/','lua/')) and p.endswith('.lua')})
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
archive = repo/'docs/validation/STEAM_DECK_20261006_HUD_TEXT_complete.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.rglob('*')):
        if p.is_file(): z.write(p,'matrix/'+str(p.relative_to(out)))
    for p in sorted(root.glob('hud-targeted-*.log')): z.write(p,'targeted/'+p.name)
    for p in sorted(root.glob('hud-paired-attempt*.log')): z.write(p,'paired/'+p.name)
    for p in [root/'hud-native-verification.json',root/'hud-parent-cl_ui_theme.lua',
              root/'hud-parent-cl_combat_roll_feed_semantics.lua',root/'hud-complete-matrix-final.log',
              root/'hud-complete-matrix.log',root/'hud-interrupted-gate.json',root/'finalize_hud_evidence.py']:
        z.write(p,'evidence/'+p.name)
    for p in sorted((root/'hud-complete-matrix').rglob('*')):
        if p.is_file(): z.write(p,'interrupted-gate/'+str(p.relative_to(root/'hud-complete-matrix')))
    for name in ['performance_client_latest(9).txt','console_latest(20261006-223050).txt',
                 'performance_client_latest(8).txt','console_latest(20261006-212455).txt']:
        z.write(root/'upload'/name,'native/'+name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    verification['archive_entries'] = len(z.infolist())
verification['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
verification['archive_bytes'] = archive.stat().st_size
(repo/'docs/validation/STEAM_DECK_20261006_HUD_TEXT_matrix.json').write_text(json.dumps(verification,indent=2)+'\n')
(root/'hud-final-proof.json').write_text(json.dumps(verification,indent=2)+'\n')
print(json.dumps({k:v for k,v in verification.items() if k not in ('production_sha256','native_parent_evidence')},indent=2))
