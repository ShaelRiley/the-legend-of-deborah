import subprocess, json, hashlib, pathlib, sys, time, importlib.util, re

root = pathlib.Path.cwd()
out = root.parent / 'favored_enemy_gate'
out.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('matrix', root/'tools/test_checkpoint_g_integration.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
chosen = ['test_identity_enemy_pool.lua', 'test_identity_perks_weakness.lua',
          'test_checkpoint_c_headless.lua', 'test_manual_document.py',
          'test_instruction_manual.lua', 'test_manual_transport.lua', 'test_population_transport.lua']
selected = [(n,c) for n,c in m.SUITES if '--syntax' not in c and any('tools/'+s in c for s in chosen)]
assert len(selected) == 7
before = m.source_snapshot()
(out/'source_manifest.json').write_text(json.dumps(before, sort_keys=True, indent=2)+'\n')
parent = subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
parent_module = 'gamemodes/legend_of_deborah/gamemode/lod/sv_identity_perks.lua'
(out/'published_parent_identity.lua').write_bytes(subprocess.check_output(['git','show',parent+':'+parent_module]))
changed = subprocess.check_output(['git','diff','--name-only']).decode().splitlines()
lua = sorted(set(p for p in changed+['tools/test_identity_enemy_pool.lua'] if p.endswith('.lua')))
installer = (root/'tools/install_dev.sh').read_text()
watched = (root/'lua/autorun/server/lod_population_observability.lua').read_text()
installed = re.findall(r'(?:gamemodes|lua)/[^\s\\]+\.lua', installer[installer.index('sha256sum'):installer.index(') > "$POPULATION_MANIFEST.tmp"')])
observed = re.findall(r'"([^"]+)"', re.search(r'local watched=\{(.*?)\n\}', watched, re.S).group(1))
assert len(installed)==58 and len(observed)==54 and set(observed)<=set(installed)
assert parent_module in installed and parent_module in observed
rows=[]
checks = [('Published-parent rejection', ['python3','tools/run_lua54.py','tools/test_identity_enemy_pool.lua',str(out/'published_parent_identity.lua')],1)]
checks += [(n,c,0) for n,c in selected]
checks += [('Changed Lua parse',['python3','tools/run_lua54.py','--syntax',*lua],0),
           ('Installer shell syntax',['bash','-n','tools/install_dev.sh'],0),
           ('Patch whitespace',['git','diff','--check'],0)]
for i,(name,cmd,expected) in enumerate(checks,1):
    started = time.monotonic()
    r = subprocess.run(cmd,capture_output=True,timeout=60)
    stem = f'{i:02}'
    (out/(stem+'.stdout.txt')).write_bytes(r.stdout)
    (out/(stem+'.stderr.txt')).write_bytes(r.stderr)
    passed = r.returncode==expected
    if expected: passed = passed and b'recurring model family count drift' in r.stderr
    row=dict(name=name,command=cmd,returncode=r.returncode,expected_returncode=expected,passed=passed,
             seconds=round(time.monotonic()-started,3),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),
             stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),log_prefix=stem)
    rows.append(row)
    print(('PASS' if passed else 'FAIL')+' '+name,flush=True)
    if not passed: print((r.stdout+r.stderr).decode(errors='replace')[-2400:],flush=True)
after=m.source_snapshot()
report=dict(parent=parent,source_before=m.snapshot_digest(before),source_after=m.snapshot_digest(after),
            changed_during_gate=[k for k in before.keys()|after.keys() if before.get(k)!=after.get(k)],
            source_files=len(before),changed_lua=len(lua),installed_sources=len(installed),population_sources=len(observed),
            total=len(rows),passed=sum(r['passed'] for r in rows),results=rows,native_accepted=False)
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'reproduce.py').write_text(pathlib.Path(__file__).read_text())
print(json.dumps({k:v for k,v in report.items() if k!='results'}),flush=True)
sys.exit(0 if report['passed']==report['total'] and before==after else 1)
