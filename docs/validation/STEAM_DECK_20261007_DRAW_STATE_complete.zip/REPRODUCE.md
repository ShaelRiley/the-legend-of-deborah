# Exact-source headless evidence

Run from the published repository checkout. Extract this archive elsewhere.
Full frozen gate: `python3 tools/test_checkpoint_g_integration.py --workers 2 --suite-timeout 600 --output /absolute/new-evidence-directory`.
The receipt retains all 313 canonical commands; raw stream hashes and individual
receipts were independently checked. The original post-repair matrix was interrupted:
recovery verified its complete source manifest and reused only hash-verified
passing canonical receipts, then ran every remaining suite. recovery.json and
recovery_driver.py preserve the exact recovery procedure and counts. The source manifest is the exact pre/post
gate snapshot, before final documentation and evidence packaging.

For paired rendering, use the existing `tools/test_low_end_render.lua` with
`--state-probe <mesh-source> <entity-source> <signature-output>` via
`python3 tools/run_lua54.py`. Supply parent/cl_textured_box.lua and
parent/cl_static_box.lua for the exact parent; supply the repository's current
cl_textured_box.lua and lod_static_box/cl_init.lua for the candidate.
The floor work line must report 72000 and 600 native state calls respectively.
The signature outputs must match byte-for-byte. `--source` with the parent must
exit 1 at the new floor-work bound. Ordinary invocation executes the full
production validator, including empty/culled/nested state and resource cases.

Pre-repair retains the failing empty-pass implementation, its exact harness,
raw streams and hashes. The earlier full matrix was interrupted (exit 130)
before repair; its partial raw evidence is not a completed gate.
Native uploads belong to the exact parent, not this new candidate. CPU timing
is inclusive wall-clock diagnostic evidence; operation counts are not FPS or
GPU performance. No native acceptance is inferred from these source checks.
