"""Complete the exact frozen matrix after its original process was interrupted.

Reuse only canonical, hash-verified passing receipts under an unchanged full
source manifest. Preserve the original directory and run every remaining suite.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

REPO = Path('/workspace/scratch/2e9a79c1e21a/the-legend-of-deborah')
ORIGINAL = REPO.parent / 'draw-state-matrix-final'
OUTPUT = Path('/workspace/scratch/b6463ad6280a/draw-state-matrix-resumed')
spec = importlib.util.spec_from_file_location('frozen_gate', REPO / 'tools/test_checkpoint_g_integration.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
manifest = json.loads((ORIGINAL / 'source_manifest.json').read_text())
assert gate.source_snapshot() == manifest, 'Source changed after the interrupted gate'
assert not OUTPUT.exists(), 'Preserve prior recovery results; use a new directory'
OUTPUT.mkdir()
(OUTPUT / 'source_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
rows = []
completed = set()
for path in sorted(ORIGINAL.glob('*.json')):
    if path.name == 'source_manifest.json':
        continue
    row = json.loads(path.read_text())
    if not isinstance(row, dict) or 'index' not in row:
        continue
    index = row['index']
    assert index not in completed
    name, command = gate.SUITES[index - 1]
    assert row['name'] == name and row['command'] == command
    assert row['returncode'] == 0, 'Failed suites cannot be reused'
    for stream in ('stdout', 'stderr'):
        source = ORIGINAL / (row['log_prefix'] + '.' + stream + '.txt')
        assert hashlib.sha256(source.read_bytes()).hexdigest() == row[stream + '_sha256']
        shutil.copy2(source, OUTPUT / source.name)
    shutil.copy2(path, OUTPUT / path.name)
    completed.add(index)
    rows.append(row)
recovery = {
    'original_directory': str(ORIGINAL),
    'original_source_digest': gate.snapshot_digest(manifest),
    'source_unchanged_before_resumption': True,
    'reused_indices': sorted(completed),
    'remaining_indices': [i for i in range(1, len(gate.SUITES) + 1) if i not in completed],
    'original_receipts_and_stream_hashes_verified': True,
    'workers': 2,
    'suite_timeout': 600,
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(OUTPUT / 'recovery.json').write_text(json.dumps(recovery, indent=2) + '\n')
print(f'FROZEN MATRIX RECOVERY: {len(completed)} verified passing suites reused; {len(gate.SUITES)-len(completed)} remaining; {len(manifest)} unchanged source files', flush=True)

def run(entry):
    index, (name, command) = entry
    start = time.monotonic()
    try:
        result = subprocess.run(command, cwd=REPO, capture_output=True, timeout=600)
        code, stdout, stderr = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code, stdout = 124, error.stdout or b''
        stderr = (error.stderr or b'') + b'\nTIMEOUT: 600s\n'
    stem = f'{index:03d}-' + re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')
    row = dict(index=index, name=name, command=command, returncode=code,
               seconds=round(time.monotonic()-start, 3), log_prefix=stem,
               stdout_sha256=hashlib.sha256(stdout).hexdigest(),
               stderr_sha256=hashlib.sha256(stderr).hexdigest())
    (OUTPUT / (stem+'.stdout.txt')).write_bytes(stdout)
    (OUTPUT / (stem+'.stderr.txt')).write_bytes(stderr)
    (OUTPUT / (stem+'.json')).write_text(json.dumps(row, indent=2)+'\n')
    return row, stdout, stderr

pending = [(i, suite) for i, suite in enumerate(gate.SUITES, 1) if i not in completed]
with ThreadPoolExecutor(max_workers=2) as pool:
    futures = [pool.submit(run, entry) for entry in pending]
    for future in as_completed(futures):
        row, stdout, stderr = future.result()
        rows.append(row)
        print(f"[{'PASS' if row['returncode']==0 else 'FAIL'}] {len(rows)}/{len(gate.SUITES)} suite {row['index']}: {row['name']} ({row['seconds']}s)", flush=True)
        if row['returncode']:
            print((stdout+stderr).decode(errors='replace')[-6000:], flush=True)
after = gate.source_snapshot()
changed = sorted(name for name in manifest.keys() | after.keys() if manifest.get(name) != after.get(name))
assert sorted(row['index'] for row in rows) == list(range(1, len(gate.SUITES)+1))
report = dict(total=len(rows), passed=sum(row['returncode']==0 for row in rows),
              source_before=gate.snapshot_digest(manifest), source_after=gate.snapshot_digest(after),
              changed_during_gate=changed, lua_files=len(gate.LUA_FILES), native_gmod_accepted=False,
              results=sorted(rows, key=lambda row: row['index']),
              recovery={'reused_verified_suites': len(completed), 'fresh_suites': len(pending), 'manifest': 'recovery.json'})
(OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2)+'\n')
print(f"SYSTEMS_MATRIX {report['passed']}/{report['total']}; source_changed={len(changed)}; Lua syntax files={report['lua_files']}", flush=True)
sys.exit(0 if report['passed']==report['total'] and not changed else 1)
