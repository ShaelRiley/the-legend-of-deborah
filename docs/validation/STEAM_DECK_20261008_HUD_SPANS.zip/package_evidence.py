from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile,sys
repo=Path('/workspace/scratch/6473023bfe43/the-legend-of-deborah')
p=Path(__file__).resolve().parent
subprocess.run(['python3',str(p/'verify_evidence.py')],cwd=repo,check=True)
v=json.loads((p/'verification.json').read_text())
code=json.loads((p/'validated-code-manifest.json').read_text())
for name in list(code)+['tools/fixtures/hud_text_parent_ui.lua','tools/fixtures/hud_text_parent_semantics.lua','gamemodes/legend_of_deborah/gamemode/lod/sh_die_logger.lua']:
    dst=p/'candidate'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/name,dst)
for name in ['performance_client_latest(20261008-005119).txt','console_latest(20261008-005119).txt']:
    dst=p/'native'/name;dst.parent.mkdir(exist_ok=True);shutil.copy2(repo.parent/'upload'/name,dst)
checks='The frozen candidate passes **20/20 focused checks, 313/313 canonical suites and 884 Lua syntax files**. All 2,556 source files remain unchanged during both gates. Every canonical command, individual receipt and all 626 matrix stream hashes are independently checked. Only documentation/evidence packaging follows; production/test hashes are rechecked before publication. The adjacent checks JSON and ZIP preserve raw native uploads, parent/candidate sources and traces, the expected failing parent work gate, complete/focused commands, receipts, raw outputs and source manifests.\n'
report=(p/'report-draft.md').read_text().replace('VALIDATION_RESULTS',checks)
(repo/'docs/validation/STEAM_DECK_20261008_HUD_SPANS.md').write_text(report)
plan=repo/'docs/DEVELOPMENT_PLAN.md';s=plan.read_text();s=s.replace('Color allocations 4,200→0 and coordinate rounding 84,000→0. The exact parent\nfails the new work bound. Verify position/palette/metric mutation and release\nof retired layouts; run the focused presentation gates, Lua syntax and complete\nfrozen canonical matrix. Headless work counts do not establish FPS savings.','Color allocations 4,200→0 and coordinate rounding 84,000→0. The exact parent\nfails the new work bound; all 313 drawing scenarios match. Position/palette/metric\nmutation and release of retired layouts are verified. The frozen source passes\n20/20 focused checks, 313/313 canonical suites and 884 Lua parses. All 2,556\nsource files remain unchanged during the gates; all commands, receipts and 626\nmatrix stream hashes are independently checked. Documentation/evidence alone\nfollows, with production/test hashes rechecked before publication. Headless\nwork counts do not establish FPS savings. See [finite gate and native evidence](validation/STEAM_DECK_20261008_HUD_SPANS.md).')
plan.write_text(s)
archive=repo/'docs/validation/STEAM_DECK_20261008_HUD_SPANS.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(p.rglob('*')):
        if f.is_file() and '__pycache__' not in f.parts:
            z.write(f,f.relative_to(p))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    members=len(z.namelist())
    for name,sha in code.items():
        assert hashlib.sha256(z.read('candidate/'+name)).hexdigest()==sha
assert all(hashlib.sha256((repo/f).read_bytes()).hexdigest()==sha for f,sha in code.items())
summary={'version':'steam-deck-hud-spans-20261008','parent_head':'8bac44ab36922d3d169f613cd3b6d1fd739be4de','gdd_document':'1OSpgiWyiGmUCLFdq--WmCSZe6KQIr7_UTkQZklPV8lY','gdd_revision':'AHj4eMRd4acJKKEDgqukO9zGvoMQvxlbUMdF6nZCAXYFhQm-CNvzGIub5PLIO_oXk6fEWbrk_V-_2bJc4m1wqQvkXjzdDNhY5wQfHSd7Pg','verification':v,'code_sha256':code,'paired':{'scenarios':313,'trace_sha256':v['trace_sha256'],'steady_frames':600,'native_draws':[42000,42000],'native_measurements':[0,0],'font_selections':[4200,600],'colors':[4200,0],'ceilings':[84000,0],'parent_work_gate_passed':False},'native_capture':{'installed':'8bac44ab36922d3d169f613cd3b6d1fd739be4de','active_fps':22.30492911801739,'median_ms':38.212,'p95_ms':82.537,'p99_ms':120.064,'native_walls':1556,'new_build_native_accepted':False,'sustained_40_fps_accepted':False},'archive':{'filename':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members}}
(repo/'docs/validation/STEAM_DECK_20261008_HUD_SPANS_CHECKS.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive'],indent=2))
