from pathlib import Path
import hashlib,json,sys
repo=Path('/workspace/scratch/6473023bfe43/the-legend-of-deborah')
p=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'tools'))
import test_checkpoint_g_integration as g
manifest=json.loads((p/'matrix/source_manifest.json').read_text())
receipt=json.loads((p/'matrix/receipt.json').read_text())
assert receipt['passed']==receipt['total']==len(g.SUITES)==313
assert not receipt['changed_during_gate']
assert receipt['source_before']==receipt['source_after']==g.snapshot_digest(manifest)
assert g.source_snapshot()==manifest
for r,expected in zip(receipt['results'],g.SUITES):
    assert (r['name'],r['command'])==expected
    assert r['returncode']==0
    assert json.loads((p/'matrix'/(r['log_prefix']+'.json')).read_text())==r
    for channel in ('stdout','stderr'):
        assert hashlib.sha256((p/'matrix'/(r['log_prefix']+'.'+channel+'.txt')).read_bytes()).hexdigest()==r[channel+'_sha256']
focus=json.loads((p/'focused/receipt.json').read_text())
assert focus['passed']==focus['total']==20 and not focus['changed_during_gate']
assert focus['source_before']==focus['source_after']==receipt['source_before']
for r in focus['results']:
    assert json.loads((p/'focused'/(r['name']+'.json')).read_text())==r
    assert hashlib.sha256((p/'focused'/r['log']).read_bytes()).hexdigest()==r['log_sha256']
code=json.loads((p/'validated-code-manifest.json').read_text())
assert all(hashlib.sha256((repo/f).read_bytes()).hexdigest()==sha for f,sha in code.items())
paired=json.loads((p/'paired-receipt.json').read_text())
assert paired['parent']['trace_sha256']==paired['candidate']['trace_sha256']
for label in ('parent','candidate'):
    assert paired[label]['returncode']==0
    assert hashlib.sha256((p/(label+'-trace.txt')).read_bytes()).hexdigest()==paired[label]['trace_sha256']
assert paired['negative']['returncode']!=0
assert 'steady native font work retained' in paired['negative']['stderr']
result={'passed':True,'canonical_suites':313,'canonical_commands_checked':313,
    'matrix_raw_stream_hashes_checked':626,'matrix_individual_receipts_checked':313,
    'frozen_files':len(manifest),'source_digest':receipt['source_before'],
    'focused_checks':20,'focused_log_hashes_checked':20,'lua_syntax_files':focus['lua_files'],
    'code_files_checked':len(code),'trace_sha256':paired['candidate']['trace_sha256'],
    'native_fps_certified':False}
(p/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
