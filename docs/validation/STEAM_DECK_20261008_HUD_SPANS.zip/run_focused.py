import sys
from pathlib import Path
sys.path.insert(0,str(Path('/workspace/scratch/6473023bfe43/the-legend-of-deborah/tools')))
import test_spot10_gate as gate
gate.LABEL='HUD_SPAN_WORK_GATE'
gate.SCOPE='Shared native HUD and feed parity, metrics, presentation and lifecycle regressions; native FPS pending'
gate.LUA=['test_hud_text_work.lua','test_feedback_language.lua','validate_spot05_die_logger.lua','test_minigame_ui.lua','test_spot13_unread.lua','test_instruction_manual.lua','test_ag011_repairs.lua','test_campaign_timeout.lua','test_deborah_finale_presentation.lua','test_soldier_character_sheet.lua','test_spot15_team_menu.lua','test_low_end_options.lua','test_player_options.lua','test_manual_transport.lua']
raise SystemExit(gate.main())
