import subprocess,pathlib,json,hashlib,time

r=pathlib.Path('/workspace/scratch/809c83fce64f/the-legend-of-deborah')
p=pathlib.Path(__file__).parent/'paired'
rows=[]
for label,mode,source in [
    ('parent','--probe',p/'sv_enemy_variance.lua'),
    ('candidate','--probe',r/'gamemodes/legend_of_deborah/gamemode/lod/sv_enemy_variance.lua'),
    ('gate','--gate',r/'gamemodes/legend_of_deborah/gamemode/lod/sv_enemy_variance.lua'),
    ('negative','--gate',p/'sv_enemy_variance.lua')]:
    command=['python3','tools/run_lua54.py','tools/test_enemy_stride_work.lua',mode,str(source)]
    if mode=='--probe': command.append(str(p/(label+'.trace.txt')))
    start=time.monotonic()
    run=subprocess.run(command,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    (p/(label+'.stdout.txt')).write_bytes(run.stdout)
    (p/(label+'.stderr.txt')).write_bytes(run.stderr)
    rows.append(dict(label=label,command=command,returncode=run.returncode,
        seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(run.stdout).hexdigest(),
        stderr_sha256=hashlib.sha256(run.stderr).hexdigest()))
    print(label,run.returncode,run.stdout.decode().strip(),run.stderr.decode().strip(),flush=True)
    assert (run.returncode!=0)==(label=='negative')
a=(p/'parent.trace.txt').read_bytes();b=(p/'candidate.trace.txt').read_bytes()
assert a==b,'parent/candidate exact trace disagreement'
receipt=dict(rows=rows,trace_bytes=len(a),trace_sha256=hashlib.sha256(a).hexdigest())
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PAIRED_PARITY',receipt['trace_bytes'],receipt['trace_sha256'])
