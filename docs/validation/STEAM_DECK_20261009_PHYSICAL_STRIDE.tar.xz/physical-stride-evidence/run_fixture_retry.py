import pathlib,json,subprocess,time,hashlib
from concurrent.futures import ThreadPoolExecutor
repo=pathlib.Path('/workspace/scratch/809c83fce64f/the-legend-of-deborah')
work=pathlib.Path(__file__).parent
rows=[]
for p in sorted((work/'matrix-final').glob('*.json')):
    if p.name in ['source_manifest.json','receipt.json']:continue
    rows.append(json.loads(p.read_text()))
failed=[r for r in rows if r['returncode']]
assert len(failed)==7
(work/'failed-matrix.json').write_text(json.dumps({'reason':'Interrupted after two incomplete source-count fixtures caused these seven dependent failures; preserved before correcting fixtures','failed':failed,'completed':rows},indent=2)+'\n')
dest=work/'fixture-retry';dest.mkdir()
def run(row):
    start=time.monotonic();result=subprocess.run(row['command'],cwd=repo,capture_output=True,timeout=600)
    stem=row['log_prefix']
    record={**row,'returncode':result.returncode,'seconds':time.monotonic()-start,
        'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
    (dest/(stem+'.stdout.txt')).write_bytes(result.stdout)
    (dest/(stem+'.stderr.txt')).write_bytes(result.stderr)
    (dest/(stem+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print('FIXTURE_RETRY',row['index'],row['name'],result.returncode,flush=True)
    if result.returncode:print((result.stdout+result.stderr).decode()[-2500:],flush=True)
    return record
with ThreadPoolExecutor(max_workers=2) as pool:completed=list(pool.map(run,failed))
(dest/'receipt.json').write_text(json.dumps({'results':completed,'passed':sum(r['returncode']==0 for r in completed),'total':len(completed)},indent=2)+'\n')
assert all(r['returncode']==0 for r in completed)
