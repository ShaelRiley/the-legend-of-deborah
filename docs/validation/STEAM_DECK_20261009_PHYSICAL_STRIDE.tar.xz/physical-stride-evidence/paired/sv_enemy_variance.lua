LOD = LOD or {}
LOD.EnemyVariance = LOD.EnemyVariance or {}

local EnemyVariance = LOD.EnemyVariance
local EC = LOD.Config.Encounter
local V = EC.InstanceVariance

local DAMAGE_FIELDS = {
    "meleeDamage", "burstDamage", "blastDamage", "explosionDamage"
}
local TIMER_FIELDS = {
    "meleeCooldown", "burstCooldown", "burstTelegraph", "burstShotInterval",
    "leapCooldown", "blastInterval", "blastTelegraph"
}
local RANGE_FIELDS = {
    "meleeRange", "fireRange", "preferredRange", "leapRange", "latchDistance", "explosionRadius"
}

-- Every PHYSICAL FOOTSTEP, not every AI update, receives its own independent
-- +/-2.5% length roll. The current roll remains fixed for the duration of that
-- one footfall, then advances only after the hostile has travelled that step's
-- target distance. This creates cumulative phase drift between enemies that
-- would otherwise march in lockstep and bunch together.
local STRIDE_VARIANCE = 0.025
local BASE_STRIDE_DISTANCE = {
    shambler = 52,
    runner = 70,
    soldier = 60,
    blitzer = 60,
    deadcrab = 35,
    bioblaster = 36
}

local function subFloat(seed, label, minimum, maximum)
    local subSeed = LOD.Seeds.Derive(seed, label)
    return LOD.RNG.New(subSeed):Float(minimum, maximum)
end

local function jitter(seed, label, amount)
    amount = amount or 0
    return subFloat(seed, label, 1 - amount, 1 + amount)
end

local function stableSpawnIdentity(hostile)
    if hostile.LODEncounterOrdinal then return "ordinal:" .. tostring(hostile.LODEncounterOrdinal) end

    if hostile.LODEncounterId then
        local pos = hostile:GetPos()
        return string.format("pos:%d:%d:%d",
            math.floor(pos.x * 10 + 0.5),
            math.floor(pos.y * 10 + 0.5),
            math.floor(pos.z * 10 + 0.5))
    end

    return "debug:" .. tostring(hostile:EntIndex())
end

local function instanceSeed(hostile)
    if hostile.LODInstanceSeed then return hostile.LODInstanceSeed end

    local state = LOD.RunManager and LOD.RunManager.State
    local levelSeed = state and state.LevelSeed or 1
    local encounter = hostile.LODEncounterId or "debug"
    local identity = stableSpawnIdentity(hostile)
    local home = hostile.LODHomeCellKey or "none"
    local archetype = hostile.LODArchetypeId or "unknown"
    local label = string.format("enemy:%s:%s:%s:%s", tostring(encounter), identity, tostring(home), tostring(archetype))
    hostile.LODInstanceSeed = LOD.Seeds.Derive(levelSeed, label)
    return hostile.LODInstanceSeed
end

local function scaledValue(base, sizeFactor, randomFactor)
    return base * sizeFactor * randomFactor
end

local function rollNextFootstep(hostile)
    local rng = hostile.LODStrideRNG
    if not rng then return end
    local factor = rng:Float(1 - STRIDE_VARIANCE, 1 + STRIDE_VARIANCE)
    hostile.LODStrideFactor = factor
    hostile.LODStrideTargetDistance = math.max(4, (hostile.LODStrideBaseDistance or 52) * factor)
    hostile.LODStrideOrdinal = (hostile.LODStrideOrdinal or 0) + 1
end

function EnemyVariance:AdvanceFootstep(hostile)
    if not IsValid(hostile) or not hostile.LODStrideRNG then return end
    rollNextFootstep(hostile)
end

function EnemyVariance:Apply(hostile)
    if not V or not IsValid(hostile) or not hostile.LODHostile or not hostile.LODConfig then return end
    if hostile.LODVarianceApplied then return end
    hostile.LODVarianceApplied = true

    local seed = instanceSeed(hostile)
    local size = (hostile.LODBossDefinition or hostile.LODArchetypeId == "hector") and 1
        or subFloat(seed, "size", V.SizeMin or 0.33, V.SizeMax or 1.33)
    local originalConfig = hostile.LODConfig
    local cfg = table.Copy(originalConfig)
    hostile.LODConfig = cfg

    local damageScale = size
    local speedScale = math.pow(size, V.SpeedSizeExponent or -0.18)
    local timerScale = math.pow(size, V.TimerSizeExponent or 0.10)
    local rangeScale = math.pow(size, V.RangeSizeExponent or 0.55)

    -- IMPORTANT: visual size is intentionally NOT applied with server-side
    -- SetModelScale and this module never changes collision bounds. Runtime
    -- testing showed that mutating a live NextBot's model/collision scale can
    -- corrupt ground contact and produce half-buried or immobilized enemies.
    -- The size value is networked below and rendered client-side only. Movement
    -- hulls are owned exclusively by the grounding/locomotion layer; firearm
    -- combat volume is owned by sv_hostile_combat_hulls.lua.
    hostile:SetModelScale(1, 0)

    local currentMax = math.max(1, hostile:GetMaxHealth())
    local fixedBase = math.max(1, tonumber(originalConfig.baseHP) or currentMax)
    local campaignPartyScale = currentMax / fixedBase
    local healthContract = LOD.CombatRolls
        and LOD.CombatRolls:RollEnemyHealth(hostile.LODArchetypeId, seed)
    local resolvedBase = fixedBase
    if healthContract then
        -- Dice retain per-instance variation, but a narrow +/-6% band makes the
        -- much stronger visible-size multiplier the dependable durability cue.
        -- This replaces rather than stacks with the former +/-8% HP jitter.
        local rawFactor = healthContract.total / math.max(1, healthContract.expected)
        local boundedFactor = math.Clamp(rawFactor, 0.94, 1.06)
        resolvedBase = healthContract.expected * boundedFactor
        healthContract.resolvedBase = resolvedBase
        healthContract.boundedFactor = boundedFactor
    end
    local variedMax = math.max(1,
        math.floor(resolvedBase * size * campaignPartyScale + 0.5))
    local hpScale = variedMax / currentMax
    hostile:SetMaxHealth(variedMax)
    hostile:SetHealth(variedMax)
    if cfg.baseHP then cfg.baseHP = resolvedBase * size end

    if cfg.speed then
        cfg.speed = scaledValue(cfg.speed, speedScale, jitter(seed, "speed", V.SpeedJitter))
    end
    if cfg.leapSpeed then
        cfg.leapSpeed = scaledValue(cfg.leapSpeed, speedScale, jitter(seed, "leapSpeed", V.SpeedJitter))
    end

    for _, field in ipairs(DAMAGE_FIELDS) do
        if cfg[field] then
            cfg[field] = scaledValue(cfg[field], damageScale, jitter(seed, "damage:" .. field, V.DamageJitter))
        end
    end

    for _, field in ipairs(TIMER_FIELDS) do
        if cfg[field] then
            cfg[field] = math.max(0.03, scaledValue(cfg[field], timerScale, jitter(seed, "timer:" .. field, V.TimerJitter)))
        end
    end

    for _, field in ipairs(RANGE_FIELDS) do
        if cfg[field] then
            cfg[field] = math.max(1, scaledValue(cfg[field], rangeScale, jitter(seed, "range:" .. field, V.RangeJitter)))
        end
    end

    if cfg.projectileSpeed then
        cfg.projectileSpeed = math.max(120, cfg.projectileSpeed * jitter(seed, "projectileSpeed", V.ProjectileSpeedJitter))
    end

    if hostile.loco and cfg.speed then
        hostile.loco:SetDesiredSpeed(cfg.speed)
        hostile.loco:SetAcceleration(math.max(500, cfg.speed * 5))
        hostile.loco:SetDeceleration(math.max(500, cfg.speed * 6))
    end

    hostile.LODStrideRNG = LOD.RNG.New(LOD.Seeds.Derive(seed, "micro-stride"))
    hostile.LODStrideBaseDistance = (BASE_STRIDE_DISTANCE[hostile.LODArchetypeId] or 52) * size
    hostile.LODStrideAccumDistance = 0
    hostile.LODStrideLastPos = hostile:GetPos()
    hostile.LODStrideOrdinal = 0
    rollNextFootstep(hostile)

    hostile.LODVariance = {
        seed = seed,
        size = size,
        hpScale = hpScale,
        speedScale = cfg.speed and originalConfig.speed and originalConfig.speed ~= 0
            and (cfg.speed / originalConfig.speed) or 1
    }
    local campaignLevel=LOD.RunManager and LOD.RunManager.State and LOD.RunManager.State.Level or 1
    local pressure=LOD.Damsels and LOD.Damsels:EndlessPressure(campaignLevel)
    if pressure then
        for _,field in ipairs({"burstCooldown","meleeCooldown"}) do
            if cfg[field] then cfg[field]=cfg[field]*pressure.recovery end
        end
    end
    hostile.LODHealthDice = healthContract
    hostile:SetNW2Float("LOD_SizeScale", size)
    hostile:SetNW2Int("LOD_InstanceSeed", seed)
    if healthContract and LOD.CombatRolls then
        LOD.CombatRolls:ReportEnemyHealth(hostile, healthContract, size,
            campaignPartyScale, variedMax)
    end
    local progression = LOD.CharacterProgressionSystem
    local runState = LOD.RunManager and LOD.RunManager.State
    if progression and progression.AttachMonsterProgression then
        progression:AttachMonsterProgression(hostile, seed, runState and runState.Level or 1)
    end
end

local function installHostilePatch()
    local stored = scripted_ents.GetStored("lod_hostile")
    local class = stored and stored.t
    if not class or class.LODEnemyVariancePatched then return false end
    class.LODEnemyVariancePatched = true

    local baseInitialize = class.Initialize
    function class:Initialize()
        baseInitialize(self)
        if not IsValid(self) or not self.LODConfig then return end
        EnemyVariance:Apply(self)
    end

    local baseBehaviourTick = class._BehaviourTick
    function class:_BehaviourTick()
        local cfg = self.LODConfig

        if cfg and cfg.speed and self.LODStrideFactor and not self.LODDead and self.LODActivated ~= false then
            local baseSpeed = cfg.speed
            cfg.speed = baseSpeed * self.LODStrideFactor
            local result = baseBehaviourTick(self)
            cfg.speed = baseSpeed
            return result
        end

        return baseBehaviourTick(self)
    end
    return true
end

installHostilePatch()
local DEFERRED_APPLY_TIMER = "LOD_EnemyVarianceDeferredApply"
EnemyVariance.PendingApply = EnemyVariance.PendingApply or setmetatable({}, {__mode = "k"})

local function applyPendingHostiles()
    local pending = EnemyVariance.PendingApply
    EnemyVariance.PendingApply = setmetatable({}, {__mode = "k"})
    for hostile in pairs(pending) do
        if IsValid(hostile) and hostile.LODHostile and not hostile.LODVarianceApplied then
            EnemyVariance:Apply(hostile)
        end
    end
end

hook.Add("OnEntityCreated", "LOD_EnemyVarianceInstallBeforeSpawn", function(ent)
    if not IsValid(ent) or ent:GetClass() ~= "lod_hostile" then return end
    installHostilePatch()

    -- The first hostile created after a Lua refresh can precede the stored-class
    -- Initialize wrapper by one lifecycle edge. Queue every creation into one
    -- shared next-tick fail-safe; the Apply guard makes this a no-op for normally
    -- initialized entities and avoids allocating one timer per hostile.
    EnemyVariance.PendingApply[ent] = true
    if not timer.Exists(DEFERRED_APPLY_TIMER) then
        timer.Create(DEFERRED_APPLY_TIMER, 0, 1, applyPendingHostiles)
    end
end)

hook.Add("Think", "LOD_EnemyVariancePhysicalFootsteps", function()
    for _, hostile in ipairs(LOD.HostileRegistry and LOD.HostileRegistry:List() or {}) do
        if IsValid(hostile) and hostile.LODStrideRNG then
            local pos = hostile:GetPos()
            local last = hostile.LODStrideLastPos
            hostile.LODStrideLastPos = pos

            local moving = not hostile.LODDead
                and hostile.LODActivated ~= false
                and hostile.LODDeadcrabState ~= "latched"
                and hostile:GetVelocity():Length2D() > 8

            if moving and last then
                local travelled = math.min(80, pos:Distance(last))
                hostile.LODStrideAccumDistance = (hostile.LODStrideAccumDistance or 0) + travelled
                local target = hostile.LODStrideTargetDistance or hostile.LODStrideBaseDistance or 52

                if hostile.LODStrideAccumDistance >= target then
                    hostile.LODStrideAccumDistance = math.max(0, hostile.LODStrideAccumDistance - target)
                    rollNextFootstep(hostile)
                end
            end
        end
    end
end)

local function mainDamage(cfg)
    if not cfg then return 0 end
    if cfg.blastDamage then return cfg.blastDamage end
    if cfg.explosionDamage then return cfg.explosionDamage end
    if cfg.burstDamage then return cfg.burstDamage end
    return cfg.meleeDamage or 0
end

local function mainTimer(cfg)
    if not cfg then return 0 end
    if cfg.blastInterval then return cfg.blastInterval end
    if cfg.leapCooldown then return cfg.leapCooldown end
    if cfg.burstCooldown then return cfg.burstCooldown end
    return cfg.meleeCooldown or 0
end

concommand.Add("lod_m3_variance", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if cv and not cv:GetBool() then return end
    if IsValid(ply) and not ply:IsAdmin() then return end

    local found = 0
    for _, hostile in ipairs(ents.FindByClass("lod_hostile")) do
        if IsValid(hostile) and hostile.LODVariance then
            found = found + 1
            local cfg = hostile.LODConfig
            local text = string.format(
                "#%d %-10s size=%.3f hp=%d speed=%.1f step#=%d stepFactor=%.3f stepDist=%.1f damage=%.1f timer=%.2f seed=%d",
                hostile:EntIndex(), tostring(hostile.LODArchetypeId), hostile.LODVariance.size,
                hostile:Health(), cfg.speed or 0, hostile.LODStrideOrdinal or 0,
                hostile.LODStrideFactor or 1, hostile.LODStrideTargetDistance or 0,
                mainDamage(cfg), mainTimer(cfg), hostile.LODVariance.seed
            )
            print("[LOD:VARIANCE] " .. text)
            if IsValid(ply) then ply:ChatPrint(text) end
        end
    end
    if found == 0 then
        print("[LOD:VARIANCE] no active varied hostiles")
        if IsValid(ply) then ply:ChatPrint("no active varied hostiles") end
    end
end)

concommand.Add("lod_dice_health_status", function(ply)
    local cv = GetConVar("lod_developer_mode")
    if cv and not cv:GetBool() then return end
    if IsValid(ply) and not ply:IsAdmin() then return end

    local active = {}
    local missing = 0
    for _, hostile in ipairs(LOD.HostileRegistry and LOD.HostileRegistry:List() or {}) do
        if IsValid(hostile) and not hostile.LODDead then
            active[#active + 1] = hostile
            if not hostile.LODHealthDice then missing = missing + 1 end
        end
    end

    -- "Clearly larger" is conservatively audited at a 0.20 scale gap. Dice
    -- banding may vary near-identical silhouettes, but must never invert an
    -- unmistakable same-archetype size difference.
    local clearPairs = 0
    local inversions = 0
    for firstIndex = 1, #active do
        local first = active[firstIndex]
        for secondIndex = firstIndex + 1, #active do
            local second = active[secondIndex]
            if first.LODArchetypeId == second.LODArchetypeId then
                local firstSize = first.LODVariance and first.LODVariance.size or 1
                local secondSize = second.LODVariance and second.LODVariance.size or 1
                if math.abs(firstSize - secondSize) >= 0.20 then
                    clearPairs = clearPairs + 1
                    local larger = firstSize > secondSize and first or second
                    local smaller = larger == first and second or first
                    if larger:GetMaxHealth() <= smaller:GetMaxHealth() then
                        inversions = inversions + 1
                    end
                end
            end
        end
    end

    local result = #active > 0 and missing == 0 and inversions == 0 and "PASS" or "FAIL"
    local line = string.format(
        "active=%d diceApplied=%d missing=%d legacyHPJitter=0 clearSizePairs=%d inversions=%d healthRolls=%d result=%s",
        #active, #active - missing, missing, clearPairs, inversions,
        LOD.CombatRolls and LOD.CombatRolls.Stats.healthRolls or 0, result)
    print("[LOD:DICE-HEALTH] " .. line)
    if IsValid(ply) then ply:ChatPrint(line) end
end)
