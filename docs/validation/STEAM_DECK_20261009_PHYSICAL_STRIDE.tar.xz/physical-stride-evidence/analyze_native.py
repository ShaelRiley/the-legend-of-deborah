import json, pathlib, re, hashlib

root=pathlib.Path('/workspace/scratch/809c83fce64f')
out=pathlib.Path(__file__).parent
current=root/'upload/performance_client_latest(20261009-002559).txt'
console=root/'upload/console_latest(20261009-002559).txt'
previous=root/'playtest/performance_client_latest(20261008-164937).txt'
def read(p):
    s=p.read_text();return json.loads(s[s.index('{'):])
def summarize(d):
    return dict(active=d['active'],install=d['start_resources']['install'],
        client_source=d['source'],population_source=d['population']['source'],
        world={k:d['population'].get(k) for k in ['seed','layoutSeed','campaign','aliveBodies','aliveWanderers','plannedBodies']},
        walls=d['start_resources']['wall_models'],configuration=d['start_configuration'],
        configuration_changes=d['configuration_changes'],reason=d['reason'],
        requested_seconds=d['requested_seconds'],total_seconds=d['total_seconds'],
        profile={side:{k:d['cpu_profile'][side].get(k) for k in ['reason','seconds','timing','coverage']} for side in ['client','server']},
        rows={side:[row for row in d['cpu_profile'][side]['rows'] if row['name'] in [
            'hook/Think/LOD_EnemyVariancePhysicalFootsteps','service/EntrySafety.BeforeAI',
            'service/EnemyRoster.TickCloseDefense','hook/PostDrawOpaqueRenderables/LOD.DrawGeneratedStaticGeometry',
            'phase/PreRender-to-PostRender']] for side in ['client','server']},
        resources={stage:d[stage+'_resources'] for stage in ['start','end']})
d=read(current)
assert d['reason']=='complete' and not d['configuration_changes']
assert d['source']==dict(verified=True,checked=15,mismatches=0,missing=0)
for stage in ['start','end']:
    r=d[stage+'_resources']
    assert r['install'].strip()=='0fe2df6ac8fcbecaf9fea712d6d43fdf83ad4508 clean'
    assert r['lua_errors']==0 and r['vr']['idle'] and r['vr']['source']['verified']
for side in ['client','server']:
    assert d['cpu_profile'][side]['seconds']>179
assert d['cpu_profile']['client']['reason']=='complete'
assert d['cpu_profile']['server']['reason']=='client-stop' and d['cpu_profile']['server_status']=='received'
assert d['population']['source']['verified'] and d['population']['source']['checked']==46
assert d['population']['source']['missing']==0 and d['population']['source']['mismatches']==0
for p in [current,console]:
    hits=re.findall(r'(?i)password|passwd|gslt|login_token|BEGIN [^-]*PRIVATE KEY|Authorization:|Bearer\s+\S+',p.read_text())
    assert not hits, 'credential markers require review before preserving raw evidence'
summary=dict(current=summarize(d),previous=summarize(read(previous)),
    inputs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [current,console,previous]])
(out/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary['current'][k] for k in ['active','walls','world','population_source','profile','rows']},indent=2))
