import hashlib, importlib.util, json, pathlib, shutil, subprocess, tarfile, re

repo=pathlib.Path('/workspace/scratch/809c83fce64f/the-legend-of-deborah')
work=pathlib.Path(__file__).parent
parent='0fe2df6ac8fcbecaf9fea712d6d43fdf83ad4508'
paths=[
    'gamemodes/legend_of_deborah/gamemode/lod/sv_enemy_variance.lua',
    'lua/autorun/server/lod_population_observability.lua',
    'tools/install_dev.sh','tools/test_enemy_stride_work.lua',
    'tools/test_checkpoint_g_integration.py','tools/test_bestiary_b28.lua',
    'tools/test_population_transport.lua','tools/test_dev_population_manifest.py']
prefix='docs/validation/STEAM_DECK_20261009_PHYSICAL_STRIDE'
def digest(data):return hashlib.sha256(data).hexdigest()
def write_json(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('matrix_gate',repo/'tools/test_checkpoint_g_integration.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
receipt=json.loads((work/'matrix-verified/receipt.json').read_text())
manifest=json.loads((work/'matrix-verified/source_manifest.json').read_text())
assert receipt['passed']==receipt['total']==len(gate.SUITES)==316
assert receipt['lua_files']==len(gate.LUA_FILES)==886
assert not receipt['changed_during_gate'] and receipt['source_before']==receipt['source_after']
assert gate.snapshot_digest(manifest)==receipt['source_before']
assert gate.source_snapshot()==manifest,'source changed before evidence packaging'
for row,(name,command) in zip(receipt['results'],gate.SUITES):
    assert row['name']==name and row['command']==command and row['returncode']==0
    stem=row['log_prefix'];assert json.loads((work/'matrix-verified'/f'{stem}.json').read_text())==row
    for stream in ['stdout','stderr']:
        assert digest((work/'matrix-verified'/f'{stem}.{stream}.txt').read_bytes())==row[stream+'_sha256']
paired=json.loads((work/'paired/receipt.json').read_text())
trace=(work/'paired/parent.trace.txt').read_bytes()
assert trace==(work/'paired/candidate.trace.txt').read_bytes()
assert digest(trace)==paired['trace_sha256'] and len(trace)==paired['trace_bytes']
baseline=subprocess.check_output(['git','show',f'{parent}:{paths[0]}'],cwd=repo)
assert baseline==(work/'paired/sv_enemy_variance.lua').read_bytes()
for row in paired['rows']:
    label=row['label'];assert (row['returncode']!=0)==(label=='negative')
    for stream in ['stdout','stderr']:
        assert digest((work/'paired'/f'{label}.{stream}.txt').read_bytes())==row[stream+'_sha256']
assert 'unchanged native field work exceeds the footstep gate' in (work/'paired/negative.stderr.txt').read_text()
stats={}
for label in ['parent','candidate']:
    line=(work/'paired'/f'{label}.stdout.txt').read_text().splitlines()[0]
    stats[label]={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
for k in ['ticks','writes','positions','velocities','rolls','trace_lines','scenarios']:
    assert stats['parent'][k]==stats['candidate'][k]
assert stats['candidate']['crossings']<stats['parent']['crossings']
source_hashes={p:digest((repo/p).read_bytes()) for p in paths}
verification=dict(parent=parent,matrix_total=receipt['total'],lua_files=receipt['lua_files'],
    frozen_files=len(manifest),source_snapshot=receipt['source_before'],raw_matrix_streams=632,
    exact_trace_sha256=paired['trace_sha256'],exact_trace_bytes=len(trace),paired=stats,
    validated_source=source_hashes,native_gmod_accepted=False)
write_json(work/'verification.json',verification)
bundle=work/'bundle';bundle.mkdir()
for p in paths:
    dest=bundle/'validated-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,dest)
for directory in ['matrix-verified','matrix-final','matrix','paired','fixture-retry']:
    shutil.copytree(work/directory,bundle/directory)
for name in ['verification.json','interrupted-matrix.json','native-summary.json','gdd-scope.json',
    'failed-matrix.json','run_fixture_retry.py','run_paired.py','analyze_native.py','finalize_evidence.py','matrix.stdout.txt','matrix.stderr.txt',
    'matrix-final.stdout.txt','matrix-final.stderr.txt','matrix-verified.stdout.txt','matrix-verified.stderr.txt',
    'native-analysis.stdout.txt','native-analysis.stderr.txt']:
    shutil.copyfile(work/name,bundle/name)
native=bundle/'native';native.mkdir()
for path,name in [
    ('upload/performance_client_latest(20261009-002559).txt','current-performance.txt'),
    ('upload/console_latest(20261009-002559).txt','current-console.txt'),
    ('playtest/performance_client_latest(20261008-164937).txt','previous-performance.txt'),
    ('playtest/console_latest(20261008-164936).txt','previous-console.txt')]:
    shutil.copyfile(repo.parent/path,native/name)
shutil.copyfile(repo/'docs/DEVELOPMENT_PLAN.md',bundle/'frozen-development-plan.md')
patch=subprocess.check_output(['git','diff','--binary',parent,'--',*paths,'docs/DEVELOPMENT_PLAN.md'],cwd=repo)
(bundle/'validated-tracked.patch').write_bytes(patch)
report=(work/'report-draft.md').read_text()
report=report.replace('{{FROZEN_FILES}}',str(len(manifest))).replace('{{SNAPSHOT}}',receipt['source_before'])
(repo/(prefix+'.md')).write_text(report)
shutil.copyfile(repo/(prefix+'.md'),bundle/'report.md')
with tarfile.open(repo/(prefix+'.tar.xz'),'w:xz',preset=6) as archive:
    archive.add(bundle,arcname='physical-stride-evidence')
allowed={'docs/DEVELOPMENT_PLAN.md',prefix+'.md',prefix+'.tar.xz'}
after=gate.source_snapshot()
changed={p for p in manifest.keys()|after.keys() if manifest.get(p)!=after.get(p)}
assert changed<=allowed,changed
for p,h in source_hashes.items():assert digest((repo/p).read_bytes())==h
print(json.dumps(verification,indent=2))
print('EVIDENCE_ARCHIVE_BYTES',(repo/(prefix+'.tar.xz')).stat().st_size)
