MS2 core MIDI phrases, exported from the curated event catalog.
Nine named instrument tracks plus a tempo/meter conductor.
GM programs are DAW audition hints; LoD uses its own instruments.
Original source lineage and direction: docs/MS2_CATALOG.json / .md.
Rebuild the game bank from tools/music/sources; these exports are portable editing/audition copies.
