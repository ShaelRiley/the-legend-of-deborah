g_VR = g_VR or {}
vrmod = vrmod or {}
vrmod.utils = vrmod.utils or {}
local magCache = {}
local function IsMagazine(ent)
    if not IsValid(ent) then return false end
    if ent.ArcticVRMagazine or ent.MagID then return true end
    local class = ent:GetClass()
    if not class then return false end
    if magCache[class] ~= nil then return magCache[class] end
    local isMag = string.StartWith(class, "avrmag_")
    magCache[class] = isMag
    return isMag
end

vrmod.utils.IsMagazine = IsMagazine

--FILTERS AND TRACE UTILS
function vrmod.utils.HitFilter(ent, ply, hand)
    if not IsValid(ent) then return false end
    if ent == ply then return false end
    if ent:GetNWBool("isVRProxy", false) then return false end
    if IsMagazine(ent) then return false end
    -- Never hit active weapons (gun mesh vs hand hull)
    if ent:IsWeapon() then return false end
    if IsValid(ply) and (hand == "left" or hand == "right") then
        local held = vrmod.GetHeldEntity and vrmod.GetHeldEntity(ply, hand)
        if IsValid(held) and held == ent then return false end
        local other = hand == "left" and "right" or "left"
        local heldOther = vrmod.GetHeldEntity and vrmod.GetHeldEntity(ply, other)
        if IsValid(heldOther) and heldOther == ent then return false end
    end
    if CLIENT and g_VR then
        if ent == g_VR.heldEntityLeft or ent == g_VR.heldEntityRight then return false end
        if ent == g_VR.viewModel or ent == g_VR.worldModelVM then return false end
        -- Cabin: ignore seat vehicle and its children
        if g_VR.vehicle and (g_VR.vehicle.inside or g_VR.vehicle.driving) and IsValid(g_VR.vehicle.current) then
            local veh = g_VR.vehicle.current
            if ent == veh or ent:GetParent() == veh then return false end
        end
    end
    if IsValid(ply) and ply.InVehicle and ply:InVehicle() then
        local veh = ply:GetVehicle()
        if IsValid(veh) and (ent == veh or ent:GetParent() == veh) then return false end
    end
    return true
end

function vrmod.utils.MeleeFilter(ent, ply, hand)
    return vrmod.utils.HitFilter(ent, ply, hand) and not IsMagazine(ent)
end

--- Trace filter for hand/weapon *wall* collisions.
--- Return true = can hit. Ignores held mags/props so wall push doesn't fight the mag.
--- Cached per-frame — never rebuild closure for every TraceHull (latency spikes).
local wallFilterCachePly, wallFilterCacheFn, wallFilterCacheFrame

function vrmod.utils.WallCollisionFilter(ply)
    local frame = FrameNumber and FrameNumber() or 0
    if wallFilterCacheFn and wallFilterCachePly == ply and wallFilterCacheFrame == frame then
        return wallFilterCacheFn
    end

    -- Snapshot held ents once (HitFilter used to call GetHeldEntity 4x per candidate)
    local heldL, heldR, vm, wvm
    if CLIENT and g_VR then
        heldL, heldR = g_VR.heldEntityLeft, g_VR.heldEntityRight
        vm, wvm = g_VR.viewModel, g_VR.worldModelVM
    end
    if SERVER and IsValid(ply) and vrmod.GetHeldEntity then
        heldL = heldL or vrmod.GetHeldEntity(ply, "left")
        heldR = heldR or vrmod.GetHeldEntity(ply, "right")
    end

    local veh = nil
    if IsValid(ply) and ply.InVehicle and ply:InVehicle() then
        veh = ply:GetVehicle()
    end
    if CLIENT and g_VR and g_VR.vehicle and IsValid(g_VR.vehicle.current) then
        veh = veh or g_VR.vehicle.current
    end
    if not IsValid(veh) and IsValid(ply) and ply.GlideGetVehicle then
        local ok, gveh = pcall(function() return ply:GlideGetVehicle() end)
        if ok and IsValid(gveh) then veh = gveh end
    end
    local vehParent = IsValid(veh) and veh:GetParent() or nil

    local fn = function(ent)
        if not IsValid(ent) then return true end
        if ent == ply then return false end
        if ent == heldL or ent == heldR then return false end
        if ent == vm or ent == wvm then return false end
        if IsMagazine(ent) then return false end
        if ent:IsWeapon() then return false end
        if ent:GetNWBool("isVRProxy", false) then return false end
        if IsValid(veh) and (ent == veh or ent == vehParent) then return false end
        if IsValid(veh) and ent:GetParent() == veh then return false end
        -- Glide / seat parts often parented under a root other than GetVehicle()
        local c = ent:GetClass() or ""
        if c:find("prop_vehicle", 1, true) or c:find("glide", 1, true) then return false end
        return true
    end

    wallFilterCachePly, wallFilterCacheFn, wallFilterCacheFrame = ply, fn, frame
    return fn
end

function vrmod.utils.TraceHand(ply, hand, fromPalm)
    local startPos, ang, dir
    if hand == "left" then
        startPos = vrmod.GetLeftHandPos(ply)
        ang = vrmod.GetLeftHandAng(ply)
        if not ang then return nil end
        if fromPalm then
            dir = ang:Right() -- palm facing sideways
            startPos = startPos + ang:Up() * 2 + ang:Forward() * vrmod.DEFAULT_OFFSET -- offset upward from hand center
        else
            dir = Angle(ang.p, ang.y, ang.r + 180):Forward() -- original forward
        end
    else
        startPos = vrmod.GetRightHandPos(ply)
        ang = vrmod.GetRightHandAng(ply)
        if not ang then return nil end
        if fromPalm then
            dir = -ang:Right() -- palm facing sideways
            startPos = startPos + ang:Up() * 2 + ang:Forward() * vrmod.DEFAULT_OFFSET -- offset upward
        else
            dir = ang:Forward() -- normal forward
        end
    end

    if not startPos or not dir then return nil end
    dir:Normalize()
    local radius = fromPalm and 6 or 2 -- palm fatter, finger forward thinner
    local range = 32768
    local maxDepth = 10
    local ignore = {}
    local traceStart = startPos
    for i = 1, maxDepth do
        local tr = util.TraceHull({
            start = traceStart,
            endpos = traceStart + dir * range,
            mins = Vector(-radius, -radius, -radius),
            maxs = Vector(radius, radius, radius),
            filter = ignore,
            mask = MASK_SHOT_HULL
        })

        if not tr.Entity or not IsValid(tr.Entity) then return tr end
        if vrmod.utils.HitFilter(tr.Entity, ply, hand) then
            return tr
        else
            table.insert(ignore, tr.Entity)
            traceStart = tr.HitPos + dir * 1 -- nudge forward
        end
    end
    return nil
end

function vrmod.utils.TraceBoxOrSphere(data)
    local best = {
        Hit = false,
        Fraction = 1
    }

    if data.mins and data.maxs then
        -- Box trace
        local tr = util.TraceHull({
            start = data.start,
            endpos = data.endpos,
            mins = data.mins,
            maxs = data.maxs,
            filter = data.filter,
            mask = data.mask
        })

        if tr.Hit then
            best = tr
            best.Hit = true
        end
    else
        -- Sphere approximation with single hull trace
        local radius = data.radius or vrmod.DEFAULT_RADIUS
        local tr = util.TraceHull({
            start = data.start,
            endpos = data.endpos,
            mins = Vector(-radius, -radius, -radius),
            maxs = Vector(radius, radius, radius),
            filter = data.filter,
            mask = data.mask
        })

        if tr.Hit then
            best = tr
            best.Hit = true
        end
    end
    return best
end