g_VR = g_VR or {}
g_VR.viewModelInfo = g_VR.viewModelInfo or {}
if CLIENT then
	local CONFIG_PATH = "vrmod/vrmod_weapons_config.json"
	-- Default hardcoded offsets and overrides
	local DEFAULT_VIEWMODEL_INFO = {
		autoOffsetAddPos = Vector(1, 0.2, 0),
		gmod_tool = {
			offsetPos = Vector(-12, 6.5, 7),
			offsetAng = Angle(0, 0, 0),
		},
		weapon_physgun = {
			offsetPos = Vector(-31.5, 13.4, 14.5),
			offsetAng = Angle(0, 0, 0),
			noLaser = true

		},
		weapon_physcannon = {
			offsetPos = Vector(-31.5, 13.4, 10.5),
			offsetAng = Angle(0, 0, 0),
			noLaser = true
		},
		weapon_shotgun = {
			offsetPos = Vector(-14.5, 10, 8.5),
			offsetAng = Angle(0, 0, 0),
		},
		weapon_rpg = {
			offsetPos = Vector(-27.5, 19, 10.5),
			offsetAng = Angle(0, 0, 0),
			noLaser = true
		},
		arcticvr_hl2_rpg = {
			noLaser = true
		},
		weapon_crossbow = {
			offsetPos = Vector(-14.5, 10, 8.5),
			offsetAng = Angle(0, 0, 0),
		},
		weapon_medkit = {
			offsetPos = Vector(-23, 10, 5),
			offsetAng = Angle(0, 0, 0)
		},
		weapon_crowbar = {
			wrongMuzzleAng = true,
		},
		arcticvr_hl2_crowbar = {
			noLaser = true
		},
		weapon_stunstick = {
			offsetPos = Vector(3.35, 1.5, 2.5),
			offsetAng = Angle(0, -90, 0),
			wrongMuzzleAng = true
		},
		arcticvr_hl2_stunstick = {
			noLaser = true
		},
		arcticvr_hl2_knife = {
			noLaser = true
		},
		arcticvr_hl2_cmbsniper = {
			noLaser = true
		},
		laserpointer = {
			noLaser = true
		},
		seal6_c4 = {
			noLaser = true
		},
		seal6_bottle = {
			noLaser = true
		},
		seal6_doritos = {
			noLaser = true
		},
		weapon_bomb = {
			noLaser = true
		},
		weapon_c4 = {
			noLaser = true
		},
		weapon_vfire_gascan = {
			noLaser = true
		},
		weapon_extinguisher_infinte = {
			noLaser = true
		},
		weapon_extinguisher = {
			noLaser = true
		},
		weapon_slam = {
			wrongMuzzleAng = true,
		},
		weapon_microwaverifle = {
			offsetPos = Vector(-9, 6.5, 10),
			offsetAng = Angle(0, 0, 0)
		},
		weapon_vfirethrower = {
			offsetPos = Vector(13, 2, -6),
			offsetAng = Angle(0, 0, 0),
			wrongMuzzleAng = true,
		},
		weapon_newtphysgun = {
			offsetPos = Vector(-34.5, 13.4, 14.5),
			offsetAng = Angle(0, 0, 0),
			noLaser = true
		},
	}

	local function SerializeViewModelInfo(tbl)
		local out = {}
		for k, v in pairs(tbl or {}) do
			if k == "autoOffsetAddPos" and isvector(v) then
				out.autoOffsetAddPos = { v.x, v.y, v.z }
			elseif istable(v) then
				local e = {}
				if v.offsetPos then
					e.offsetPos = { v.offsetPos.x or v.offsetPos[1] or 0, v.offsetPos.y or v.offsetPos[2] or 0, v.offsetPos.z or v.offsetPos[3] or 0 }
				end
				if v.offsetAng then
					e.offsetAng = { v.offsetAng.p or v.offsetAng[1] or 0, v.offsetAng.y or v.offsetAng[2] or 0, v.offsetAng.r or v.offsetAng[3] or 0 }
				end
				if v.muzzleOffsetPos then
					e.muzzleOffsetPos = { v.muzzleOffsetPos.x or v.muzzleOffsetPos[1] or 0, v.muzzleOffsetPos.y or v.muzzleOffsetPos[2] or 0, v.muzzleOffsetPos.z or v.muzzleOffsetPos[3] or 0 }
				end
				if v.muzzleOffsetAng then
					e.muzzleOffsetAng = { v.muzzleOffsetAng.p or v.muzzleOffsetAng[1] or 0, v.muzzleOffsetAng.y or v.muzzleOffsetAng[2] or 0, v.muzzleOffsetAng.r or v.muzzleOffsetAng[3] or 0 }
				end
				if v.wrongMuzzleAng ~= nil then e.wrongMuzzleAng = v.wrongMuzzleAng and true or false end
				if v.noLaser ~= nil then e.noLaser = v.noLaser and true or false end
				if v.useWorldModel ~= nil then e.useWorldModel = v.useWorldModel and true or false end
				out[k] = e
			end
		end
		return out
	end

	local function SaveViewModelConfig()
		if not file.IsDir("vrmod", "DATA") then file.CreateDir("vrmod") end
		file.Write(CONFIG_PATH, util.TableToJSON(SerializeViewModelInfo(g_VR.viewModelInfo), true) or "{}")
	end

	--- Public API for Cube VR weapon settings menu
	function vrmod.SaveWeaponViewModelConfig()
		SaveViewModelConfig()
		return true
	end

	function vrmod.EnsureWeaponViewModelEntry(class)
		if not class or class == "" then return nil end
		g_VR.viewModelInfo = g_VR.viewModelInfo or {}
		if not g_VR.viewModelInfo[class] then
			g_VR.viewModelInfo[class] = {
				offsetPos = Vector(0, 0, 0),
				offsetAng = Angle(0, 0, 0),
				muzzleOffsetPos = Vector(0, 0, 0),
				muzzleOffsetAng = Angle(0, 0, 0),
				wrongMuzzleAng = false,
				noLaser = false,
				useWorldModel = false,
			}
		else
			local d = g_VR.viewModelInfo[class]
			if not d.offsetPos then d.offsetPos = Vector(0, 0, 0) end
			if not d.offsetAng then d.offsetAng = Angle(0, 0, 0) end
			if not d.muzzleOffsetPos then d.muzzleOffsetPos = Vector(0, 0, 0) end
			if not d.muzzleOffsetAng then d.muzzleOffsetAng = Angle(0, 0, 0) end
		end
		return g_VR.viewModelInfo[class]
	end

	function vrmod.GetWeaponViewModelEntry(class)
		if not class then return nil end
		return g_VR.viewModelInfo and g_VR.viewModelInfo[class]
	end

	function vrmod.ApplyWeaponViewModelLive(class)
		if not class or not g_VR then return end
		local d = g_VR.viewModelInfo and g_VR.viewModelInfo[class]
		if not d then return end
		local wep = LocalPlayer():GetActiveWeapon()
		if IsValid(wep) and wep:GetClass() == class then
			g_VR.currentvmi = d
			if vrmod.utils and vrmod.utils.UpdateViewModelPos then
				pcall(vrmod.utils.UpdateViewModelPos)
			elseif vrmod.utils and vrmod.utils.UpdateViewModel then
				pcall(vrmod.utils.UpdateViewModel)
			end
		end
	end

	-- Custom deep copy function to handle Vector and Angle
	local function DeepCopy(orig)
		if type(orig) == "table" then
			local copy = {}
			for k, v in pairs(orig) do
				copy[k] = DeepCopy(v)
			end
			return copy
		elseif type(orig) == "Vector" then
			return Vector(orig.x, orig.y, orig.z)
		elseif type(orig) == "Angle" then
			return Angle(orig.p, orig.y, orig.r)
		else
			return orig -- Return non-table, non-userdata values as-is
		end
	end

	local function LoadViewModelConfig()
		-- Initialize g_VR.viewModelInfo if empty
		if not next(g_VR.viewModelInfo) then
			g_VR.viewModelInfo = DeepCopy(DEFAULT_VIEWMODEL_INFO) -- Copy entire default table
		end

		-- Load saved config (if any)
		if file.Exists(CONFIG_PATH, "DATA") then
			local loaded = util.JSONToTable(file.Read(CONFIG_PATH, "DATA")) or {}
			for cls, loadedData in pairs(loaded) do
				-- Ensure the class exists in viewModelInfo, using defaults if not
				if not g_VR.viewModelInfo[cls] then g_VR.viewModelInfo[cls] = DeepCopy(DEFAULT_VIEWMODEL_INFO[cls] or {}) end
				-- Merge loaded data, only updating fields that exist
				if loadedData.offsetPos and type(loadedData.offsetPos) == "table" then g_VR.viewModelInfo[cls].offsetPos = Vector(loadedData.offsetPos[1] or 0, loadedData.offsetPos[2] or 0, loadedData.offsetPos[3] or 0) end
				if loadedData.offsetAng and type(loadedData.offsetAng) == "table" then g_VR.viewModelInfo[cls].offsetAng = Angle(loadedData.offsetAng[1] or 0, loadedData.offsetAng[2] or 0, loadedData.offsetAng[3] or 0) end
				if loadedData.muzzleOffsetPos and type(loadedData.muzzleOffsetPos) == "table" then g_VR.viewModelInfo[cls].muzzleOffsetPos = Vector(loadedData.muzzleOffsetPos[1] or 0, loadedData.muzzleOffsetPos[2] or 0, loadedData.muzzleOffsetPos[3] or 0) end
				if loadedData.muzzleOffsetAng and type(loadedData.muzzleOffsetAng) == "table" then g_VR.viewModelInfo[cls].muzzleOffsetAng = Angle(loadedData.muzzleOffsetAng[1] or 0, loadedData.muzzleOffsetAng[2] or 0, loadedData.muzzleOffsetAng[3] or 0) end
				if loadedData.wrongMuzzleAng ~= nil then g_VR.viewModelInfo[cls].wrongMuzzleAng = loadedData.wrongMuzzleAng end
				if loadedData.noLaser ~= nil then g_VR.viewModelInfo[cls].noLaser = loadedData.noLaser end
				if loadedData.useWorldModel ~= nil then g_VR.viewModelInfo[cls].useWorldModel = loadedData.useWorldModel end
			end

			-- Handle autoOffsetAddPos separately if present in loaded config
			if loaded.autoOffsetAddPos and type(loaded.autoOffsetAddPos) == "table" then g_VR.viewModelInfo.autoOffsetAddPos = Vector(loaded.autoOffsetAddPos[1] or 0, loaded.autoOffsetAddPos[2] or 0, loaded.autoOffsetAddPos[3] or 0) end
		end

		SaveViewModelConfig()
	end

	-- Initialize on VR start
	hook.Add("VRMod_Start", "InitializeViewModelSettings", function() LoadViewModelConfig() end)
	LoadViewModelConfig()
	function CreateWeaponConfigGUI()
		RunConsoleCommand("vrmod_vgui_reset")
		local frame = vgui.Create("DFrame")
		frame:SetSize(800, 400)
		frame:Center()
		frame:SetTitle("Weapon ViewModel Configuration")
		frame:MakePopup()
		frame.OnClose = function() SaveViewModelConfig() end
		local listview = vgui.Create("DListView", frame)
		listview:Dock(FILL)
		listview:AddColumn("Weapon Class")
		listview:AddColumn("Offset Position")
		listview:AddColumn("Offset Angle")
		listview:AddColumn("Wrong Muzzle Ang")
		listview:AddColumn("No Laser")
		listview:AddColumn("Use World Model")
		local function UpdateListView()
			if not g_VR.viewModelInfo then return end
			listview:Clear()
			for class, data in pairs(g_VR.viewModelInfo) do
				listview:AddLine(class, tostring(data.offsetPos), tostring(data.offsetAng), tostring(data.wrongMuzzleAng or false), tostring(data.noLaser or false), tostring(data.useWorldModel or false))
				-- Make sure column 6 is filled
			end
		end

		UpdateListView()
		local bottomPanel = vgui.Create("DPanel", frame)
		bottomPanel:Dock(BOTTOM)
		bottomPanel:SetTall(150)
		local leftPanel = vgui.Create("DPanel", bottomPanel)
		leftPanel:SetWide(frame:GetWide() / 2 - 15)
		leftPanel:Dock(LEFT)
		leftPanel:DockMargin(10, 5, 5, 5)
		local rightPanel = vgui.Create("DPanel", bottomPanel)
		rightPanel:SetWide(frame:GetWide() / 2 - 15)
		rightPanel:Dock(RIGHT)
		rightPanel:DockMargin(5, 5, 10, 5)
		-- Fixed AddButton: always dock TOP and stack properly
		local function AddButton(parent, txt, func)
			local btn = vgui.Create("DButton", parent)
			btn:SetText(txt)
			btn:Dock(TOP)
			btn:SetHeight(30)
			btn:DockMargin(5, 5, 5, 0)
			btn.DoClick = func
			return btn
		end

		local function UpdateListLine(class)
			local lines = listview:GetLines()
			for i, line in ipairs(lines) do
				if line:GetValue(1) == class then
					local data = g_VR.viewModelInfo[class]
					if data then
						line:SetColumnText(2, tostring(data.offsetPos))
						line:SetColumnText(3, tostring(data.offsetAng))
						line:SetColumnText(4, tostring(data.wrongMuzzleAng or false))
						line:SetColumnText(5, tostring(data.noLaser or false))
						line:SetColumnText(6, tostring(data.useWorldModel or false))
					end

					break
				end
			end
		end

		-- Left panel buttons
		AddButton(leftPanel, "Add new", function()
			local wep = LocalPlayer():GetActiveWeapon()
			if IsValid(wep) then
				local class = wep:GetClass()
				g_VR.viewModelInfo[class] = g_VR.viewModelInfo[class] or {
					offsetPos = Vector(),
					offsetAng = Angle()
				}

				UpdateListLine(class)
			end
		end)

		AddButton(leftPanel, "Disable Laser", function()
			local wep = LocalPlayer():GetActiveWeapon()
			if not IsValid(wep) then return end
			local class = wep:GetClass()
			local data = g_VR.viewModelInfo[class]
			if not data then return end
			data.noLaser = not data.noLaser
			vrmod.SetViewModelNoLaser(class, data.noLaser)
			UpdateListLine(class)
		end)

		AddButton(leftPanel, "Fix muzzle", function()
			local wep = LocalPlayer():GetActiveWeapon()
			if not IsValid(wep) then return end
			local class = wep:GetClass()
			local data = g_VR.viewModelInfo[class]
			if not data then return end
			data.wrongMuzzleAng = not data.wrongMuzzleAng
			vrmod.SetViewModelFixMuzzle(class, data.wrongMuzzleAng)
			UpdateListLine(class)
		end)

		AddButton(leftPanel, "Use World Model", function()
			local wep = LocalPlayer():GetActiveWeapon()
			if not IsValid(wep) then return end
			local class = wep:GetClass()
			local data = g_VR.viewModelInfo[class]
			if not data then return end
			data.useWorldModel = not data.useWorldModel
			vrmod.SetViewModelUseWorldModel(class, data.useWorldModel)
			UpdateListLine(class)
		end)

		-- Right panel buttons
		AddButton(rightPanel, "Reset Config", function()
			local confirm = vgui.Create("DFrame")
			confirm:SetSize(350, 200)
			confirm:Center()
			confirm:SetTitle("Confirm Reset")
			confirm:MakePopup()
			local msg = [[This will permanently delete your saved weapon viewmodel configuration file,
and reset everything to the default values.

You might need to reload the map afterwards in case you use VR specific weapons. 

Are you sure you want to continue?]]
			local lbl = vgui.Create("DLabel", confirm)
			lbl:SetText(msg)
			lbl:SetFont("DermaDefault")
			lbl:SetContentAlignment(7)
			lbl:SetWrap(true)
			lbl:SetAutoStretchVertical(true)
			lbl:Dock(TOP)
			lbl:DockMargin(10, 10, 10, 0)
			local btnPanel = vgui.Create("DPanel", confirm)
			btnPanel:Dock(BOTTOM)
			btnPanel:SetTall(40)
			local function DoReset()
				if file.Exists(CONFIG_PATH, "DATA") then file.Delete(CONFIG_PATH) end
				table.Empty(g_VR.viewModelInfo)
				for cls, data in pairs(DEFAULT_VIEWMODEL_INFO) do
					g_VR.viewModelInfo[cls] = data
				end

				SaveViewModelConfig()
				UpdateListView()
				confirm:Close()
			end

			local yesBtn = vgui.Create("DButton", btnPanel)
			yesBtn:SetText("Yes")
			yesBtn:Dock(LEFT)
			yesBtn:DockMargin(20, 5, 10, 5)
			yesBtn.DoClick = DoReset
			local noBtn = vgui.Create("DButton", btnPanel)
			noBtn:SetText("Cancel")
			noBtn:Dock(RIGHT)
			noBtn:DockMargin(10, 5, 20, 5)
			noBtn.DoClick = function() confirm:Close() end
		end)

		AddButton(rightPanel, "Delete", function()
			local selected = listview:GetSelectedLine()
			if selected then
				local class = listview:GetLine(selected):GetValue(1)
				g_VR.viewModelInfo[class] = nil
				UpdateListView()
			end
		end)

		AddButton(rightPanel, "Edit offset", function()
			local selected = listview:GetSelectedLine()
			if selected then
				local class = listview:GetLine(selected):GetValue(1)
				CreateAddWeaponConfigGUI(class, true)
				frame:Close()
			end
		end)
	end

	function CreateAddWeaponConfigGUI(class, isEditing)
		local frame = vgui.Create("DFrame")
		frame:SetSize(300, 520)
		frame:Center()
		frame:SetTitle(isEditing and "Edit ViewModel Config" or "Add ViewModel Config")
		frame:MakePopup()
		local data = g_VR.viewModelInfo[class] or {
			offsetPos = Vector(),
			offsetAng = Angle(),
			muzzleOffsetPos = Vector(),
			muzzleOffsetAng = Angle(),
		}
		if not data.muzzleOffsetPos then data.muzzleOffsetPos = Vector() end
		if not data.muzzleOffsetAng then data.muzzleOffsetAng = Angle() end

		local originalData = table.Copy(data)
		-- Offset Position
		local posPanel = vgui.Create("DPanel", frame)
		posPanel:Dock(TOP)
		posPanel:SetHeight(100)
		posPanel:SetPaintBackground(false)
		local posLabel = vgui.Create("DLabel", posPanel)
		posLabel:SetText("Offset Position:")
		posLabel:Dock(TOP)
		local posSliders = {}
		for i, axis in ipairs({"X", "Y", "Z"}) do
			local slider = vgui.Create("DNumSlider", posPanel)
			slider:Dock(TOP)
			slider:SetText(axis)
			slider:SetMin(-100)
			slider:SetMax(100)
			slider:SetValue(data.offsetPos[i])
			slider:SetDecimals(3)
			posSliders[i] = slider
		end

		-- Offset Angle
		local angPanel = vgui.Create("DPanel", frame)
		angPanel:Dock(TOP)
		angPanel:SetHeight(100)
		angPanel:SetPaintBackground(false)
		local angLabel = vgui.Create("DLabel", angPanel)
		angLabel:SetText("Offset Angle:")
		angLabel:Dock(TOP)
		local angSliders = {}
		for i, axis in ipairs({"P", "Y", "R"}) do
			local slider = vgui.Create("DNumSlider", angPanel)
			slider:Dock(TOP)
			slider:SetText(axis)
			slider:SetMin(-180)
			slider:SetMax(180)
			slider:SetValue(data.offsetAng[i])
			slider:SetDecimals(3)
			angSliders[i] = slider
		end

		-- Offset Position
		for i, slider in ipairs(posSliders) do
			slider.OnValueChanged = function()
				local pos = Vector(posSliders[1]:GetValue(), posSliders[2]:GetValue(), posSliders[3]:GetValue())
				local ang = Angle(angSliders[1]:GetValue(), angSliders[2]:GetValue(), angSliders[3]:GetValue())
				vrmod.SetViewModelOffsetForWeaponClass(class, pos, ang)
			end
		end

		-- Offset Angle
		for i, slider in ipairs(angSliders) do
			slider.OnValueChanged = function()
				local pos = Vector(posSliders[1]:GetValue(), posSliders[2]:GetValue(), posSliders[3]:GetValue())
				local ang = Angle(angSliders[1]:GetValue(), angSliders[2]:GetValue(), angSliders[3]:GetValue())
				vrmod.SetViewModelOffsetForWeaponClass(class, pos, ang)
			end
		end

		local muzPosPanel = vgui.Create("DPanel", frame)
		muzPosPanel:Dock(TOP)
		muzPosPanel:SetHeight(100)
		muzPosPanel:SetPaintBackground(false)
		local muzPosLabel = vgui.Create("DLabel", muzPosPanel)
		muzPosLabel:SetText("Muzzle Offset Position:")
		muzPosLabel:Dock(TOP)
		local muzPosSliders = {}
		for i, axis in ipairs({"X", "Y", "Z"}) do
			local slider = vgui.Create("DNumSlider", muzPosPanel)
			slider:Dock(TOP)
			slider:SetText(axis)
			slider:SetMin(-100)
			slider:SetMax(100)
			slider:SetValue(data.muzzleOffsetPos[i] or 0)
			slider:SetDecimals(3)
			muzPosSliders[i] = slider
		end

		local muzAngPanel = vgui.Create("DPanel", frame)
		muzAngPanel:Dock(TOP)
		muzAngPanel:SetHeight(100)
		muzAngPanel:SetPaintBackground(false)
		local muzAngLabel = vgui.Create("DLabel", muzAngPanel)
		muzAngLabel:SetText("Muzzle Offset Angle:")
		muzAngLabel:Dock(TOP)
		local muzAngSliders = {}
		for i, axis in ipairs({"P", "Y", "R"}) do
			local slider = vgui.Create("DNumSlider", muzAngPanel)
			slider:Dock(TOP)
			slider:SetText(axis)
			slider:SetMin(-180)
			slider:SetMax(180)
			slider:SetValue(data.muzzleOffsetAng[i] or 0)
			slider:SetDecimals(3)
			muzAngSliders[i] = slider
		end

		local function PushMuzzleLive()
			if vrmod.SetViewModelMuzzleOffsetForWeaponClass then
				vrmod.SetViewModelMuzzleOffsetForWeaponClass(class,
					Vector(muzPosSliders[1]:GetValue(), muzPosSliders[2]:GetValue(), muzPosSliders[3]:GetValue()),
					Angle(muzAngSliders[1]:GetValue(), muzAngSliders[2]:GetValue(), muzAngSliders[3]:GetValue()))
			end
		end
		for _, slider in ipairs(muzPosSliders) do
			slider.OnValueChanged = PushMuzzleLive
		end
		for _, slider in ipairs(muzAngSliders) do
			slider.OnValueChanged = PushMuzzleLive
		end

		local applyButton = vgui.Create("DButton", frame)
		applyButton:SetText("Apply")
		applyButton:Dock(BOTTOM)
		applyButton.DoClick = function()
			data.offsetPos = Vector(posSliders[1]:GetValue(), posSliders[2]:GetValue(), posSliders[3]:GetValue())
			data.offsetAng = Angle(angSliders[1]:GetValue(), angSliders[2]:GetValue(), angSliders[3]:GetValue())
			data.muzzleOffsetPos = Vector(muzPosSliders[1]:GetValue(), muzPosSliders[2]:GetValue(), muzPosSliders[3]:GetValue())
			data.muzzleOffsetAng = Angle(muzAngSliders[1]:GetValue(), muzAngSliders[2]:GetValue(), muzAngSliders[3]:GetValue())
			vrmod.SetViewModelOffsetForWeaponClass(class, data.offsetPos, data.offsetAng)
			if vrmod.SetViewModelMuzzleOffsetForWeaponClass then
				vrmod.SetViewModelMuzzleOffsetForWeaponClass(class, data.muzzleOffsetPos, data.muzzleOffsetAng)
			end
			g_VR.viewModelInfo[class] = data
			SaveViewModelConfig()
			frame:Close()
		end

		local cancelButton = vgui.Create("DButton", frame)
		vrmod.SetViewModelOffsetForWeaponClass(class, originalData.offsetPos, originalData.offsetAng)
		if vrmod.SetViewModelMuzzleOffsetForWeaponClass then
			vrmod.SetViewModelMuzzleOffsetForWeaponClass(class, originalData.muzzleOffsetPos or Vector(), originalData.muzzleOffsetAng or Angle())
		end
		cancelButton:SetText("Cancel")
		cancelButton:Dock(BOTTOM)
		cancelButton.DoClick = function() frame:Close() end
	end

	-- GUI: Cube VR menu in headset, classic Derma on desktop
	concommand.Add("vrmod_weaponconfig", function()
		if not g_VR.viewModelInfo then LoadViewModelConfig() end
		if g_VR and g_VR.active and vrmod.WeaponSettings_Open then
			vrmod.WeaponSettings_Open()
			return
		end
		CreateWeaponConfigGUI()
	end)

	concommand.Add("vrmod_weaponsettings", function()
		if g_VR and g_VR.active and vrmod.WeaponSettings_Open then
			vrmod.WeaponSettings_Open()
		else
			RunConsoleCommand("vrmod_weaponconfig")
		end
	end)
end