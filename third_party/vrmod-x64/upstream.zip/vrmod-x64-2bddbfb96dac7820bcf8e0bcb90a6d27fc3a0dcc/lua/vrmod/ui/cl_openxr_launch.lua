if SERVER then return end
-- =============================================================================
-- OpenXR native launcher handshake
--
-- gvrmod_launcher.sh writes garrysmod/data/vrmod/openxr_launch.txt before boot.
-- Goal: HMD is primary — force OpenXR VR + Cube hub (native launcher UI).
-- Desktop window is only a tiny mirror. Never wait on GameUI / cursor.
-- =============================================================================

vrmod = vrmod or {}
g_VR = g_VR or {}

local MARKER = "vrmod/openxr_launch.txt"
local applied = false
local startAttempts = 0
local hubAttempts = 0
local MAX_START_ATTEMPTS = 60 -- ~30s @ 0.5s
local launchedUI = false

local function log(fmt, ...)
	local msg = string.format(fmt, ...)
	print("[gVRMod][openxr-launch] " .. msg)
	if vrmod.logger then vrmod.logger.Info("[openxr-launch] " .. msg) end
end

local function parseMarker(raw)
	local t = {}
	for line in string.gmatch(raw or "", "[^\r\n]+") do
		local k, v = string.match(line, "^([%w_]+)%s*=%s*(.-)%s*$")
		if k then t[k] = v end
	end
	return t
end

local function setBoolCvar(name, val)
	local c = GetConVar(name)
	if c then
		pcall(function() c:SetBool(val and true or false) end)
		return
	end
	if not GetConVar(name) then
		CreateClientConVar(name, val and "1" or "0", true, FCVAR_ARCHIVE)
	end
	c = GetConVar(name)
	if c then pcall(function() c:SetBool(val and true or false) end) end
end

local function setStrCvar(name, val)
	local c = GetConVar(name)
	if c then
		pcall(function() c:SetString(tostring(val)) end)
		return
	end
	if not GetConVar(name) then
		CreateClientConVar(name, tostring(val), true, FCVAR_ARCHIVE)
	end
	c = GetConVar(name)
	if c then pcall(function() c:SetString(tostring(val)) end) end
end

--- Apply launch marker → convars. Marker kept until VR is live (retry-safe).
function vrmod.ApplyOpenXRLaunchMarker()
	if not file.Exists(MARKER, "DATA") then return false end
	local raw = file.Read(MARKER, "DATA") or ""
	local t = parseMarker(raw)
	if not t.mode and not t.autostart then return false end

	-- Native Cube launcher is the product. "menu" still opens hub (not stock GameUI).
	local mode = t.mode or "hub"
	if mode == "menu" then mode = "hub" end
	local wantAuto = (t.autostart == "1" or t.autostart == "true" or t.autostart == nil)
	local wantHub = true

	setStrCvar("vrmod_prefer_backend", t.prefer_backend or "openxr")
	setBoolCvar("vrmod_autostart", wantAuto)
	setBoolCvar("vrmod_menu_vr", false) -- never chase stock MainMenu cinema
	setBoolCvar("vrmod_hub", true)
	setBoolCvar("vrmod_require_window_focus", false)
	setBoolCvar("vrmod_laserpointer", true)

	pcall(function()
		file.Write("vrmod/openxr_launch_last.txt",
			string.format("applied=%s mode=%s auto=%s\n", os.date("%Y-%m-%d %H:%M:%S"), mode, tostring(wantAuto)))
	end)

	local nativeWrapper = (t.native_wrapper == "1" or t.native_wrapper == "true")
	applied = true
	g_VR._openxrLaunch = {
		mode = mode,
		autostart = wantAuto,
		menu = false,
		hub = wantHub,
		bg_map = t.bg_map or "gm_construct",
		map_mode = t.map_mode or "full",
		native_wrapper = nativeWrapper,
		ts = tonumber(t.ts) or 0,
	}
	log("marker applied mode=%s autostart=%s native_wrapper=%s hub=1 (native Cube launcher)",
		mode, tostring(wantAuto), tostring(nativeWrapper))
	return true
end

local function consumeMarker()
	if file.Exists(MARKER, "DATA") then
		pcall(function() file.Delete(MARKER) end)
	end
end

function vrmod.IsOpenXRLaunchSession()
	return applied or (g_VR and g_VR._openxrLaunch ~= nil)
end

--- True when Start came from CubeUI / gvrmod_launcher (marker native_wrapper=1).
function vrmod.IsNativeWrapperLaunch()
	if g_VR and g_VR._openxrLaunch and g_VR._openxrLaunch.native_wrapper then
		return true
	end
	-- Marker may still be on disk before apply; treat as wrapper product path
	if file.Exists(MARKER, "DATA") then
		local raw = file.Read(MARKER, "DATA") or ""
		if string.find(raw, "native_wrapper=1", 1, true)
			or string.find(raw, "native_wrapper=true", 1, true) then
			return true
		end
	end
	return false
end

local function writeStatus(line)
	pcall(function()
		file.Write("vrmod/cube_launch_status.txt",
			string.format("%s | %s | active=%s attempts=%d\n",
				os.date("%H:%M:%S"), line,
				tostring(g_VR and g_VR.active), startAttempts))
	end)
end

--- Signal native CubeUI to release OpenXR (seamless handoff, no black gap).
local function writeHandoff(phase)
	pcall(function()
		file.Write("vrmod/cube_handoff.txt",
			string.format("phase=%s\nts=%d\n", tostring(phase), os.time()))
	end)
end

local handoffSignaled = false
local handoffDelayUntil = 0

--- Reset take_xr handshake so RESUME / second session can ask Cube to drop XR again.
function vrmod.OpenXR_ResetHandoff(reason)
	handoffSignaled = false
	handoffDelayUntil = 0
	startAttempts = 0
	log("handoff reset (%s)", tostring(reason or "?"))
end

local function forceStartVR()
	if g_VR and g_VR.active then
		writeHandoff("vr_active")
		return true
	end
	-- Ensure module is loaded (openxr_launch can run before core finishes require)
	if not isfunction(VRUtilClientStart) then
		if vrmod.LoadNativeModule then pcall(vrmod.LoadNativeModule) end
	end
	if not isfunction(VRUtilClientStart) then
		log("VRUtilClientStart missing (module not loaded yet)")
		writeStatus("wait_module")
		writeHandoff("wait_module")
		return false
	end

	-- Ask native launcher to drop OpenXR first (only one session).
	if not handoffSignaled then
		handoffSignaled = true
		-- Native orderly release needs room for xrRequestExitSession + STOPPING
		handoffDelayUntil = CurTime() + 2.5
		writeHandoff("take_xr")
		writeStatus("take_xr_signaled")
		log("signaled CubeUI take_xr — waiting for native to release session (2.5s)")
		return false
	end
	if CurTime() < handoffDelayUntil then
		writeStatus("wait_native_release")
		return false
	end

	startAttempts = startAttempts + 1
	log("force VRUtilClientStart attempt %d", startAttempts)
	writeStatus("start_attempt_" .. tostring(startAttempts))
	writeHandoff("starting_xr")
	-- Always force — loading screen has cursor; normal vrmod_start waits forever
	if isfunction(RunConsoleCommand) then
		pcall(RunConsoleCommand, "vrmod_start", "force")
	end
	local ok, err = pcall(VRUtilClientStart)
	if not ok then
		log("start error: %s", tostring(err))
		writeStatus("error_" .. tostring(err))
		return false
	end
	if g_VR and g_VR.active then
		writeStatus("vr_active")
		writeHandoff("vr_active")
		pcall(function() file.Write("vrmod/cube_ready.txt", "ready=1\n") end)
		return true
	end
	writeStatus("start_returned_inactive")
	return false
end

--- Product entry for soft resume from Cube (warm_attach): re-run take_xr + start.
-- Must NOT only call vrmod_start force — Cube still owns OpenXR until take_xr.
function vrmod.OpenXR_ForceStartWithHandoff(reason)
	if g_VR and g_VR.active then
		writeHandoff("vr_active")
		return true
	end
	vrmod.OpenXR_ResetHandoff(reason or "force_handoff")
	vrmod.ApplyOpenXRLaunchMarker()
	-- Immediate take_xr poke, then tick until active or attempts exhausted
	forceStartVR()
	timer.Remove("vrmod_openxr_resume_start")
	local n = 0
	timer.Create("vrmod_openxr_resume_start", 0.5, 0, function()
		n = n + 1
		if g_VR and g_VR.active then
			timer.Remove("vrmod_openxr_resume_start")
			return
		end
		if n > MAX_START_ATTEMPTS then
			timer.Remove("vrmod_openxr_resume_start")
			log("resume handoff gave up after %d ticks", n)
			if vrmod.Toast then
				vrmod.Toast("Resume VR failed — Cube still holding XR?", 6, "warn")
			end
			return
		end
		forceStartVR()
	end)
	return false
end

-- After any VR exit, next start must re-signal take_xr (stale flag blocked soft resume).
hook.Add("VRMod_Exit", "vrmod_openxr_reset_handoff", function(ply)
	if ply and IsValid(ply) and IsValid(LocalPlayer()) and ply ~= LocalPlayer() then return end
	vrmod.OpenXR_ResetHandoff("vrmod_exit")
	timer.Remove("vrmod_openxr_resume_start")
end)

--- Native VR launcher UI (Cube hub) — automatic product surface.
-- Never stock GameUI. Never requires a concommand.
-- Do NOT call OpenPauseMenuVR (toggle can close an already-open hub).
local function openNativeLauncherUI()
	if not (g_VR and g_VR.active) then return false end
	if vrmod.VRUnpauseWorld then pcall(vrmod.VRUnpauseWorld) end

	if vrmod.VRHub_IsOpen and vrmod.VRHub_IsOpen() then
		launchedUI = true
		return true
	end

	-- Direct open only (no pause-menu toggle path)
	if vrmod.VRHub_Open then
		pcall(vrmod.VRHub_Open)
	elseif vrmod.VRHub_OpenWhenReady then
		pcall(vrmod.VRHub_OpenWhenReady)
	end

	if vrmod.VRHub_IsOpen and vrmod.VRHub_IsOpen() then
		launchedUI = true
		log("Cube hub open — native VR launcher")
		return true
	end

	hubAttempts = hubAttempts + 1
	if hubAttempts <= 12 then
		log("hub not open yet (try %d)", hubAttempts)
	end
	return false
end

-- G03: read Cube shell STAGE pack (continuity data only — never auto-apply height/origin).
local stagePackNotified = false
local function noteStagePackOnce()
	if stagePackNotified then return end
	stagePackNotified = true
	if not (vrmod.utils and vrmod.utils.StagePack_Parse) then return end
	local raw
	pcall(function()
		if file and file.Exists and file.Exists("vrmod/cube_stage_pack.txt", "DATA") then
			raw = file.Read("vrmod/cube_stage_pack.txt", "DATA")
		end
	end)
	if not raw or raw == "" then
		log("no cube_stage_pack.txt (cold start without Cube shell pack)")
		return
	end
	local pack = vrmod.utils.StagePack_Parse(raw)
	if not pack or not vrmod.utils.StagePack_IsUsable(pack) then
		log("stage pack present but unusable")
		return
	end
	g_VR._cubeStagePack = pack
	-- G03 apply gate + plan + careful executor (default OFF; opt-in convar/file)
	local measuredY
	pcall(function()
		local hmd = g_VR.tracking and g_VR.tracking.hmd
		-- tracking poses are Source units; pack is meters — skip measured if we can't convert safely
		if hmd and hmd.pos and g_VR.scale and g_VR.scale > 1 then
			measuredY = hmd.pos.z / g_VR.scale
		end
	end)
	-- Opt-in only: vrmod_stage_apply 1 or DATA/vrmod/stage_apply_enable.txt
	local allowApply = false
	if vrmod.utils.StagePack_AllowApplyFromFlags then
		local conOn, fileOn = false, false
		pcall(function()
			if not GetConVar("vrmod_stage_apply") then
				CreateClientConVar("vrmod_stage_apply", "0", true, FCVAR_ARCHIVE,
					"G03 careful Cube stage height apply (0=off)")
			end
			local c = GetConVar("vrmod_stage_apply")
			if c then conOn = c:GetBool() end
		end)
		pcall(function()
			if file and file.Exists and file.Exists("vrmod/stage_apply_enable.txt", "DATA") then
				fileOn = true
			end
		end)
		allowApply = vrmod.utils.StagePack_AllowApplyFromFlags({
			convar_on = conOn,
			file_enable = fileOn,
		})
	end
	local decision = vrmod.utils.StagePack_ApplyDecision(pack, {
		measured_head_y_m = measuredY,
		allow_apply = allowApply,
	})
	g_VR._cubeStagePackApply = decision
	local curSeat = 0
	pcall(function()
		local cv = GetConVar and GetConVar("vrmod_seatedoffset")
		if cv then curSeat = cv:GetFloat() end
	end)
	local plan = (vrmod.utils.StagePack_ComputeApplyPlan and vrmod.utils.StagePack_ComputeApplyPlan(pack, decision, {
		world_scale = (g_VR.scale and g_VR.scale > 1) and g_VR.scale or 40,
		current_seatedoffset = curSeat,
		allow_apply = allowApply,
	})) or nil
	g_VR._cubeStagePackPlan = plan
	local muts = (plan and vrmod.utils.StagePack_MutationsFromPlan and vrmod.utils.StagePack_MutationsFromPlan(plan)) or {}
	g_VR._cubeStagePackMutations = muts
	-- Careful executor: only when plan armed + allow (mutations non-empty)
	local execRes
	if vrmod.utils.StagePack_ShouldExecutePlan
		and vrmod.utils.StagePack_ShouldExecutePlan(plan, allowApply)
		and #muts > 0
		and vrmod.utils.StagePack_ExecuteMutations then
		execRes = vrmod.utils.StagePack_ExecuteMutations(muts, function(name, val)
			local n = tonumber(val) or 0
			-- Single SoT write (cache + VRMod_SettingChanged + seated hook)
			if vrmod.SettingsSetFloat then
				local ok = pcall(vrmod.SettingsSetFloat, name, n)
				if not ok then return false, "set_fail_" .. tostring(name) end
			else
				local cv = GetConVar(name)
				if not cv then return false, "missing_" .. tostring(name) end
				local ok = pcall(function() cv:SetFloat(n) end)
				if not ok then return false, "set_fail_" .. tostring(name) end
			end
			if name == "vrmod_seatedoffset" then
				if vrmod.SettingsSetBool then pcall(vrmod.SettingsSetBool, "vrmod_seated", true) end
				if vrmod.UpdateSeatedOffset then pcall(vrmod.UpdateSeatedOffset) end
			end
			return true
		end)
		g_VR._cubeStagePackExec = execRes
		log("stage pack execute applied=%s ok=%s allow=%s",
			tostring(execRes and execRes.applied), tostring(execRes and execRes.ok), tostring(allowApply))
	end
	local hint = (execRes and vrmod.utils.StagePack_ExecuteToast and vrmod.utils.StagePack_ExecuteToast(execRes, plan))
		or (plan and vrmod.utils.StagePack_PlanToast and vrmod.utils.StagePack_PlanToast(plan))
		or (vrmod.utils.StagePack_ApplyToast and vrmod.utils.StagePack_ApplyToast(decision))
		or vrmod.utils.StagePack_ToastHint(pack)
	local expect = (vrmod.utils.StagePack_HmdExpect
		and vrmod.utils.StagePack_HmdExpect(decision, plan, execRes)) or nil
	g_VR._cubeStagePackHmdExpect = expect
	if expect and expect.checklist then
		log("G03 HMD %s", tostring(expect.checklist))
	end
	log("stage pack ok space=%s head_ok=%s y=%s apply=%s reason=%s plan=%s muts=%d allow=%s",
		tostring(pack.ref_space), tostring(pack.head_ok), tostring(pack.head_y),
		tostring(decision and decision.action), tostring(decision and decision.reason),
		tostring(plan and plan.method), #muts, tostring(allowApply))
	if hint and vrmod.Toast then
		vrmod.Toast(hint, 4, "hint")
	end
end

-- G04: read cube_warm.txt map-attach intent; careful changelevel opt-in only.
local warmAttachNotified = false
local function noteWarmAttachOnce()
	if warmAttachNotified then return end
	warmAttachNotified = true
	if not (vrmod.utils and vrmod.utils.WarmAttach_Parse) then return end
	local raw
	pcall(function()
		if file and file.Exists and file.Exists("vrmod/cube_warm.txt", "DATA") then
			raw = file.Read("vrmod/cube_warm.txt", "DATA")
		end
	end)
	if not raw or raw == "" then
		log("no cube_warm.txt (cold-only Start or cleared)")
		return
	end
	local req = vrmod.utils.WarmAttach_Parse(raw)
	if not req then
		log("cube_warm present but unusable")
		return
	end
	local curMap = ""
	pcall(function()
		if game and game.GetMap then curMap = tostring(game.GetMap() or "") end
	end)
	-- Opt-in only: vrmod_warm_changelevel 1 or DATA/vrmod/warm_changelevel_enable.txt
	local allowChg = false
	if vrmod.utils.WarmAttach_AllowChangelevelFromFlags then
		local conOn, fileOn = false, false
		pcall(function()
			if not GetConVar("vrmod_warm_changelevel") then
				CreateClientConVar("vrmod_warm_changelevel", "0", true, FCVAR_ARCHIVE,
					"G04 careful warm-map changelevel (0=off)")
			end
			local c = GetConVar("vrmod_warm_changelevel")
			if c then conOn = c:GetBool() end
		end)
		pcall(function()
			if file and file.Exists and file.Exists("vrmod/warm_changelevel_enable.txt", "DATA") then
				fileOn = true
			end
		end)
		allowChg = vrmod.utils.WarmAttach_AllowChangelevelFromFlags({
			convar_on = conOn,
			file_enable = fileOn,
		})
	end
	local decision = vrmod.utils.WarmAttach_Decide(req, {
		current_map = curMap,
		allow_changelevel = allowChg, -- default false; opt-in above
	})
	g_VR._cubeWarmRequest = req
	g_VR._cubeWarmAttach = decision
	local plan = (vrmod.utils.WarmAttach_ChangelevelPlan
		and vrmod.utils.WarmAttach_ChangelevelPlan(decision)) or nil
	g_VR._cubeWarmChangelevelPlan = plan
	-- Careful executor: only when plan armed + allow (never default path)
	local execRes
	if plan
		and vrmod.utils.WarmAttach_ShouldExecuteChangelevel
		and vrmod.utils.WarmAttach_ShouldExecuteChangelevel(plan, allowChg)
		and vrmod.utils.WarmAttach_ExecuteChangelevel then
		execRes = vrmod.utils.WarmAttach_ExecuteChangelevel(plan, function(map)
			local ok = pcall(function()
				RunConsoleCommand("changelevel", tostring(map))
			end)
			if not ok then return false, "rcc_fail" end
			return true
		end)
		g_VR._cubeWarmChangelevelExec = execRes
		log("warm changelevel applied=%s ok=%s map=%s allow=%s",
			tostring(execRes and execRes.applied), tostring(execRes and execRes.ok),
			tostring(execRes and execRes.map), tostring(allowChg))
	end
	local expect = (vrmod.utils.WarmAttach_HmdExpect
		and vrmod.utils.WarmAttach_HmdExpect(decision, plan, execRes, nil)) or nil
	g_VR._cubeWarmHmdExpect = expect
	if expect and expect.checklist then
		log("G04 HMD %s", tostring(expect.checklist))
	end
	log("warm attach action=%s reason=%s want=%s cur=%s allow_chg=%s plan=%s",
		tostring(decision.action), tostring(decision.reason),
		tostring(decision.request_map), tostring(decision.current_map),
		tostring(allowChg), tostring(plan and plan.method))
	local hint = (execRes and vrmod.utils.WarmAttach_ExecuteToast
			and vrmod.utils.WarmAttach_ExecuteToast(execRes, plan))
		or (vrmod.utils.WarmAttach_Toast and vrmod.utils.WarmAttach_Toast(decision))
	if hint and vrmod.Toast then
		vrmod.Toast(hint, 4, "hint")
	end
end

local function afterVRLive()
	log("VR active map=%s — sole Cube hub (one pause surface)", tostring(game.GetMap and game.GetMap() or "?"))
	-- Never let a host CubeUI relaunch fight GMod for OpenXR after Start/Resume
	if vrmod.CubeBridge_CancelRelaunch then
		pcall(vrmod.CubeBridge_CancelRelaunch, "after_vr_live")
	end
	consumeMarker()
	pcall(function() RunConsoleCommand("vrmod_laserpointer", "1") end)
	if vrmod.VRUnpauseWorld then pcall(vrmod.VRUnpauseWorld) end
	noteStagePackOnce()
	noteWarmAttachOnce()

	-- One product surface only — not hub + pause + QM spam
	local function openOnce()
		if vrmod.OpenSoleHub then
			return vrmod.OpenSoleHub()
		end
		return openNativeLauncherUI()
	end
	timer.Remove("vrmod_openxr_hub_retry")
	if openOnce() then
		launchedUI = true
		if vrmod.Toast then
			vrmod.Toast("Cube hub — Resume · New Game · Settings", 4, "hint")
		end
		return
	end
	-- Single short retry window if hands/menus not ready yet
	local tries = 0
	timer.Create("vrmod_openxr_hub_retry", 0.4, 8, function()
		tries = tries + 1
		if not (g_VR and g_VR.active) then
			timer.Remove("vrmod_openxr_hub_retry")
			return
		end
		if vrmod.VRHub_IsOpen and vrmod.VRHub_IsOpen() then
			launchedUI = true
			timer.Remove("vrmod_openxr_hub_retry")
			return
		end
		if openOnce() then
			launchedUI = true
			timer.Remove("vrmod_openxr_hub_retry")
		elseif tries >= 8 then
			log("hub open gave up after retries")
		end
	end)
end

--- Cube Start can leave GMod on the main menu when +map ran before workshop
-- mounted (GMA-only maps). Retry map once BSP is visible to GAME.
local function scheduleDeferredMap()
	local want = g_VR._openxrLaunch and g_VR._openxrLaunch.bg_map
	if not want or want == "" then return end
	want = tostring(want):gsub("^maps/", ""):gsub("%.bsp$", "")
	timer.Remove("vrmod_cube_deferred_map")
	local tries = 0
	timer.Create("vrmod_cube_deferred_map", 1.0, 45, function()
		tries = tries + 1
		local cur = (game.GetMap and game.GetMap()) or ""
		if cur ~= "" and string.lower(cur) == string.lower(want) then
			timer.Remove("vrmod_cube_deferred_map")
			log("deferred map ok — already on %s", want)
			return
		end
		-- Main menu / wrong map: only load when filesystem can see the BSP
		local path = "maps/" .. want .. ".bsp"
		if not (file and file.Exists and file.Exists(path, "GAME")) then
			if tries == 1 or tries % 10 == 0 then
				log("deferred map wait — %s not in GAME yet (try %d)", path, tries)
			end
			if tries >= 45 and vrmod.Toast then
				vrmod.Toast("Map not found: " .. want .. " (extract/workshop?)", 8, "warn")
			end
			return
		end
		log("deferred map load → %s (was %s)", want, tostring(cur))
		writeStatus("map_" .. want)
		writeHandoff("map_load")
		if vrmod.Toast then
			vrmod.Toast("Loading map " .. want .. "…", 4, "hint")
		end
		-- Prefer map (full load) over changelevel from empty menu
		pcall(function()
			RunConsoleCommand("map", want)
		end)
		timer.Remove("vrmod_cube_deferred_map")
	end)
end

local function bootFromLaunch()
	local had = vrmod.ApplyOpenXRLaunchMarker()
	if not had and not vrmod.IsOpenXRLaunchSession() then
		local auto = GetConVar("vrmod_autostart")
		local hub = GetConVar("vrmod_hub")
		local menu = GetConVar("vrmod_menu_vr")
		if not ((auto and auto:GetBool()) and ((hub and hub:GetBool()) or (menu and menu:GetBool()))) then
			return
		end
		applied = true
		g_VR._openxrLaunch = g_VR._openxrLaunch or {
			mode = "cfg",
			autostart = true,
			hub = true,
			menu = false,
			-- cfg path is always the native Cube product wrapper
			native_wrapper = true,
		}
		setBoolCvar("vrmod_hub", true)
		setBoolCvar("vrmod_menu_vr", false)
		log("boot from cfg convars (no marker) → native hub")
	end

	if not (g_VR._openxrLaunch and g_VR._openxrLaunch.autostart) then
		local auto = GetConVar("vrmod_autostart")
		if not (auto and auto:GetBool()) then return end
	end

	-- Force openxr backend preference every boot for launcher sessions
	setStrCvar("vrmod_prefer_backend", "openxr")
	writeHandoff("boot")
	writeStatus("boot")

	-- If cold +map failed (menu), recover once workshop/extract is visible
	scheduleDeferredMap()

	timer.Create("vrmod_openxr_launch_start", 0.5, 0, function()
		if g_VR and g_VR.active then
			timer.Remove("vrmod_openxr_launch_start")
			afterVRLive()
			return
		end
		if startAttempts >= MAX_START_ATTEMPTS then
			timer.Remove("vrmod_openxr_launch_start")
			log("gave up after %d attempts — check WiVRn / HMD / vrmod_debug.log", startAttempts)
			if vrmod.Toast then
				vrmod.Toast("OpenXR VR start failed — WiVRn + headset?", 8, "error")
			end
			return
		end
		-- Don't start VR on pure main menu with no map — wait for deferred map
		local cur = (game.GetMap and game.GetMap()) or ""
		local want = g_VR._openxrLaunch and g_VR._openxrLaunch.bg_map
		if want and want ~= "" and cur ~= "" and string.lower(cur) ~= string.lower(want) then
			-- still wrong map; keep waiting (forceStart would claim XR on menu)
			if startAttempts < 3 then
				writeStatus("wait_map_" .. tostring(want))
			end
			-- still try VR after a few map waits so hub can appear
		end
		forceStartVR()
	end)
end

hook.Add("Think", "vrmod_openxr_launch_boot", function()
	hook.Remove("Think", "vrmod_openxr_launch_boot")
	-- Marker first (before other systems gate start)
	vrmod.ApplyOpenXRLaunchMarker()
	timer.Simple(0.15, bootFromLaunch)
end)

hook.Add("InitPostEntity", "vrmod_openxr_launch_map", function()
	if file.Exists(MARKER, "DATA") then
		vrmod.ApplyOpenXRLaunchMarker()
	end
	local want = vrmod.IsOpenXRLaunchSession()
		or (GetConVar("vrmod_autostart") and GetConVar("vrmod_autostart"):GetBool())
	if not want then return end
	-- G01: status-file phase for Cube seamless panel (map loaded before take_xr)
	local mapName = tostring(game.GetMap and game.GetMap() or "?")
	writeHandoff("map_ready")
	writeStatus("map_ready_" .. mapName)
	log("InitPostEntity map=%s — force VR", mapName)
	timer.Simple(0.5, function()
		if not (g_VR and g_VR.active) then forceStartVR() end
	end)
	timer.Simple(1.5, function()
		if not (g_VR and g_VR.active) then forceStartVR() end
	end)
	timer.Simple(2.5, function()
		if g_VR and g_VR.active then
			openNativeLauncherUI()
		else
			forceStartVR()
		end
	end)
end)

hook.Add("VRMod_Start", "vrmod_openxr_launch_ui", function(ply)
	if ply and IsValid(LocalPlayer()) and ply ~= LocalPlayer() then return end
	if not vrmod.IsOpenXRLaunchSession() then
		local auto = GetConVar("vrmod_autostart")
		local hub = GetConVar("vrmod_hub")
		if not ((auto and auto:GetBool()) and (hub and hub:GetBool())) then
			return
		end
	end
	timer.Simple(0.2, afterVRLive)
end)

-- Debug only — product path never requires typing these
concommand.Add("vrmod_openxr_launch_status", function()
	print(string.format("[gVRMod] launchSession=%s applied=%s active=%s attempts=%d hubUI=%s marker=%s",
		tostring(vrmod.IsOpenXRLaunchSession()),
		tostring(applied),
		tostring(g_VR and g_VR.active),
		startAttempts,
		tostring(launchedUI or (vrmod.VRHub_IsOpen and vrmod.VRHub_IsOpen())),
		tostring(file.Exists(MARKER, "DATA"))))
	if g_VR and g_VR._openxrLaunch then
		PrintTable(g_VR._openxrLaunch)
	end
end)
